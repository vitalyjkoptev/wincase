<?php
/**
 * Theme Address Info Widget
 * @package Visaland
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit(); // Exit if accessed directly
}

// Check if Codestar Framework is active
if (class_exists('CSF')) {

    // Create Address Info Widget
    CSF::createWidget('visaland_address_info_widget', array(
        'title'       => esc_html__('Visaland: Address Info', 'visaland-core'),
        'classname'   => 'visaland-widget-address-info',
        'description' => esc_html__('Display Address Info widget', 'visaland-core'),
        'fields'      => array(
            array(
                'id'      => 'address-title',
                'type'    => 'text',
                'title'   => esc_html__('Title', 'visaland-core'),
                'default' => esc_html__('Address:', 'visaland-core'),
            ),
            array(
                'id'      => 'address-location',
                'type'    => 'textarea',
                'title'   => esc_html__('Location', 'visaland-core'),
                'default' => esc_html__('570 8th Ave, New York, NY 10018 United States', 'visaland-core'),
            ),
            array(
                'id'      => 'hours-title',
                'type'    => 'text',
                'title'   => esc_html__('Hours Title', 'visaland-core'),
                'default' => esc_html__('Hours', 'visaland-core'),
            ),
            array(
                'id'      => 'hours-text',
                'type'    => 'textarea',
                'title'   => esc_html__('Hours Text', 'visaland-core'),
                'default' => esc_html__('9.30am – 6.30pm <br>Monday to Friday', 'visaland-core'),
            ),
        )
    ));

    // Widget Output Function
    if (!function_exists('visaland_address_info_widget')) {
        function visaland_address_info_widget($args, $instance)
        {
            echo $args['before_widget'];

            // Retrieve fields
            $title       = $instance['address-title'] ?? esc_html__('Address:', 'visaland-core');
            $location    = $instance['address-location'] ?? '';
            $hours_title = $instance['hours-title'] ?? esc_html__('Hours', 'visaland-core');
            $hours_text  = $instance['hours-text'] ?? '';

            ?>
            <div class="widget-head">
                <h5><?php echo esc_html($title); ?></h5>
            </div>
            <div class="footer-address-text">
                <p><?php echo wp_kses_post(esc_html($location)); ?></p>
                <h5><?php echo wp_kses_post($hours_title); ?></h5>
                <p><?php echo wp_kses_post($hours_text); ?></p>
            </div>
            <?php

            echo $args['after_widget'];
        }
    }
}
?>
