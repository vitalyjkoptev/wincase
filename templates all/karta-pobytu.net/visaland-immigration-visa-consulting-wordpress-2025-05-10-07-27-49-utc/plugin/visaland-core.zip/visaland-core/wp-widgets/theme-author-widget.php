<?php
/**
 * Theme Author Widget
 * @package Visaland
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit(); //exit if access directly
}
// Control core classes for avoid errors
if (class_exists('CSF')) {


    // Create a About Widget
    CSF::createWidget('visaland_author_widget', array(
        'title' => esc_html__('Visaland: Author', 'visaland-core'),
        'classname' => 'visaland-widget-author',
        'description' => esc_html__('Display Author widget', 'visaland-core'),
        'fields' => array(
            array(
                'id' => 'image',
                'type' => 'media',
                'title' => esc_html__('Image', 'Visaland-core')
            ),
            array(
                'id' => 'name',
                'type' => 'text',
                'title' => esc_html__('Name', 'Visaland-core'),
                'default' => esc_html__('Leslie Alexander', 'visaland-core')
            ),
            array(
                'id' => 'phone',
                'type' => 'text',
                'title' => esc_html__('Phone', 'Visaland-core'),
                'default' => esc_html__('(480) 555-0103', 'visaland-core')
            ),

            array(
                'id' => 'visaland-author-social-repeater',
                'type' => 'repeater',
                'title' => esc_html__('Author', 'visaland-core'),
                'fields' => array(
                    array(
                        'id' => 'visaland-author-social',
                        'type' => 'icon',
                        'title' => esc_html__('author social', 'visaland-core'),
                    ),
                    array(
                        'id' => 'visaland-author-social-url',
                        'type' => 'text',
                        'title' => esc_html__('author social', 'visaland-core'),
                        'default' => esc_html__('#', 'visaland-core')
                    ),

                ),
            ),
        )
    ));


    if (!function_exists('visaland_author_widget')) {
        function visaland_author_widget($args, $instance)
        {

            echo $args['before_widget'];
            $image = $instance['image'];
            $img_id = $image['id'] ?? '';
            $img_print = $img_id ? wp_get_attachment_image_src($img_id,'full')[0] : '';
            $alt_text = get_post_meta($img_id, '_wp_attachment_image_alt', true);
            $name = $instance['name'] ?? '';
            $phone = $instance['phone'] ?? '';
            $author = is_array($instance['visaland-author-social-repeater']) && !empty($instance['visaland-author-social-repeater']) ? $instance['visaland-author-social-repeater'] : [];
            ?>

            <div class="widget_author text-center">  
                <?php
                    if (!empty($img_print)) {
                        printf('<div class="thumb"><img src="%1$s" alt="%2$s"/></div>', esc_url($img_print), esc_attr($alt_text));
                    }
                ?> 
                <div class="details">
                    <h5><?php echo esc_html($name); ?></h5>
                    <h6><?php echo esc_html($phone); ?></h6>
                    <ul class="social-media-list">
                        <?php
                            foreach ($author as $socials) {
                                echo '<li>
                                    <a href="'.$socials['visaland-author-social-url'].'">
                                        <i class="' . $socials['visaland-author-social'] . '"></i>
                                    </a>
                                </li>';
                            };
                        ?>
                    </ul>
                </div>
            </div>
            <?php

            echo $args['after_widget'];

        }
    }

}

?>