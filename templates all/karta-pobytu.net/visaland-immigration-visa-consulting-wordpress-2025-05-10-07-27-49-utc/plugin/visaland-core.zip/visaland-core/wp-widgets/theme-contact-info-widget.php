<?php
/**
 * Theme Contact Info Widget
 * @package Visaland
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit(); // Exit if accessed directly
}

if (class_exists('CSF')) {

    // Create Contact Info Widget
    CSF::createWidget('visaland_topbar_contact_info_widget', array(
        'title'       => esc_html__('Visaland: Footer Top-bar Contact Info', 'visaland-core'),
        'classname'   => 'visaland-widget-contact-info',
        'description' => esc_html__('Display Contact Info widget', 'visaland-core'),
        'fields'      => array(   
            array(
                'id'          => 'opt-select-3',
                'type'        => 'select',
                'title'       => esc_html__('Select Styles', 'visaland-core'),
                'chosen'      => true,
                'placeholder' => 'Select an option',
                'options'     => array(
                    'option-1'  => 'Option 1',
                    'option-2'  => 'Option 2',
                ),
                'default'     => 'option-1',
            ),      
            array(
                'id'    => 'visaland-footer-contact-info-repeater',
                'type'  => 'repeater',
                'title' => esc_html__('Contact Info Repeater', 'visaland-core'),
                'fields' => array(
                    array(
                        'id'      => 'visaland-footer-top-bar-contact-icon',
                        'type'    => 'icon',
                        'title'   => esc_html__('Icon', 'visaland-core'),
                        'default' => 'fa fa-facebook-f',
                    ),
                    array(
                        'id'      => 'visaland-footer-top-bar-contact-text',
                        'type'    => 'text',
                        'title'   => esc_html__('Enter Contact Text', 'visaland-core'),
                        'default' => esc_html__('Call Us 7/24', 'visaland-core'),
                    ),
                    array(
                        'id'      => 'visaland-footer-top-bar-contact-info',
                        'type'    => 'text',
                        'title'   => esc_html__('Enter Contact Info', 'visaland-core'),
                        'default' => esc_html__('+1718-904-4450', 'visaland-core'),
                    ),
                    array(
                        'id'      => 'visaland-footer-top-bar-contact-url',
                        'type'    => 'text',
                        'title'   => esc_html__('Enter Contact URL', 'visaland-core'),
                        'default' => esc_html__('tel:+1718-904-4450', 'visaland-core'),
                    ),
                ),
            ),
            array(
                'id'    => 'footer-3-widget-logo',
                'type'  => 'media',
                'title' => esc_html__('Upload Your Logo', 'visaland-core'),
            ),           
        )
    ));

    // Widget Output Function
    if (!function_exists('visaland_topbar_contact_info_widget')) {
        function visaland_topbar_contact_info_widget($args, $instance)
        {
            echo $args['before_widget'];

            // Get the value of the select field
            $selected_option = isset($instance['opt-select-3']) ? $instance['opt-select-3'] : 'option-1';

            // Contact Info Repeater Logic
            $contact_infos = is_array($instance['visaland-footer-contact-info-repeater']) ? $instance['visaland-footer-contact-info-repeater'] : [];

            // Check which option was selected and display the corresponding content
            if ($selected_option === 'option-1') {
                // Option 1: Display Contact Info Repeater
                if (!empty($contact_infos)) {
                    echo '<div class="contact-info-area-5">';

                    foreach ($contact_infos as $contact_info) {
                        $icon = isset($contact_info['visaland-footer-top-bar-contact-icon']) ? $contact_info['visaland-footer-top-bar-contact-icon'] : 'fa fa-phone';
                        $text = isset($contact_info['visaland-footer-top-bar-contact-text']) ? $contact_info['visaland-footer-top-bar-contact-text'] : esc_html__('Call Us 7/24', 'visaland-core');
                        $info = isset($contact_info['visaland-footer-top-bar-contact-info']) ? $contact_info['visaland-footer-top-bar-contact-info'] : '';
                        $url  = isset($contact_info['visaland-footer-top-bar-contact-url']) ? $contact_info['visaland-footer-top-bar-contact-url'] : '#';
                        ?>

                        <div class="contact-info-items wow fadeInUp" data-wow-delay=".3s">
                            <div class="icon">
                                <i class="<?php echo esc_attr($icon); ?>"></i>
                            </div>
                            <div class="content">
                                <p><?php echo esc_html($text); ?></p>
                                <h3>
                                    <a href="<?php echo esc_url($url); ?>"><?php echo esc_html($info); ?></a>
                                </h3>
                            </div>
                        </div>

                        <?php
                    }

                    echo '</div>';
                }
            } elseif ($selected_option === 'option-2') {

                $logo = isset($instance['footer-3-widget-logo']) ? wp_get_attachment_image_src($instance['footer-3-widget-logo']['id'], 'full') : '';

                echo '<div class="footer-top">';

                if (!empty($logo)) {
                    ?>
                    <div class="footer-logo wow fadeInUp" data-wow-delay=".3s">
                        <a href="<?php echo esc_url(home_url('/')); ?>">
                            <img src="<?php echo esc_url($logo[0]); ?>" alt="<?php echo esc_attr__('Footer Logo', 'visaland-core'); ?>">
                        </a>
                    </div>
                    <?php
                }

                // Display social icons

                if (!empty($contact_infos)) {
                    echo '<ul class="wow fadeInUp" data-wow-delay=".5s">';
                    foreach ($contact_infos as $contact_info) {
                        // Extract individual fields from the repeater
                        $icon = isset($contact_info['visaland-footer-top-bar-contact-icon']) ? $contact_info['visaland-footer-top-bar-contact-icon'] : 'fa fa-phone';
                        $text = isset($contact_info['visaland-footer-top-bar-contact-text']) ? $contact_info['visaland-footer-top-bar-contact-text'] : esc_html__('Call Us 7/24', 'visaland-core');
                        $info = isset($contact_info['visaland-footer-top-bar-contact-info']) ? $contact_info['visaland-footer-top-bar-contact-info'] : '';
                        $url = isset($contact_info['visaland-footer-top-bar-contact-url']) ? $contact_info['visaland-footer-top-bar-contact-url'] : '#';
        
                        // Output the social icon and its corresponding link
                        echo '<li>';
                        echo '<i class="' . esc_attr($icon) . '"></i>';
                        echo '<a href="' . esc_url($url) . '">' . esc_html($text) . '</a>';
                        echo '</li>';
                    }
                    echo '</ul>';
                }
                
                echo '</div>';

                ?>  
               
                <?php
            }

            echo $args['after_widget'];
        }
    }
}
?>
