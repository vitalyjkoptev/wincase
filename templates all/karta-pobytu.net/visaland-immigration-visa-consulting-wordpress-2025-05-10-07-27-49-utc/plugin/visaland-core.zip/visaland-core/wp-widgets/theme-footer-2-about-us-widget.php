<?php
/**
 * Theme Footer 2 About Us Widget
 * @package Visaland
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit(); // Exit if accessed directly
}

// Check if Codestar Framework is active
if (class_exists('CSF')) {

    // Create an About Us Widget using Codestar Framework
    CSF::createWidget('visaland_footer_2_about_widget', array(
        'title'       => esc_html__('Visaland: Footer Two About Us', 'visaland-core'),
        'classname'   => 'visaland-widget-about',
        'description' => esc_html__('Display about us widget', 'visaland-core'),
        'fields'      => array(
            array(
                'id'    => 'logo-area',
                'type'  => 'media',
                'title' => esc_html__('Upload Logo', 'visaland-core'),
            ),
            array(
                'id'      => 'description',
                'type'    => 'textarea',
                'title'   => esc_html__('Description', 'Visaland-core'),
                'default' => esc_html__('Quis autem veumure repreh volu tate velit esse niholestiae conseua veillum dolorem eum fugiat voluta.', 'visaland-core'),
            ),
            array(
                'id'    => 'visaland-footer-social-icon-repeater',
                'type'  => 'repeater',
                'title' => esc_html__('Social Icon', 'visaland-core'),
                'fields' => array(
                    array(
                        'id'      => 'visaland-footer-social-icon',
                        'type'    => 'icon',
                        'title'   => esc_html__('Icon', 'visaland-core'),
                        'default' => 'fab fa-facebook-f',
                    ),
                    array(
                        'id'      => 'visaland-footer-social-url',
                        'type'    => 'text',
                        'title'   => esc_html__('Enter Your Url', 'visaland-core'),
                        'default' => '#',
                    ),
                ),
            ),
        ),
    ));

    // Widget Output Function
    if (!function_exists('visaland_footer_2_about_widget')) {
        function visaland_footer_2_about_widget($args, $instance)
        {
            // Output the widget's before widget markup
            echo $args['before_widget'];

            // Retrieve the logo and other fields
            $logo = $instance['logo-area'];
            $img_id = $logo['id'] ?? '';
            $img_print = $img_id ? wp_get_attachment_image_src($img_id, 'full')[0] : '';
            $alt_text = get_post_meta($img_id, '_wp_attachment_image_alt', true);
            $paragraph = $instance['description'] ?? '';

            // Retrieve the social icons
            $socialIcons = is_array($instance['visaland-footer-social-icon-repeater']) && !empty($instance['visaland-footer-social-icon-repeater']) ? $instance['visaland-footer-social-icon-repeater'] : [];

            ?>

            <div class="single-footer-widget">
                <div class="widget-head">
                    <?php if ($img_print) : ?>
                        <a href="<?php echo esc_url(home_url('/')); ?>">
                            <img src="<?php echo esc_url($img_print); ?>" alt="<?php echo esc_attr($alt_text); ?>">
                        </a>
                    <?php endif; ?>
                </div>
                <div class="footer-content">
                    <p>
                        <?php echo esc_html($paragraph); ?>
                    </p>
                    <?php if (!empty($socialIcons)) : ?>
                        <div class="social-icon d-flex align-items-center">
                            <?php foreach ($socialIcons as $iconItem) : 
                                $icon = isset($iconItem['visaland-footer-social-icon']) ? $iconItem['visaland-footer-social-icon'] : 'fab fa-facebook-f';
                                $url = isset($iconItem['visaland-footer-social-url']) ? $iconItem['visaland-footer-social-url'] : '#';
                            ?>
                                <a href="<?php echo esc_url($url); ?>">
                                    <i class="<?php echo esc_attr($icon); ?>"></i>
                                </a>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <?php

            // Output the widget's after widget markup
            echo $args['after_widget'];
        }
    }

}

?>
