<?php
/**
 * Theme Footer 2 Gallery Widget
 * @package Visaland
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit(); // Exit if accessed directly
}

// Check if Codestar Framework is active
if (class_exists('CSF')) {

    // Create a Gallery Widget using Codestar Framework
    CSF::createWidget('visaland_footer_gallery_widget', array(
        'title'       => esc_html__('Visaland: Footer Gallery', 'visaland-core'),
        'classname'   => 'visaland-widget-gallery',
        'description' => esc_html__('Display gallery widget', 'visaland-core'),
        'fields'      => array(
            array(
                'id'      => 'gallery-title',
                'type'    => 'text',
                'title'   => esc_html__('Title', 'visaland-core'),
                'default' => esc_html__('Instagram', 'visaland-core'),
            ),
            array(
                'id'    => 'visaland-footer-gallery-repeater',
                'type'  => 'repeater',
                'title' => esc_html__('Gallery Images', 'visaland-core'),
                'fields' => array(
                    array(
                        'id'    => 'image-area',
                        'type'  => 'media',
                        'title' => esc_html__('Upload Image', 'visaland-core'),
                    ),
                ),
            ),
        ),
    ));

    // Widget Output Function
    if (!function_exists('visaland_footer_gallery_widget')) {
        function visaland_footer_gallery_widget($args, $instance)
        {
            // Output the widget's before widget markup
            echo $args['before_widget'];

            // Retrieve the title
            $galleryTitle = $instance['gallery-title'] ?? esc_html__('Instagram', 'visaland-core');

            // Retrieve the gallery images
            $galleryImages = is_array($instance['visaland-footer-gallery-repeater']) && !empty($instance['visaland-footer-gallery-repeater']) ? $instance['visaland-footer-gallery-repeater'] : [];

            ?>

            <div class="widget-head">
                <h5><?php echo esc_html($galleryTitle); ?></h5>
            </div>
            <div class="footer-gallery">
                <div class="gallery-wrap">
                    <div class="gallery-item">
                    <?php if (!empty($galleryImages)) : ?>
                        <?php foreach ($galleryImages as $galleryItem) :
                            $image = $galleryItem['image-area'];
                            $image_url = isset($image['url']) ? $image['url'] : '';
                            $image_id = isset($image['id']) ? $image['id'] : '';
                            $image_alt = $image_id ? get_post_meta($image_id, '_wp_attachment_image_alt', true) : 'gallery-img';
                        ?>
                            
                            <div class="thumb">
                                <a href="<?php echo esc_url($image_url); ?>" class="img-popup">
                                    <img src="<?php echo esc_url($image_url); ?>" alt="<?php echo esc_attr($image_alt); ?>">
                                    <div class="icon">
                                        <i class="far fa-plus"></i>
                                    </div>
                                </a>
                            </div>
                    
                        <?php endforeach; ?>
                    <?php endif; ?>
                    </div>
                </div>
            </div>

            <?php

            // Output the widget's after widget markup
            echo $args['after_widget'];
        }
    }

}

?>
