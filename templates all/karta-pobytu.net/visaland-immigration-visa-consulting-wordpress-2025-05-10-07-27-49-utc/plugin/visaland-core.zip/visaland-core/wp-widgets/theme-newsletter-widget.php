<?php
/**
 * Theme Newsletter Widget
 * @package Visaland
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit(); // Exit if accessed directly
}

// Check if Codestar Framework is active
if (class_exists('CSF')) {

    // Create the Newsletter Widget using Codestar Framework
    CSF::createWidget('visaland_newsletter_widget', array(
        'title'       => esc_html__('Visaland: Newsletter', 'visaland-core'),
        'classname'   => 'visaland-widget-newsletter',
        'description' => esc_html__('Display newsletter widget', 'visaland-core'),
        'fields'      => array(
            array(
                'id'          => 'opt-select-1',
                'type'        => 'select',
                'title'       => esc_html__('Select Styles', 'visaland-core'),
                'chosen'      => true,
                'placeholder' => 'Select an option',
                'options'     => array(
                    'option-1'  => 'Option 1',
                    'option-2'  => 'Option 2',
                ),
                'default'     => 'option-1',
            ),
            array(
                'id'      => 'newsletter-title',
                'type'    => 'text',
                'title'   => esc_html__('Title', 'visaland-core'),
                'default' => esc_html__('Newsletters', 'visaland-core'),
            ),
            array(
                'id'      => 'newsletter-description',
                'type'    => 'textarea',
                'title'   => esc_html__('Description', 'visaland-core'),
                'default' => esc_html__('Sign Up For News & Get 30% Off Your Next Course.', 'visaland-core'),
            ),
            array(
                'id'    => 'shortcode',
                'type'  => 'text',
                'title' => esc_html__('Shortcode', 'visaland-core'),
            ),
            array(
                'id'    => 'footer-privacy-policy',
                'type'  => 'text',
                'title' => esc_html__('Privacy Policy', 'visaland-core'),
                'default' => esc_html__('By subscribing, you’re accepting <a href="#">Privacy Policy</a>', 'visaland-core'),
            ),
        ),
    ));

    // Widget Output Function
    if (!function_exists('visaland_newsletter_widget')) {
        function visaland_newsletter_widget($args, $instance)
        {
            // Output the widget's before widget markup
            echo $args['before_widget'];

            // Retrieve the fields
            $title       = $instance['newsletter-title'] ?? '';
            $description = $instance['newsletter-description'] ?? '';
            $shortcode   = $instance['shortcode'] ?? '';
            $select_style = $instance['opt-select-1'] ?? 'option-1';

            // Check the selected style and render the appropriate output
            if ($select_style === 'option-1') {
                ?>

                <!-- Option 1 -->
                <div class="widget-head">
                    <h5><?php echo esc_html($title); ?></h5>
                </div>
                <div class="footer-content">
                    <p><?php echo esc_html($description); ?></p>
                    <div class="footer-input">
                        <?php echo do_shortcode($shortcode); ?>
                    </div>
                </div>

                <?php
            } elseif ($select_style === 'option-2') {
                ?>

                <!-- Option 2 -->
                <div class="single-footer-widget me-4">
                    <div class="widget-head">
                        <h3><?php echo esc_html($title); ?></h3>
                    </div>
                    <div class="footer-content">
                        <p>
                            <?php echo wp_kses_post($description); ?>
                        </p>
                       
                        <?php echo do_shortcode($shortcode); ?>
                     
                        <h6 class="label-text">
                            <?php echo wp_kses_post($instance['footer-privacy-policy']); ?>
                        </h6>
                    </div>
                </div>

                <?php
            }

            // Output the widget's after widget markup
            echo $args['after_widget'];
        }
    }
}

?>
