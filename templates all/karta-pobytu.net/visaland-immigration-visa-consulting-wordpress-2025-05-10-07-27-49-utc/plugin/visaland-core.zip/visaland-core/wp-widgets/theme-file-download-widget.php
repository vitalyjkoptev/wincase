<?php
/**
 * Theme File Download Widget
 * @package Visaland
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit(); //exit if access directly
}
// Control core classes for avoid errors
if (class_exists('CSF')) {


    // Create a About Widget
    CSF::createWidget('visaland_file_download_widget', array(
        'title' => esc_html__('Visaland: File Download', 'visaland-core'),
        'classname' => 'visaland-widget-file-download',
        'description' => esc_html__('Display File Download widget', 'visaland-core'),
        'fields' => array(
            array(
                'id' => 'title',
                'type' => 'text',
                'title' => esc_html__('Title', 'Visaland-core'),
                'default' => esc_html__('Download', 'visaland-core')
            ),

            array(
                'id' => 'visaland-file-download-repeater',
                'type' => 'repeater',
                'title' => esc_html__('File Download', 'visaland-core'),
                'fields' => array(
                    array(
                        'id' => 'visaland-file-download',
                        'type' => 'media',
                        'title' => esc_html__('File', 'visaland-core'),
                    ),
                    array(
                        'id' => 'visaland-file-download-text',
                        'type' => 'text',
                        'title' => esc_html__('File Text', 'visaland-core'),
                        'default' => esc_html__('Company Profile', 'visaland-core')
                    ),

                ),
            ),
        )
    ));


    if (!function_exists('visaland_file_download_widget')) {
        function visaland_file_download_widget($args, $instance)
        {

            echo $args['before_widget'];

            $title = $instance['title'] ?? '';
            $file_download = is_array($instance['visaland-file-download-repeater']) && !empty($instance['visaland-file-download-repeater']) ? $instance['visaland-file-download-repeater'] : [];


            ?>
            <div class="widget_download">
                <h5 class="widget-headline style-01"><?php echo esc_html($title); ?></h5>               
                <ul>
                    <?php
                        foreach ($file_download as $file) {
                            echo '<li class="mb-0 mt-0">
                                <a download href="'.$file['visaland-file-download']['url'].'">
                                    ' . $file['visaland-file-download-text'] . '
                                    <i class="fa fa-angle-double-right"></i>
                                </a>
                            </li>';
                        };
                    ?>
                </ul>
            </div>
            <?php

            echo $args['after_widget'];

        }
    }

}

?>