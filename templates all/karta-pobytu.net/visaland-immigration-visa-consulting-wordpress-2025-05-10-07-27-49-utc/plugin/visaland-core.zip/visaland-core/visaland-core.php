<?php
/*
Plugin Name: Visaland Core
Plugin URI: https://modinatheme.com/visaland/
Description: Plugin to contain short codes and custom post types of the Visaland theme.
Author: modinatheme
Author URI: https://themeforest.net/user/modinatheme/portfolio
Version: 1.1.0
Text Domain: visaland-core
*/

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}


/**
 * Plugin directory path
 * @package visaland
 * @since 1.0.0
 */
define( 'VISALAND_CORE_ROOT_PATH', plugin_dir_path( __FILE__ ) );
define( 'VISALAND_CORE_ROOT_URL', plugin_dir_url( __FILE__ ) );
define( 'VISALAND_CORE_SELF_PATH', 'visaland-core/visaland-core.php' );
define( 'VISALAND_CORE_VERSION', '2.0.1' );
define( 'VISALAND_CORE_INC', VISALAND_CORE_ROOT_PATH .'/inc');
define( 'VISALAND_CORE_LIB', VISALAND_CORE_ROOT_PATH .'/lib');
define( 'VISALAND_CORE_ELEMENTOR', VISALAND_CORE_ROOT_PATH .'/elementor');
define( 'VISALAND_CORE_DEMO_IMPORT', VISALAND_CORE_ROOT_PATH .'/demo-import');
define( 'VISALAND_CORE_ADMIN', VISALAND_CORE_ROOT_PATH .'/admin');
define( 'VISALAND_CORE_ADMIN_ASSETS', VISALAND_CORE_ROOT_URL .'admin/assets');
define( 'VISALAND_CORE_WP_WIDGETS', VISALAND_CORE_ROOT_PATH .'/wp-widgets');
define( 'VISALAND_CORE_ASSETS', VISALAND_CORE_ROOT_URL .'assets/');
define( 'VISALAND_CORE_CSS', VISALAND_CORE_ASSETS .'css');
define( 'VISALAND_CORE_JS', VISALAND_CORE_ASSETS .'js');
define( 'VISALAND_CORE_IMG', VISALAND_CORE_ASSETS .'img');


/**
 * Load additional helpers functions
 * @package visaland
 * @since 1.0.0
 */
if (!function_exists('visaland_core')){
	require_once VISALAND_CORE_INC .'/theme-core-helper-functions.php';
	if (!function_exists('visaland_core')){
		function visaland_core(){
			return class_exists('Visaland_Core_Helper_Functions') ? new Visaland_Core_Helper_Functions() : false;
		}
	}
}
//ob flash
remove_action( 'shutdown', 'wp_ob_end_flush_all', 1 );


/**
 * Load Codestar Framework Functions
 * @package visaland
 * @since 1.0.0
 */
if ( !visaland_core()->is_visaland_active()) {
	if ( file_exists( VISALAND_CORE_ROOT_PATH . '/inc/csf-functions.php' ) ) {
		require_once VISALAND_CORE_ROOT_PATH . '/inc/csf-functions.php';
	}
}



/**
 * Core Plugin Init
 * @package visaland
 * @since 1.0.0
 */
if ( file_exists( VISALAND_CORE_ROOT_PATH . '/inc/theme-core-init.php' ) ) {
	require_once VISALAND_CORE_ROOT_PATH . '/inc/theme-core-init.php';
}