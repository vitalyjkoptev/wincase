<?php
namespace Elementor;

/**
 * Elementor Widget
 * @package Visaland
 * @since 1.0.0
 */ 
 
class Project_Grid extends Widget_Base {

	/**
	 * Get widget name.
	 * Retrieve button widget name.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'visaland-project-grid-widget';
	}

	/**
	 * Get widget title.
	 * Retrieve button widget title.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Project Grid', 'visaland-core' );
	}

	/**
	 * Get widget icon.
	 * Retrieve button widget icon.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-flash';
	}

	/**
	 * Get widget categories.
	 * Retrieve the list of categories the button widget belongs to.
	 * Used to determine where to display the widget in the editor.
	 *
	 * @since  2.0.0
	 * @access public
	 * @return array Widget categories.
	 */
	public function get_categories()
    {
        return ['visaland_widgets'];
    }
	
	/**
	 * Register button widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function register_controls() {

		// Tab Start - 1

		$this->start_controls_section(
			'project_grid',
			[
				'label' => esc_html__( 'Project Grid', 'visaland-core' ),
			]
		);		
		
		$this->add_control(
			'style',
			[
				'label'   => esc_html__( 'Select Style', 'visaland-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'style1',
				'options' => array(
					'style1'   => esc_html__( 'Style One', 'visaland-core' ),
					'style2'   => esc_html__( 'Style Two', 'visaland-core' ),
				),
			]
		);

		$this->add_control('service_grid', [
			'label' => esc_html__('Column Grid', 'visaland-core'),
			'type' => Controls_Manager::SELECT,
			'options' => array(
				'col-lg-2' => esc_html__('col-lg-2', 'visaland-core'),
				'col-lg-3' => esc_html__('col-lg-3', 'visaland-core'),
				'col-lg-4' => esc_html__('col-lg-4', 'visaland-core'),
				'col-lg-6' => esc_html__('col-lg-6', 'visaland-core'),
			),
			'default' => 'col-lg-3',
			'description' => esc_html__('Select Grid', 'visaland-core')
		]);

		$this->end_controls_section();

		// Tab Start - 2

		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Block', 'visaland-core' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
		  'repeat', 
			[
				'type' => Controls_Manager::REPEATER,
				'separator' => 'before',
				'default' => 
					[
						['block_title' => esc_html__('Hello World', 'visaland-core')],
					],
				'fields' => 
					[						

						'block_image' =>
						[
							'name' => 'block_image',
							'label' => __( 'Image', 'visaland-core' ),
							'type' => Controls_Manager::MEDIA,
							'default' => ['url' => Utils::get_placeholder_image_src(),],
						],	

						'block_alt_text' =>
						[
						'name' => 'block_alt_text',
						'label' => esc_html__('Image Text', 'visaland-core'),
						'type' => Controls_Manager::TEXTAREA,
						'default' => esc_html__('', 'visaland-core')
						],	

						'block_title' =>
						[
							'name' => 'block_title',
							'label' => esc_html__('Title', 'visaland-core'),
							'type' => Controls_Manager::TEXTAREA,
							'default' => esc_html__('', 'visaland-core')
						],

						'block_subtitle' =>
						[
							'name' => 'block_subtitle',
							'label' => esc_html__('Sub Title', 'visaland-core'),
							'type' => Controls_Manager::TEXTAREA,
							'default' => esc_html__('', 'visaland-core')
						],

						'block_text' =>
						[
							'name' => 'block_text',
							'label' => esc_html__('Text', 'visaland-core'),
							'type' => Controls_Manager::TEXTAREA,
							'default' => esc_html__('', 'visaland-core')
						],					

						'block_button' =>
						[
							'name' => 'block_button',
							'label'       => __( 'Button', 'visaland-core' ),
							'type'        => Controls_Manager::TEXT,
							'dynamic'     => [
								'active' => true,
							],
							'placeholder' => __( 'Enter your Button Title', 'visaland-core' ),
							'default' => esc_html__('Read More', 'visaland-core'),
						],
						
						'block_button_link' =>
						[
						  'name' => 'block_button_link',
						  'label' => __( 'Button Url', 'visaland-core' ),
						  'type' => Controls_Manager::URL,
						  'placeholder' => __( 'https://your-link.com', 'visaland-core' ),
						  'show_external' => true,
						  'default' => [
							'url' => '',
							'is_external' => true,
							'nofollow' => true,
						  ],
					   ],
						
					],
				'title_field' => '{{block_title}}',
			 ]
	);
		
		
	$this->end_controls_section();	

	
		}

	/**
	 * Render button widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$allowed_tags = wp_kses_allowed_html('post');
		?>

<?php
	  echo '
	 <script>
 jQuery(document).ready(function($) {

// js code start


// js code end 

  });
</script>';


?>

<?php  if ( 'style1' === $settings['style'] ) : ?>	

	<div class="row">
		<?php foreach($settings['repeat'] as $item):?>	
		<div class="<?php echo esc_attr($settings['service_grid']); ?> col-md-6 wow fadeInUp" data-wow-delay=".2s">
			<div class="coaching-box-items">
				<div class="coaching-image">
					<?php if(!empty(wp_get_attachment_url($item['block_image']['id']))): ?>
						<img src="<?php echo wp_get_attachment_url($item['block_image']['id']);?>" alt="<?php echo wp_kses($item['block_alt_text'], $allowed_tags);?>">
						<img src="<?php echo wp_get_attachment_url($item['block_image']['id']);?>" alt="<?php echo wp_kses($item['block_alt_text'], $allowed_tags);?>">
					<?php endif;?>
					<a href="<?php echo esc_url($item['block_button_link']['url']);?>" class="image-overlay">
						<i class="fal fa-plus"></i>
					</a>
					<h5 class="price"><?php echo wp_kses($item['block_subtitle'], $allowed_tags);?></h5>
				</div>
				<div class="content">
					<h4><a href="<?php echo esc_url($item['block_button_link']['url']);?>"><?php echo wp_kses($item['block_title'], $allowed_tags);?></a></h4>
					<p>
						<?php echo wp_kses($item['block_text'], $allowed_tags);?>
					</p>
					<a href="<?php echo esc_url($item['block_button_link']['url']);?>" class="link-btn link-btn-2">
						<span><?php echo wp_kses($item['block_button'], $allowed_tags);?></span>
						<i class="fas fa-chevron-right"></i>
					</a>
				</div>
			</div>
		</div>
		<?php endforeach; ?>
	</div>

<?php  elseif ( 'style2' === $settings['style'] ) : ?>		

<!-- not used -->

	<div class="row">
		<?php foreach($settings['repeat'] as $item):?>	
		<div class="<?php echo esc_attr($settings['service_grid']); ?> col-md-6 wow fadeInUp" data-wow-delay=".2s">
			<div class="coaching-box-items">
				<div class="coaching-image">
					<?php if(!empty(wp_get_attachment_url($item['block_image']['id']))): ?>
						<img src="<?php echo wp_get_attachment_url($item['block_image']['id']);?>" alt="<?php echo wp_kses($item['block_alt_text'], $allowed_tags);?>">
						<img src="<?php echo wp_get_attachment_url($item['block_image']['id']);?>" alt="<?php echo wp_kses($item['block_alt_text'], $allowed_tags);?>">
					<?php endif;?>
					<a href="<?php echo esc_url($item['block_button_link']['url']);?>" class="image-overlay">
						<i class="fal fa-plus"></i>
					</a>
					<h5 class="price"><?php echo wp_kses($item['block_subtitle'], $allowed_tags);?></h5>
				</div>
				<div class="content">
					<h4><a href="<?php echo esc_url($item['block_button_link']['url']);?>"><?php echo wp_kses($item['block_title'], $allowed_tags);?></a></h4>
					<p>
						<?php echo wp_kses($item['block_text'], $allowed_tags);?>
					</p>
					<a href="<?php echo esc_url($item['block_button_link']['url']);?>" class="link-btn link-btn-2">
						<span><?php echo wp_kses($item['block_button'], $allowed_tags);?></span>
						<i class="fas fa-chevron-right"></i>
					</a>
				</div>
			</div>
		</div>
		<?php endforeach; ?>
	</div>

<?php endif ;?>	

             
		<?php 
	}


}

Plugin::instance()->widgets_manager->register_widget_type(new Project_Grid());