<?php
namespace Elementor;

/**
 * Elementor Widget
 * @package Visaland
 * @since 1.0.0
 */ 
 
class Service_Sidebar extends Widget_Base {

	/**
	 * Get widget name.
	 * Retrieve button widget name.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'visaland-service-sidebar-widget';
	}

	/**
	 * Get widget title.
	 * Retrieve button widget title.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Service Sidebar', 'visaland-core' );
	}

	/**
	 * Get widget icon.
	 * Retrieve button widget icon.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-flash';
	}

	/**
	 * Get widget categories.
	 * Retrieve the list of categories the button widget belongs to.
	 * Used to determine where to display the widget in the editor.
	 *
	 * @since  2.0.0
	 * @access public
	 * @return array Widget categories.
	 */
	public function get_categories()
    {
        return ['visaland_widgets'];
    }
	
	/**
	 * Register button widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function register_controls() {

		// Tab Start - 1

		$this->start_controls_section(
			'service-sidebar',
			[
				'label' => esc_html__( 'Service Sidebar', 'visaland-core' ),
			]
		);		
		
		$this->add_control(
			'style',
			[
				'label'   => esc_html__( 'Select Style', 'visaland-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'style1',
				'options' => array(
					'style1'   => esc_html__( 'Style One', 'visaland-core' ),
					'style2'   => esc_html__( 'Style Two', 'visaland-core' ),
					'style3'   => esc_html__( 'Style Three', 'visaland-core' ),
				),
			]
		);

		$this->add_control(
			'bg_image',
			[
				'label' => esc_html__('Background image', 'visaland-core'),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
		);	

		$this->add_control(
			'subtitle',
			[
				'label'       => __( 'Sub Title', 'visaland-core' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your sub title', 'visaland-core' ),
			]
		);

		$this->add_control(
			'title',
			[
				'label'       => __( 'Title', 'visaland-core' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your title', 'visaland-core' ),
			]
		);

		$this->add_control(
			'text',
			[
				'label'       => __( 'Description Text', 'visaland-core' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter Your Text', 'visaland-core' ),
			]
		);

		$this->add_control(
			'button_link',
			[
			  'label' => __( 'Button Url', 'visaland-core' ),
			  'type' => Controls_Manager::URL,
			  'placeholder' => __( 'https://your-link.com', 'visaland-core' ),
			  'show_external' => true,
			  'default' => [
				'url' => '',
				'is_external' => true,
				'nofollow' => true,
			  ],
			
		   ]
		);

		$this->add_control(
			'button',
			[
				'label'       => __( 'Button', 'visaland-core' ),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => esc_html__( 'Enter your button text', 'visaland-core' ),
				'default' => esc_html__('Read More', 'visaland-core'),
			]
		);	

	$this->add_control(
			'button_link2',
			[
			  'label' => __( 'Button Url', 'visaland-core' ),
			  'type' => Controls_Manager::URL,
			  'placeholder' => __( 'https://your-link.com', 'visaland-core' ),
			  'show_external' => true,
			  'default' => [
				'url' => '',
				'is_external' => true,
				'nofollow' => true,
			  ],
			
		   ]
		);

		$this->add_control(
			'button2',
			[
				'label'       => __( 'Button', 'visaland-core' ),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => esc_html__( 'Enter your button text', 'visaland-core' ),
				'default' => esc_html__('Read More', 'visaland-core'),
			]
		);	

	$this->add_control(
			'button_link3',
			[
			  'label' => __( 'Button Url', 'visaland-core' ),
			  'type' => Controls_Manager::URL,
			  'placeholder' => __( 'https://your-link.com', 'visaland-core' ),
			  'show_external' => true,
			  'default' => [
				'url' => '',
				'is_external' => true,
				'nofollow' => true,
			  ],
			
		   ]
		);

		$this->add_control(
			'contact_form',
			[
				'label'       => __( 'Contact Form 7 Url', 'visaland-core' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Contact Form 7 Url', 'visaland-core' ),
				'default'     => __( '', 'visaland-core' ),
			]
		);

		$this->end_controls_section();

		// Tab Start - 2

		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Block', 'visaland-core' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
		  'repeat', 
			[
				'type' => Controls_Manager::REPEATER,
				'separator' => 'before',
				'default' => 
					[
						['block_title' => esc_html__('Hello World', 'visaland-core')],
					],
				'fields' => 
					[	
						'block_title' =>
						[
							'name' => 'block_title',
							'label' => esc_html__('Title', 'visaland-core'),
							'type' => Controls_Manager::TEXTAREA,
							'default' => esc_html__('', 'visaland-core')
						],
						
						'block_button_link' =>
						[
						  'name' => 'block_button_link',
						  'label' => __( 'Button Url', 'visaland-core' ),
						  'type' => Controls_Manager::URL,
						  'placeholder' => __( 'https://your-link.com', 'visaland-core' ),
						  'show_external' => true,
						  'default' => [
							'url' => '',
							'is_external' => true,
							'nofollow' => true,
						  ],
					   ],
						
					],
				'title_field' => '{{block_title}}',
			 ]
	);
		
		
	$this->end_controls_section();	

	
		}

	/**
	 * Render button widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$allowed_tags = wp_kses_allowed_html('post');
		?>

<?php  if ( 'style1' === $settings['style'] ) : ?>	

	<div class="visa-details-wrapper">
		<div class="visa-sidebar">
			<div class="visa-widget-categories">
				<ul>
					<?php foreach($settings['repeat'] as $item):?>	
					<li><a href="<?php echo esc_url($item['block_button_link']['url']);?>"><?php echo wp_kses($item['block_title'], $allowed_tags);?><span><i class="fas fa-chevron-right"></i></span></a></li>
					<?php endforeach; ?>
				</ul>
			</div>

			<?php if($settings['title']): ?>
			<div class="visa-sidebar-widget">
				<div class="contact-bg text-center bg-cover" style="background-image: url('<?php echo wp_get_attachment_url($settings['bg_image']['id']);?>');">
					<h4><?php echo $settings['subtitle'];?></h4>
					<h3><a href="<?php echo esc_url($settings['button_link']['url']);?>"><?php echo $settings['title'];?></a></h3>
					<p><?php echo $settings['text'];?></p>
					<a href="<?php echo esc_url($settings['button_link2']['url']);?>" class="theme-btn bg-white">
						<span>
						<?php echo $settings['button'];?>
							<i class="fas fa-chevron-right"></i>
						</span>
					</a>
				</div>
			</div>
			<?php endif; ?>

			<?php if($settings['button2']): ?>
			<a href="<?php echo esc_url($settings['button_link3']['url']);?>" class="theme-btn w-100 text-center">
				<span><i class="fas fa-file-pdf me-3"></i> <?php echo $settings['button2'];?></span>
			</a>
			<?php endif; ?>

		</div>
	</div>

	<?php  elseif ( 'style2' === $settings['style'] ) : ?>	

		<div class="coaching-details-wrapper">
			<div class="country-sidebar">
				<div class="single-contact-form">
					<h3 class="wid-title">
						Quick Contact
					</h3>
						<?php echo do_shortcode( $settings['contact_form'] );?>
					</div>

					<?php if($settings['title']): ?>
					<div class="country-sidebar-widget">
						<div class="contact-bg bg-cover" style="background-image: url('<?php echo wp_get_attachment_url($settings['bg_image']['id']);?>');">
							<h3><?php echo $settings['subtitle'];?></h3>
							<h2><?php echo $settings['title'];?></h2>

							<a href="<?php echo esc_url($settings['button_link2']['url']);?>" class="theme-btn bg-white">
								<span>
								<?php echo $settings['button'];?>
									<i class="fas fa-chevron-right"></i>
								</span>
							</a>

						</div>
					</div>
					<?php endif; ?>

					<?php if($settings['button2']): ?>
					<a href="<?php echo esc_url($settings['button_link3']['url']);?>" class="theme-btn w-100 text-center">
						<span><i class="fas fa-file-pdf me-3"></i> <?php echo $settings['button2'];?></span>
					</a>
					<?php endif; ?>
					
				</div>
			</div>

	<?php endif ;?>	


             
		<?php 
	}


}

Plugin::instance()->widgets_manager->register_widget_type(new Service_Sidebar());