<?php
namespace Elementor;

/**
 * Elementor Widget
 * @package Visaland
 * @since 1.0.0
 */ 
 
class Free_Consulting extends Widget_Base {

	/**
	 * Get widget name.
	 * Retrieve button widget name.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'visaland-free-consulting-widget';
	}

	/**
	 * Get widget title.
	 * Retrieve button widget title.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Free Consulting', 'visaland-core' );
	}

	/**
	 * Get widget icon.
	 * Retrieve button widget icon.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-site-title';
	}

	/**
	 * Get widget categories.
	 * Retrieve the list of categories the button widget belongs to.
	 * Used to determine where to display the widget in the editor.
	 *
	 * @since  2.0.0
	 * @access public
	 * @return array Widget categories.
	 */
	public function get_categories()
    {
        return ['visaland_widgets'];
    }
	
	/**
	 * Register button widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function register_controls() {

		// Tab Start - 1

		$this->start_controls_section(
			'free_consulting',
			[
				'label' => esc_html__( 'Free consulting', 'visaland-core' ),
			]
		);	
		

		$this->add_control(
			'image',
				[
				  'label' => __( 'Image', 'visaland-core' ),
				  'type' => Controls_Manager::MEDIA,
				  'default' => ['url' => Utils::get_placeholder_image_src(),],
				]
		);	
		
		$this->add_control(
			'alt_text',
			[
				'label'       => __( 'Alt text', 'visaland-core' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter Your Text', 'visaland-core' ),
			]
		);

		$this->add_control(
			'bg_image',
			[
				'label' => esc_html__('Background image', 'visaland-core'),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
		);	

		$this->add_control(
			'subtitle',
			[
				'label'       => __( 'Sub Title', 'visaland-core' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your sub title', 'visaland-core' ),
			]
		);
	
		$this->add_control(
				'title',
				[
					'label'       => __( 'Title', 'visaland-core' ),
					'type'        => Controls_Manager::TEXTAREA,
					'dynamic'     => [
						'active' => true,
					],
					'placeholder' => __( 'Enter your title', 'visaland-core' ),
				]
			);

			$this->add_control(
				'text',
				[
					'label'       => __( 'Description Text', 'visaland-core' ),
					'type'        => Controls_Manager::TEXTAREA,
					'dynamic'     => [
						'active' => true,
					],
					'placeholder' => __( 'Enter Your Text', 'visaland-core' ),
				]
			);

			$this->add_control(
				'button',
				[
					'label'       => __( 'Button', 'visaland-core' ),
					'type'        => Controls_Manager::TEXT,
					'dynamic'     => [
						'active' => true,
					],
					'placeholder' => esc_html__( 'Enter your button text', 'visaland-core' ),
					'default' => esc_html__('Read More', 'visaland-core'),
				]
			);	
		
	//Link
	
		$this->add_control(
				'button_link',
				[
				  'label' => __( 'Button Url', 'visaland-core' ),
				  'type' => Controls_Manager::URL,
				  'placeholder' => __( 'https://your-link.com', 'visaland-core' ),
				  'show_external' => true,
				  'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				  ],
				
			   ]
			);
	//Link
	
		$this->add_control(
				'video_link',
				[
				  'label' => __( 'Video Url', 'visaland-core' ),
				  'type' => Controls_Manager::URL,
				  'placeholder' => __( 'https://your-link.com', 'visaland-core' ),
				  'show_external' => true,
				  'default' => [
					'url' => 'https://www.youtube.com/watch?v=Cn4G2lZ_g2I',
					'is_external' => true,
					'nofollow' => true,
				  ],
				
			   ]
			);	

		$this->end_controls_section();

	
		}

	/**
	 * Render button widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$allowed_tags = wp_kses_allowed_html('post');
		?>


<div class="single-it-service-provide fix">
	<div class="arrow-shape wow fadeInUp" data-wow-delay=".3s">
	<?php  if ( !empty(esc_url($settings['image']['id']) )) : ?>   
		<img src="<?php echo wp_get_attachment_url($settings['image']['id']);?>" alt="<?php echo esc_attr($settings['alt_text']);?>"/>
	<?php endif;?>
	</div>
	<div class="service-bg bg-cover" style="background-image: url('<?php echo wp_get_attachment_url($settings['bg_image']['id']);?>');">
		<div class="single-provide-content">
			<div class="section-content">
				<span class="wow fadeInUp sub-cont">
					<?php echo $settings['subtitle'];?>
				</span>
				<h2 class="title-anim">
					<?php echo $settings['title'];?>
				</h2>
				<p class="wow fadeInUp" data-wow-delay=".5s">
					<?php echo $settings['text'];?>
				</p>
				<a href="<?php echo esc_url($settings['button_link']['url']);?>" class="theme-btn bg-white wow fadeInUp" data-wow-delay=".7s">
					<span> <?php echo $settings['button'];?></span>
				</a>
			</div>
			<div class="video-btn video-pulse">
				<a class="video-popup" href="<?php echo esc_url($settings['video_link']['url']);?>"><i class="fas fa-play"></i></a>
			</div>
		</div>
	</div>
</div>


             
		<?php 
	}


}

Plugin::instance()->widgets_manager->register_widget_type(new Free_Consulting());