<?php
/**
 * Elementor Widget
 * @package Visaland
 * @since 1.0.0
 */

namespace Elementor;

class Blog_Post extends Widget_Base
{

    /**
     * Get widget name.
     *
     * Retrieve Elementor widget name.
     *
     * @return string Widget name.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_name()
    {
        return 'visaland-blog-post-widget';
    }

    /**
     * Get widget title.
     *
     * Retrieve Elementor widget title.
     *
     * @return string Widget title.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_title()
    {
        return esc_html__('Blog Post', 'visaland-core');
    }

    /**
     * Get widget icon.
     *
     * Retrieve Elementor widget icon.
     *
     * @return string Widget icon.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_icon()
    {
        return 'eicon-post';
    }

    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the Elementor widget belongs to.
     *
     * @return array Widget categories.
     * @since 1.0.0
     * @access public
     *
     */
    public function get_categories()
    {
        return ['visaland_widgets'];
    }

    /**
     * Register Elementor widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function register_controls()
    {

        $this->start_controls_section(
            'settings_section',
            [
                'label' => esc_html__('General Settings', 'visaland-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'style',
            [
                'label'   => esc_html__( 'Select Style', 'visaland-core' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'style1',
                'options' => array(
                    'style1'   => esc_html__( 'Style One', 'visaland-core' ),
                    'style2'   => esc_html__( 'Style Two', 'visaland-core' ),
                    'style3'   => esc_html__( 'Style Three', 'visaland-core' ),
                    'style4'   => esc_html__( 'Style Four', 'visaland-core' ),
                ),
            ]
        );
        
        $this->add_control('blog_grid', [
            'label' => esc_html__('Blog Grid', 'visaland-core'),
            'type' => Controls_Manager::SELECT,
            'options' => array(
                'col-lg-2' => esc_html__('col-lg-2', 'visaland-core'),
                'col-lg-3' => esc_html__('col-lg-3', 'visaland-core'),
                'col-lg-4' => esc_html__('col-lg-4', 'visaland-core'),
                'col-lg-6' => esc_html__('col-lg-6', 'visaland-core'),
                'col-lg-12' => esc_html__('col-lg-12', 'visaland-core'),
            ),
            'default' => 'col-lg-4',
            'description' => esc_html__('Select Blog Grid', 'visaland-core')
        ]);   
        
        $this->add_control(
			'button',
			[
				'label'       => __( 'Button', 'visaland-core' ),
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => esc_html__( 'Enter your button text', 'visaland-core' ),
				'default' => esc_html__('Read More', 'visaland-core'),
			]
		);	

        $this->add_control(
            'word_limit',
            [
                'label' => esc_html__('Word Limit', 'visaland-core'),
                'type' => Controls_Manager::NUMBER,
                'default' => 20,
                'description' => esc_html__('Set the number of words to display from the post content.', 'visaland-core'),
            ]
        );

        $this->add_control(
            'more_text',
            [
                'label' => esc_html__('More Text', 'visaland-core'),
                'type' => Controls_Manager::TEXT,
                'default' => '...',
                'description' => esc_html__('Set the text to append after the trimmed words, e.g., "Read More". Leave blank for no text.', 'visaland-core'),
            ]
        );
   
        $this->add_control('total', [
            'label' => esc_html__('Total Posts', 'visaland-core'),
            'type' => Controls_Manager::TEXT,
            'default' => '-1',
            'description' => esc_html__('enter how many post you want in masonry , enter -1 for unlimited post.')
        ]);
        $this->add_control('offset', [
            'label' => esc_html__('Offset Posts', 'visaland-core'),
            'type' => Controls_Manager::TEXT,
            'default' => '0',
            'description' => esc_html__('enter how many post you want in masonry , enter -1 for unlimited post.')
        ]);
        $this->add_control('category', [
            'label' => esc_html__('Category', 'visaland-core'),
            'type' => Controls_Manager::SELECT2,
            'multiple' => true,
            'options' => visaland_core()->get_terms_names('category', 'id'),
            'description' => esc_html__('Select category as you want, leave it blank for all categories', 'visaland-core'),
        ]);        

        $this->add_control('order', [
            'label' => esc_html__('Order', 'visaland-core'),
            'type' => Controls_Manager::SELECT,
            'options' => array(
                'ASC' => esc_html__('Ascending', 'visaland-core'),
                'DESC' => esc_html__('Descending', 'visaland-core'),
            ),
            'default' => 'DESC',
            'description' => esc_html__('select order', 'visaland-core')
        ]);
        $this->add_control('orderby', [
            'label' => esc_html__('OrderBy', 'visaland-core'),
            'type' => Controls_Manager::SELECT,
            'options' => array(
                'ID' => esc_html__('ID', 'visaland-core'),
                'title' => esc_html__('Title', 'visaland-core'),
                'date' => esc_html__('Date', 'visaland-core'),
                'rand' => esc_html__('Random', 'visaland-core'),
                'comment_count' => esc_html__('Most Comments', 'visaland-core'),
            ),
            'default' => 'ID',
            'description' => esc_html__('select order', 'visaland-core')
        ]);      
        
           $this->add_control(
            'image_thumb_display',
            [
                'label' => esc_html__('Image Display', 'visaland-core'),
                'type' => Controls_Manager::SWITCHER,
                'description' => esc_html__('show/hide description', 'visaland-core'),
            ]
        );
        
        $this->add_control(
            'thumb_date',
            [
                'label' => esc_html__('Thumb Date Show/Hide', 'visaland-core'),
                'type' => Controls_Manager::SWITCHER,
                'description' => esc_html__('show/hide description', 'visaland-core'),
            ]
        );
      
        $this->add_control(
            'pagination',
            [
                'label' => esc_html__('Pagination', 'visaland-core'),
                'type' => Controls_Manager::SWITCHER,
                'description' => esc_html__('you can set yes to show pagination.', 'visaland-core'),
                'default' => 'no',
            ]
        );
        
          $this->add_control(
            'category_display',
            [
                'label' => esc_html__('Category Display', 'visaland-core'),
                'type' => Controls_Manager::SWITCHER,
                'description' => esc_html__('Show  Or Hide Category.', 'visaland-core'),
            ]
        );

          $this->add_control(
            'tag_display',
            [
                'label' => esc_html__('Tags Display', 'visaland-core'),
                'type' => Controls_Manager::SWITCHER,
                'description' => esc_html__('Show  Or Hide Tags.', 'visaland-core'),
            ]
        );
        
        $this->add_control(
            'pagination_alignment',
            [
                'label' => esc_html__('Pagination Alignment', 'visaland-core'),
                'type' => Controls_Manager::SELECT,
                'options' => array(
                    'start' => esc_html__('Left Align', 'visaland-core'),
                    'center' => esc_html__('Center Align', 'visaland-core'),
                    'end' => esc_html__('Right Align', 'visaland-core'),
                ),
                'description' => esc_html__('you can set pagination alignment.', 'visaland-core'),
                'default' => 'start',
                'condition' => array('pagination' => 'yes'),
            ]
        );
        $this->end_controls_section();


            //========== Title Settings ==========================
    $this->start_controls_section(
        'title_settings',
        [
            'label' => __( 'Title Settings', 'visaland-core' ),
            'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
        ]
    );

    // Show/Hide Title Control
    $this->add_control(
        'show_title',
        [
            'label'     => esc_html__( 'Show Title', 'visaland-core' ),
            'type'      => \Elementor\Controls_Manager::CHOOSE,
            'options'   => [
                'show' => [
                    'title' => esc_html__( 'Show', 'visaland-core' ),
                    'icon'  => 'eicon-check-circle',
                ],
                'none' => [
                    'title' => esc_html__( 'Hide', 'visaland-core' ),
                    'icon'  => 'eicon-close-circle',
                ],
            ],
            'default'   => 'show',
            'selectors' => [
                '{{WRAPPER}} h3 a' => 'display: {{VALUE}} !important',
            ],
        ]
    );

    // Title Alignment Control
    $this->add_control(
        'title_alignment',
        [
            'label'     => esc_html__( 'Alignment', 'visaland-core' ),
            'type'      => \Elementor\Controls_Manager::CHOOSE,
            'options'   => [
                'left'   => [
                    'title' => esc_html__( 'Left', 'visaland-core' ),
                    'icon'  => 'eicon-text-align-left',
                ],
                'center' => [
                    'title' => esc_html__( 'Center', 'visaland-core' ),
                    'icon'  => 'eicon-text-align-center',
                ],
                'right'  => [
                    'title' => esc_html__( 'Right', 'visaland-core' ),
                    'icon'  => 'eicon-text-align-right',
                ],
            ],
            'default'   => '',
            'condition' => ['show_title' => 'show'],
            'toggle'    => true,
            'selectors' => [
                '{{WRAPPER}} h3 a' => 'text-align: {{VALUE}}',
            ],
        ]
    );

    // Title Margin Control
    $this->add_control(
        'title_margin',
        [
            'label'       => __( 'Margin', 'visaland-core' ),
            'type'        => \Elementor\Controls_Manager::DIMENSIONS,
            'size_units'  => ['px', '%', 'em'],
            'condition'   => ['show_title' => 'show'],
            'selectors'   => [
                '{{WRAPPER}} h3 a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important',
            ],
        ]
    );

    // Title Padding Control
    $this->add_control(
        'title_padding',
        [
            'label'       => __( 'Padding', 'visaland-core' ),
            'type'        => \Elementor\Controls_Manager::DIMENSIONS,
            'size_units'  => ['px', '%', 'em'],
            'condition'   => ['show_title' => 'show'],
            'selectors'   => [
                '{{WRAPPER}} h3 a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important',
            ],
        ]
    );

    // Title Typography Control
    $this->add_group_control(
        \Elementor\Group_Control_Typography::get_type(),
        [
            'name'       => 'title_typography',
            'label'      => __( 'Typography', 'visaland-core' ),
            'condition'  => ['show_title' => 'show'],
            'selector'   => '{{WRAPPER}} h3 a',
        ]
    );

    // Title Color Control
    $this->add_control(
        'title_color',
        [
            'label'      => __( 'Color', 'visaland-core' ),
            'type'       => \Elementor\Controls_Manager::COLOR,
            'condition'  => ['show_title' => 'show'],
            'selectors'  => [
                '{{WRAPPER}} h3 a' => 'color: {{VALUE}} !important',
            ],
        ]
    );

    // Title Hover Color Control
    $this->add_control(
        'title_hover_color',
        [
            'label'      => __( 'Hover Color', 'visaland-core' ),
            'type'       => \Elementor\Controls_Manager::COLOR,
            'condition'  => ['show_title' => 'show'],
            'selectors'  => [
                '{{WRAPPER}} h3 a:hover' => 'color: {{VALUE}} !important',
            ],
        ]
    );

    $this->end_controls_section();
    // End of Title Settings


        // Subtitle Settings ================== 

        $this->start_controls_section(
            'subtitle_settings',
            [
                'label' => __( 'Sub Title Setting', 'visaland-core' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
    
        // Show Sub Title Control
        $this->add_control(
            'show_subtitle',
            [
                'label'     => esc_html__( 'Show Sub Title', 'visaland-core' ),
                'type'      => \Elementor\Controls_Manager::CHOOSE,
                'options'   => [
                    'show' => [
                        'title' => esc_html__( 'Show', 'visaland-core' ),
                        'icon'  => 'eicon-check-circle',
                    ],
                    'none' => [
                        'title' => esc_html__( 'Hide', 'visaland-core' ),
                        'icon'  => 'eicon-close-circle',
                    ],
                ],
                'default'   => 'show',
                'selectors' => [
                    '{{WRAPPER}} .news-content p' => 'display: {{VALUE}} !important',
                ],
            ]
        );
    
        // Subtitle Alignment Control
        $this->add_control(
            'subtitle_alignment',
            [
                'label'     => esc_html__( 'Alignment', 'visaland-core' ),
                'type'      => \Elementor\Controls_Manager::CHOOSE,
                'options'   => [
                    'left'   => [
                        'title' => esc_html__( 'Left', 'visaland-core' ),
                        'icon'  => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__( 'Center', 'visaland-core' ),
                        'icon'  => 'eicon-text-align-center',
                    ],
                    'right'  => [
                        'title' => esc_html__( 'Right', 'visaland-core' ),
                        'icon'  => 'eicon-text-align-right',
                    ],
                ],
                'default'   => 'left',
                'condition' => [ 'show_subtitle' => 'show' ],
                'toggle'    => true,
                'selectors' => [
                    '{{WRAPPER}} .news-content p' => 'text-align: {{VALUE}} !important',
                ],
            ]
        );
    
        // Subtitle Padding Control
        $this->add_control(
            'subtitle_padding',
            [
                'label'       => __( 'Padding', 'visaland-core' ),
                'type'        => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units'  => [ 'px', '%', 'em' ],
                'condition'   => [ 'show_subtitle' => 'show' ],
                'selectors'   => [
                    '{{WRAPPER}} .news-content p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important',
                ],
            ]
        );
    
        // Subtitle Margin Control
        $this->add_control(
            'subtitle_margin',
            [
                'label'       => __( 'Margin', 'visaland-core' ),
                'type'        => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units'  => [ 'px', '%', 'em' ],
                'condition'   => [ 'show_subtitle' => 'show' ],
                'selectors'   => [
                    '{{WRAPPER}} .news-content p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important',
                ],
            ]
        );
    
        // Subtitle Typography Control
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name'       => 'subtitle_typography',
                'label'      => __( 'Typography', 'visaland-core' ),
                'selector'   => '{{WRAPPER}} .news-content p',
                'condition'  => [ 'show_subtitle' => 'show' ],
            ]
        );
    
        // Subtitle Color Control
        $this->add_control(
            'subtitle_color',
            [
                'label'      => __( 'Color', 'visaland-core' ),
                'type'       => \Elementor\Controls_Manager::COLOR,
                'separator'  => 'after',
                'condition'  => [ 'show_subtitle' => 'show' ],
                'selectors'  => [
                    '{{WRAPPER}} .news-content p' => 'color: {{VALUE}} !important',
                ],
            ]
        );
    
        // Subtitle Background Color Control
        $this->add_control(
            'subtitle_bg_color',
            [
                'label'      => __( 'Background Color', 'visaland-core' ),
                'type'       => \Elementor\Controls_Manager::COLOR,
                'separator'  => 'after',
                'condition'  => [ 'show_subtitle' => 'show' ],
                'selectors'  => [
                    '{{WRAPPER}} .news-content p' => 'background-color: {{VALUE}} !important',
                ],
            ]
        );
    
        $this->end_controls_section();
    
        // End of Subtitle Settings ==================

        
        //========== icon Settings===================================
		
		$this->start_controls_section(
			'icon_control',
			array(
				'label' => __( 'Icon Settings', 'visaland-core' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);
		
		$this->add_control(
			'show_icon',
			array(
				'label' => esc_html__( 'Show Icon', 'visaland-core' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'show' => [
						'show' => esc_html__( 'Show', 'visaland-core' ),	
						'icon' => 'eicon-check-circle',
					],
					'none' => [
						'none' => esc_html__( 'Hide', 'visaland-core' ),
						'icon' => 'eicon-close-circle',
					],
				],
				'default' => 'show',
				'selectors' => array(
					'{{WRAPPER}} .link-btn' => 'display: {{VALUE}} !important',
				),
			)
		);
		
		$this->add_control(
			'icon_alignment',
			array(
				'label' => esc_html__( 'Alignment', 'visaland-core' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'condition'    => array( 'show_icon' => 'show' ),
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'visaland-core' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'visaland-core' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'visaland-core' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => '',
				'toggle' => true,
				'selectors' => array(
					'{{WRAPPER}} .link-btn' => 'text-align: {{VALUE}} !important',
				),
			)
		);	
		
		$this->add_control(
			'icon_color',
			array(
				'label'     => __( ' Color', 'visaland-core' ),
				'condition'    => array( 'show_icon' => 'show' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .link-btn' => 'color: {{VALUE}} !important',

				),
			)
		);
		
		$this->add_control(
			'icon_bgcolor',
			array(
				'label'     => __( 'Background Color', 'visaland-core' ),
				'condition'    => array( 'show_icon' => 'show' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .link-btn' => 'background: {{VALUE}} !important',

				),
			)
		);
		
		
		$this->add_control(
			'icon_hover_color',
			array(
				'label'     => __( ' Hover Color', 'visaland-core' ),
				'condition'    => array( 'show_icon' => 'show' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .link-btn:hover' => 'color: {{VALUE}} !important',

				),
			)
		);
		
		$this->add_control(
			'icon_hover_bgcolor',
			array(
				'label'     => __( 'Background Hover Color', 'visaland-core' ),
				'condition'    => array( 'show_icon' => 'show' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .link-btn:hover' => 'background: {{VALUE}} !important',

				),
			)
		);
		
		$this->add_control(
			'icon_padding',
			array(
				'label'     => __( 'Padding', 'visaland-core' ),
				'type'      => \Elementor\Controls_Manager::DIMENSIONS,
				'condition'    => array( 'show_icon' => 'show' ),
				'size_units' =>  ['px', '%', 'em' ],
			
				'selectors' => array(
					'{{WRAPPER}} .link-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}!important',
				),
			)
		);

		$this->add_control(
			'icon_margin',
			array(
				'label'     => __( 'Margin', 'visaland-core' ),
				'type'      => \Elementor\Controls_Manager::DIMENSIONS,
				'condition'    => array( 'show_icon' => 'show' ),
				'size_units' =>  ['px', '%', 'em' ],
				'selectors' => array(
					'{{WRAPPER}} .link-btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}!important',
				),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'icon_typography',
				'condition'    => array( 'show_icon' => 'show' ),
				'label'    => __( 'Typography', 'visaland-core' ),
				'selector' => '{{WRAPPER}} .link-btn',
			)
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			array(
				'name' => 'icon_border',
				'condition'    => array( 'show_icon' => 'show' ),
				'selector' => '{{WRAPPER}} .link-btn',
			)
		);
		
		$this->add_control(
			'icon_border_radius',
			array(
				'label'     => __( 'Icon Border Radius', 'visaland-core' ),
				'type'      => \Elementor\Controls_Manager::DIMENSIONS,
				'condition'    => array( 'show_icon' => 'show' ),
				'size_units' =>  ['px', '%', 'em' ],
			
				'selectors' => array(
					'{{WRAPPER}} .link-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}!important',
				),
			)
		);


		$this->end_controls_section();		
		
		//End of icon


    }

    /**
     * Render Elementor widget output on the frontend.
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $rand_numb = rand(333, 999999999);
        //query settings
        $total_posts = $settings['total'];
        $category = $settings['category'];
        $order = $settings['order'];
        $orderby = $settings['orderby'];
        $offset = $settings['offset'];
        $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;

        //other settings
        $pagination = $settings['pagination'] ? false : true;
        $pagination_alignment = $settings['pagination_alignment'];

        //setup query       

        $args = array(
            'post_type' => 'post',
            'posts_per_page' => $total_posts,
            'order' => $order,
            'orderby' => $orderby,
            'paged' => $paged, // Use paged instead of offset
            'post_status' => 'publish',
            'ignore_sticky_posts' => 1,
        );
        
        if (!empty($category)) {
            $args['tax_query'] = array(
                array(
                    'taxonomy' => 'category',
                    'field' => 'term_id',
                    'terms' => $category
                )
            );
        }
        
        $post_data = new \WP_Query($args);
        

        ?>

        
        <?php  if ( 'style1' === $settings['style'] ) : ?>

        <div class="row">
            <?php while ($post_data->have_posts()):$post_data->the_post(); 
                $img_id = get_post_thumbnail_id(get_the_ID()) ? get_post_thumbnail_id(get_the_ID()) : false;
                $img_url_val = $img_id ? wp_get_attachment_image_src($img_id, 'visaland_grid_blog_12', false) : '';
                $img_url = is_array($img_url_val) && !empty($img_url_val) ? $img_url_val[0] : '';
                $img_alt = get_post_meta($img_id, '_wp_attachment_image_alt', true);

                $comments_count = get_comments_number(get_the_ID());
                $comment_text = ($comments_count > 1) ? 'Comments (' . $comments_count . ')' : 'Comment (' . $comments_count . ')';
            ?>
            <div class="<?php echo esc_attr($settings['blog_grid']); ?> col-md-6 wow fadeInUp" data-wow-delay=".3s">
                <div class="news-box-items">
                    <div class="news-image">

                        <?php if(!empty($settings['image_thumb_display'])) : ?>
                            <img src="<?php echo esc_url($img_url); ?>" alt="<?php echo esc_attr($img_alt); ?>">
                            <img src="<?php echo esc_url($img_url); ?>" alt="<?php echo esc_attr($img_alt); ?>">
                        <?php endif; ?>

                        <?php if(!empty($settings['thumb_date'])) : ?>
                            <h6 class="date"><?php echo get_the_date('d'); ?> <span><?php echo get_the_date('M'); ?></span></h6>
                        <?php endif; ?>

                    </div>
                    <div class="news-content">
                       <ul class="post-date">
                            <li>
                                <i class="far fa-user-circle"></i>
                                <?php the_author(); ?>
                            </li>
                            <li>
                                <i class="fal fa-comments"></i>
                                Comments (<?php comments_number('0', '1', '%'); ?>)
                            </li>
                            <?php if(!empty($settings['tag_display'])) : ?>
                            <li>
                                <i class="fas fa-tag"></i> 
                                <?php
                                    $post_tags = get_the_tags();
                                    if ($post_tags) {
                                        $first_tag = reset($post_tags);
                                        echo '<a href="' . get_tag_link($first_tag->term_id) . '">' . $first_tag->name . '</a>';
                                    } else {
                                        echo "No tags found";
                                    }
                                ?>                       
                            </li>
                            <?php endif; ?>

                            <?php if(!empty($settings['category_display'])) : ?>
                            <li>
                                <i class="fas fa-folder-open"></i> 
                                <?php
                                    $post_category = get_the_category();
                                    if ($post_category) {
                                        $first_category = reset($post_category);
                                        echo '<a href="' . get_tag_link($first_category->term_id) . '">' . $first_category->name . '</a>';
                                    } else {
                                        echo "No category found";
                                    }
                                ?>                       
                            </li>
                            <?php endif; ?>
                        </ul>
                        <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                        <p>
                            <?php print wp_trim_words(get_the_content(), $settings['word_limit'], $settings['more_text']); ?>
                        </p>
                        <a href="<?php the_permalink(); ?>" class="link-btn">
                            <span><?php echo $settings['button'];?></span> <i class="fas fa-chevron-right"></i>
                        </a>
                    </div>
                </div>
            </div>
            <?php
                endwhile;
                wp_reset_query();
            ?>
            <?php if (!$pagination) { ?>
                <div class="col-lg-12">
                    <div class="blog-pagination text-<?php echo esc_attr($pagination_alignment) ?> margin-top-20">
                        
                            <?php visaland()->post_pagination($post_data); ?>

                    </div>
                </div>
            <?php } ?>
        </div>

        <?php  elseif ( 'style2' === $settings['style'] ) : ?>

            <div class="row">
                <?php while ($post_data->have_posts()):$post_data->the_post(); 
                    $img_id = get_post_thumbnail_id(get_the_ID()) ? get_post_thumbnail_id(get_the_ID()) : false;
                    $img_url_val = $img_id ? wp_get_attachment_image_src($img_id, 'visaland_grid_blog_12', false) : '';
                    $img_url = is_array($img_url_val) && !empty($img_url_val) ? $img_url_val[0] : '';
                    $img_alt = get_post_meta($img_id, '_wp_attachment_image_alt', true);

                    $comments_count = get_comments_number(get_the_ID());
                    $comment_text = ($comments_count > 1) ? 'Comments (' . $comments_count . ')' : 'Comment (' . $comments_count . ')';
                ?>
                <div class="<?php echo esc_attr($settings['blog_grid']); ?> col-md-6 wow fadeInUp" data-wow-delay=".3s">
                    <div class="single-news-style-1">
                        <div class="news-image">
                            <?php if(!empty($settings['image_thumb_display'])) : ?>
                                <img src="<?php echo esc_url($img_url); ?>" alt="<?php echo esc_attr($img_alt); ?>">
                                <img src="<?php echo esc_url($img_url); ?>" alt="<?php echo esc_attr($img_alt); ?>">
                            <?php endif; ?>
                            <?php if(!empty($settings['thumb_date'])) : ?>
                            <div class="post-date">
                                <h3><?php echo get_the_date('d'); ?></h3>
                                <p><?php echo get_the_date('M'); ?></p>
                            </div>
                            <?php endif; ?>
                        </div>
                        <div class="news-content">
                            <div class="author-item mb-4">                               
                                <div class="post-cat d-flex g-2">

                                    <?php if(!empty($settings['category_display'])) : ?>
                                        <?php
                                            $post_category = get_the_category();
                                            if ($post_category) {
                                                $first_category = reset($post_category);
                                                echo '<a href="' . get_tag_link($first_category->term_id) . '">' . $first_category->name . '</a>';
                                            } else {
                                                echo "No category found";
                                            }
                                        ?>   
                                    <?php endif; ?>

                                    <?php if(!empty($settings['tag_display'])) : ?>
                                        <?php
                                            $post_tags = get_the_tags();
                                            if ($post_tags) {
                                                $first_tag = reset($post_tags);
                                                echo '<a href="' . get_tag_link($first_tag->term_id) . '">' . $first_tag->name . '</a>';
                                            } else {
                                                echo "No tags found";
                                            }
                                        ?>  
                                      <?php endif; ?>

                                </div>
                              
                                <div class="post-author d-flex align-items-center">
                                    <?php 
                                        $author_id = get_the_author_meta('ID'); 
                                        echo get_avatar($author_id, 40, '', 'author-img', ['class' => 'img-fluid rounded-circle']); 
                                    ?>
                                    <p><?php the_author(); ?></p>
                                </div>
                            </div>
                            <h3>
                                <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                            </h3>
                            <a href="<?php the_permalink(); ?>" class="link-btn mt-4">
                            <?php echo $settings['button'];?><i class="fas fa-chevron-right"></i>
                            </a>
                        </div>
                    </div>
                </div>
                <?php
                endwhile;
                wp_reset_query();
                ?>
                <?php if (!$pagination) { ?>
                    <div class="col-lg-12">
                        <div class="blog-pagination text-<?php echo esc_attr($pagination_alignment) ?> margin-top-20">
                            
                                <?php visaland()->post_pagination($post_data); ?>

                        </div>
                    </div>
                <?php } ?>
            </div>

        <?php  elseif ( 'style3' === $settings['style'] ) : ?>

            <div class="row">
                <?php while ($post_data->have_posts()):$post_data->the_post(); 
                    $img_id = get_post_thumbnail_id(get_the_ID()) ? get_post_thumbnail_id(get_the_ID()) : false;
                    $img_url_val = $img_id ? wp_get_attachment_image_src($img_id, 'visaland_grid_blog_12', false) : '';
                    $img_url = is_array($img_url_val) && !empty($img_url_val) ? $img_url_val[0] : '';
                    $img_alt = get_post_meta($img_id, '_wp_attachment_image_alt', true);

                    $comments_count = get_comments_number(get_the_ID());
                    $comment_text = ($comments_count > 1) ? 'Comments (' . $comments_count . ')' : 'Comment (' . $comments_count . ')';
                ?>
                <div class="<?php echo esc_attr($settings['blog_grid']); ?> col-md-6 wow fadeInUp" data-wow-delay=".3s">
                    <div class="single-news-items-2">
                        <div class="news-image bg-cover" style="background-image: url('<?php echo esc_url($img_url); ?>');">
                            <?php if(!empty($settings['thumb_date'])) : ?>
                            <div class="post-date">
                                <h4>
                                    <?php echo get_the_date('d'); ?> <br>
                                    <span><?php echo get_the_date('M'); ?></span>
                                </h4>
                            </div>
                            <?php endif; ?>
                        </div>
                        <div class="news-content">
                            <?php if(!empty($settings['category_display'])) : ?>
                            <p>
                                <?php
                                    $post_category = get_the_category();
                                    if ($post_category) {
                                        $first_category = reset($post_category);
                                        echo '<a href="' . get_tag_link($first_category->term_id) . '">' . $first_category->name . '</a>';
                                    } else {
                                        echo "No category found";
                                    }
                                ?> 
                            </p>
                            <?php endif; ?>

                            <?php if(!empty($settings['tag_display'])) : ?>
                                <p>                            
                                <?php
                                    $post_tags = get_the_tags();
                                    if ($post_tags) {
                                        $first_tag = reset($post_tags);
                                        echo '<a href="' . get_tag_link($first_tag->term_id) . '">' . $first_tag->name . '</a>';
                                    } else {
                                        echo "No tags found";
                                    }
                                ?>                           
                                </p>
                                <?php endif; ?>

                            <h4>
                               <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                            </h4>
                            <a href="<?php the_permalink(); ?>" class="link-btn link-btn-2">
                                <span><?php echo $settings['button'];?></span>
                                <i class="fas fa-chevron-right"></i>
                            </a>
                        </div>
                    </div>
                </div>
                <?php
                endwhile;
                wp_reset_query();
                ?>
                <?php if (!$pagination) { ?>
                    <div class="col-lg-12">
                        <div class="blog-pagination text-<?php echo esc_attr($pagination_alignment) ?> margin-top-20">
                            
                                <?php visaland()->post_pagination($post_data); ?>

                        </div>
                    </div>
                <?php } ?>
            </div>

        <?php  elseif ( 'style4' === $settings['style'] ) : ?>

            <div class="row">
                <?php while ($post_data->have_posts()):$post_data->the_post(); 
                    $img_id = get_post_thumbnail_id(get_the_ID()) ? get_post_thumbnail_id(get_the_ID()) : false;
                    $img_url_val = $img_id ? wp_get_attachment_image_src($img_id, 'visaland_grid_blog_12', false) : '';
                    $img_url = is_array($img_url_val) && !empty($img_url_val) ? $img_url_val[0] : '';
                    $img_alt = get_post_meta($img_id, '_wp_attachment_image_alt', true);

                    $comments_count = get_comments_number(get_the_ID());
                    $comment_text = ($comments_count > 1) ? 'Comments (' . $comments_count . ')' : 'Comment (' . $comments_count . ')';
                ?>
                <div class="<?php echo esc_attr($settings['blog_grid']); ?> col-md-6 wow fadeInUp" data-wow-delay=".3s">
                    <div class="single-news-items-4">
                        <div class="news-image bg-cover" style="background-image: url('<?php echo esc_url($img_url); ?>');">
                            <?php if(!empty($settings['thumb_date'])) : ?>
                            <div class="post-date">
                                <h5><?php echo get_the_date('d'); ?></h5>
                                <span><?php echo get_the_date('M'); ?></span>
                            </div>
                            <?php endif; ?>
                            <div class="news-content">
                                    <?php if(!empty($settings['category_display'])) : ?>
                                    <div class="icon">
                                        <i class="fal fa-tag"></i>
                                        <span>
                                            <?php
                                                $post_category = get_the_category();
                                                if ($post_category) {
                                                    $first_category = reset($post_category);
                                                    echo '<a href="' . get_tag_link($first_category->term_id) . '">' . $first_category->name . '</a>';
                                                } else {
                                                    echo "No category found";
                                                }
                                            ?> 
                                        </span>
                                    </div>
                                    <?php endif; ?>

                                    <?php if(!empty($settings['tag_display'])) : ?>
                                    <div class="icon">
                                        <i class="fal fa-folder"></i>
                                        <span>
                                            <?php
                                                $post_tags = get_the_tags();
                                                if ($post_tags) {
                                                    $first_tag = reset($post_tags);
                                                    echo '<a href="' . get_tag_link($first_tag->term_id) . '">' . $first_tag->name . '</a>';
                                                } else {
                                                    echo "No tags found";
                                                }
                                            ?>
                                        </span>
                                    </div>
                                    <?php endif; ?>
                                <h4>
                                    <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                </h4>
                                <ul class="post-list">
                                    <li>
                                        <i class="far fa-comment-alt"></i>
                                        Comments (<?php comments_number('0', '1', '%'); ?>)
                                    </li>
                                    <li><a href="<?php the_permalink(); ?>"><i class="fas fa-long-arrow-right"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
                endwhile;
                wp_reset_query();
                ?>
                <?php if (!$pagination) { ?>
                    <div class="col-lg-12">
                        <div class="blog-pagination text-<?php echo esc_attr($pagination_alignment) ?> margin-top-20">
                            
                                <?php visaland()->post_pagination($post_data); ?>

                        </div>
                    </div>
                <?php } ?>
            </div>

        <?php endif ;?>	

        <?php
    }
}

Plugin::instance()->widgets_manager->register_widget_type(new Blog_Post());