<?php
namespace Elementor;

/**
 * Elementor Widget
 * @package Visaland
 * @since 1.0.0
 */ 
 
class Exprience extends Widget_Base {

	/**
	 * Get widget name.
	 * Retrieve button widget name.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'visaland-exprience-widget';
	}

	/**
	 * Get widget title.
	 * Retrieve button widget title.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Experience', 'visaland-core' );
	}

	/**
	 * Get widget icon.
	 * Retrieve button widget icon.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-flash';
	}

	/**
	 * Get widget categories.
	 * Retrieve the list of categories the button widget belongs to.
	 * Used to determine where to display the widget in the editor.
	 *
	 * @since  2.0.0
	 * @access public
	 * @return array Widget categories.
	 */
	public function get_categories()
    {
        return ['visaland_widgets'];
    }
	
	/**
	 * Register button widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function register_controls() {

		// Tab Start - 1

		$this->start_controls_section(
			'exprience',
			[
				'label' => esc_html__( 'Experience', 'visaland-core' ),
			]
		);		
		
		$this->add_control(
			'style',
			[
				'label'   => esc_html__( 'Select Style', 'visaland-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'style1',
				'options' => array(
					'style1'   => esc_html__( 'Style One', 'visaland-core' ),
				),
			]
		);

		$this->add_control(
			'subtitle',
			[
				'label'       => __( 'Sub Title', 'visaland-core' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your sub title', 'visaland-core' ),
			]
		);
	
		$this->add_control(
				'title',
				[
					'label'       => __( 'Title', 'visaland-core' ),
					'type'        => Controls_Manager::TEXTAREA,
					'dynamic'     => [
						'active' => true,
					],
					'placeholder' => __( 'Enter your title', 'visaland-core' ),
				]
			);
	
	
		$this->add_control(
				'text',
				[
					'label'       => __( 'Description Text', 'visaland-core' ),
					'type'        => Controls_Manager::TEXTAREA,
					'dynamic'     => [
						'active' => true,
					],
					'placeholder' => __( 'Enter Your Text', 'visaland-core' ),
				]
			);

			$this->add_control(
				'button',
				[
					'label'       => __( 'Button', 'visaland-core' ),
					'type'        => Controls_Manager::TEXT,
					'dynamic'     => [
						'active' => true,
					],
					'placeholder' => esc_html__( 'Enter your button text', 'visaland-core' ),
					'default' => esc_html__('Read More', 'visaland-core'),
				]
			);	
	
		$this->add_control(
				'button_link',
				[
				  'label' => __( 'Button Url', 'visaland-core' ),
				  'type' => Controls_Manager::URL,
				  'placeholder' => __( 'https://your-link.com', 'visaland-core' ),
				  'show_external' => true,
				  'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				  ],
				
			   ]
			);

		$this->end_controls_section();

		// Tab Start - 2

		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Block', 'visaland-core' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
		  'repeat', 
			[
				'type' => Controls_Manager::REPEATER,
				'separator' => 'before',
				'default' => 
					[
						['block_title' => esc_html__('Hello World', 'visaland-core')],
					],
				'fields' => 
					[						

						'block_icons' =>
						[
						 'name' => 'block_icons',
						 'label' => esc_html__('Enter The icons', 'visaland-core'),
						 'type' => Controls_Manager::ICONS,							
						 ],

						'block_title' =>
						[
							'name' => 'block_title',
							'label' => esc_html__('Title', 'visaland-core'),
							'type' => Controls_Manager::TEXTAREA,
							'default' => esc_html__('', 'visaland-core')
						],

						'block_subtitle' =>
						[
							'name' => 'block_subtitle',
							'label' => esc_html__('Suffix', 'visaland-core'),
							'type' => Controls_Manager::TEXTAREA,
							'default' => esc_html__('', 'visaland-core')
						],

						'block_text' =>
						[
							'name' => 'block_text',
							'label' => esc_html__('Text', 'visaland-core'),
							'type' => Controls_Manager::TEXTAREA,
							'default' => esc_html__('', 'visaland-core')
						],						
						
					],
				'title_field' => '{{block_title}}',
			 ]
	);
		
		
	$this->end_controls_section();	

	
		}

	/**
	 * Render button widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$allowed_tags = wp_kses_allowed_html('post');
		?>


<?php  if ( 'style1' === $settings['style'] ) : ?>	

	<section class="service-counter-section fix">
		<div class="container">
			<div class="service-counter-wrapper">
				<div class="row">
					<div class="col-lg-5">
						<div class="service-counter-content">
							<div class="section-title">
								<span class="text-white wow fadeInUp"><?php echo $settings['subtitle'];?></span>
								<h2 class="text-white title-anim">
									<?php echo $settings['title'];?>
								</h2>
							</div>
							<p class="mt-4 mt-md-0 text-white wow fadeInUp" data-wow-delay=".5s">
								<?php echo $settings['text'];?>
							</p>
							<a href="<?php echo esc_url($settings['button_link']['url']);?>" class="theme-btn bg-white mt-4 wow fadeInUp" data-wow-delay=".7s">
								<span>
									<?php echo $settings['button'];?>
									<i class="fas fa-chevron-right"></i>
								</span>
							</a>
						</div>
					</div>
					<div class="col-lg-7 mt-5 mt-lg-0">
						<div class="row g-4">
							<?php foreach($settings['repeat'] as $item):?>
							<div class="col-lg-4 wow fadeInUp" data-wow-delay=".3s">
								<div class="service-counter-items">
									<div class="icon">
										<i class="<?php echo str_replace("icon ", " ", esc_attr( $item['block_icons']['value']));?>"></i>
									</div>
									<div class="content">
										<h2>
											<span class="count"><?php echo wp_kses($item['block_title'], $allowed_tags);?></span><?php echo wp_kses($item['block_subtitle'], $allowed_tags);?></h2>
										<p>
											<?php echo wp_kses($item['block_text'], $allowed_tags);?>
										</p>
									</div>
								</div>
							</div>
							<?php endforeach; ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

<?php endif ;?>	

             
		<?php 
	}


}

Plugin::instance()->widgets_manager->register_widget_type(new Exprience());