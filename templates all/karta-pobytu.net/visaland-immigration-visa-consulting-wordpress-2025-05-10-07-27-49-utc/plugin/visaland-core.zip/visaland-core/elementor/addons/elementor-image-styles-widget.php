<?php
namespace Elementor;

/**
 * Elementor Widget
 * @package Visaland
 * @since 1.0.0
 */ 
 
class Image_Styles extends Widget_Base {

	/**
	 * Get widget name.
	 * Retrieve button widget name.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'visaland-image-styles-widget';
	}

	/**
	 * Get widget title.
	 * Retrieve button widget title.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Image Styles', 'visaland-core' );
	}

	/**
	 * Get widget icon.
	 * Retrieve button widget icon.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-image-box';
	}

	/**
	 * Get widget categories.
	 * Retrieve the list of categories the button widget belongs to.
	 * Used to determine where to display the widget in the editor.
	 *
	 * @since  2.0.0
	 * @access public
	 * @return array Widget categories.
	 */
	public function get_categories()
    {
        return ['visaland_widgets'];
    }
	
	/**
	 * Register button widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function register_controls() {

		// Tab Start - 1

		$this->start_controls_section(
			'image_styles',
			[
				'label' => esc_html__( 'Image Styles', 'visaland-core' ),
			]
		);	
		
		$this->add_control(
			'style',
			[
				'label'   => esc_html__( 'Select Style', 'visaland-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'style1',
				'options' => array(
					'style1'   => esc_html__( 'Style One', 'visaland-core' ),
					'style2'   => esc_html__( 'Style Two', 'visaland-core' ),
					'style3'   => esc_html__( 'Style Three', 'visaland-core' ),
					'style4'   => esc_html__( 'Style Four', 'visaland-core' ),
					'style5'   => esc_html__( 'Style Five', 'visaland-core' ),
					'style6'   => esc_html__( 'Style Six', 'visaland-core' ),
					'style7'   => esc_html__( 'Style Seven', 'visaland-core' ),
				),
			]
		);

		$this->add_control(
			'image',
				[
				  'label' => __( 'Image', 'visaland-core' ),
				  'type' => Controls_Manager::MEDIA,
				  'default' => ['url' => Utils::get_placeholder_image_src(),],
				  'condition'	=> ['style' => ['style1','style2','style3','style4','style5','style6','style7']],
				]
		);	
		
		$this->add_control(
			'alt_text',
			[
				'label'       => __( 'Alt text', 'visaland-core' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter Your Text', 'visaland-core' ),
				'condition'	=> ['style' => ['style1','style2','style3','style4','style5','style6','style7']],
			]
		);

		$this->add_control(
			'bg_image',
			[
				'label' => esc_html__('Background image', 'visaland-core'),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
				'condition'	=> ['style' => ['style1','style2','style3','style4','style5']],
			]
		);

		$this->add_control(
			'image2',
				[
				  'label' => __( 'Image', 'visaland-core' ),
				  'type' => Controls_Manager::MEDIA,
				  'default' => ['url' => Utils::get_placeholder_image_src(),],
				  'condition'	=> ['style' => ['style1','style2','style3','style4','style5','style6','style7']],
				]
		);	
		
		$this->add_control(
			'alt_text2',
			[
				'label'       => __( 'Alt text', 'visaland-core' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter Your Text', 'visaland-core' ),
				'condition'	=> ['style' => ['style1','style2','style3','style4','style5','style6','style7']],
			]
		);
		
		$this->add_control(
			'image3',
				[
				  'label' => __( 'Image', 'visaland-core' ),
				  'type' => Controls_Manager::MEDIA,
				  'default' => ['url' => Utils::get_placeholder_image_src(),],
				  'condition'	=> ['style' => ['style2','style6','style7']],
				]
		);	
		
		$this->add_control(
			'alt_text3',
			[
				'label'       => __( 'Alt text', 'visaland-core' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter Your Text', 'visaland-core' ),
				'condition'	=> ['style' => ['style2','style6','style7']],
			]
		);

		$this->add_control(
			'image4',
				[
				  'label' => __( 'Image', 'visaland-core' ),
				  'type' => Controls_Manager::MEDIA,
				  'default' => ['url' => Utils::get_placeholder_image_src(),],
				  'condition'	=> ['style' => ['style2','style6']],
				]
		);	
		
		$this->add_control(
			'alt_text4',
			[
				'label'       => __( 'Alt text', 'visaland-core' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter Your Text', 'visaland-core' ),
				'condition'	=> ['style' => ['style2','style6']],
			]
		);

		$this->add_control(
			'title',
			[
				'label'       => __( 'Title', 'visaland-core' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your title', 'visaland-core' ),
				'condition'	=> ['style' => ['style2','style3','style5','style7']],
			]
		);

		$this->add_control(
			'subtitle',
			[
				'label'       => __( 'Sub Title', 'visaland-core' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your sub title', 'visaland-core' ),
				'condition'	=> ['style' => ['style3','style5']],
			]
		);

		$this->add_control(
			'subtitle2',
			[
				'label'       => __( 'Sub Title', 'visaland-core' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your sub title', 'visaland-core' ),
				'condition'	=> ['style' => ['style3']],
			]
		);

		$this->end_controls_section();

	
		}

	/**
	 * Render button widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$allowed_tags = wp_kses_allowed_html('post');
		?>

<?php  if ( 'style1' === $settings['style'] ) : ?>	

	<div class="about-wrapper">
		<div class="about-image-items">
			<div class="border-shape">
			<?php  if ( !empty(esc_url($settings['image']['id']) )) : ?>   
				<img src="<?php echo wp_get_attachment_url($settings['image']['id']);?>" alt="<?php echo esc_attr($settings['alt_text']);?>"/>
			<?php endif;?>
			</div>
			<div class="about-image bg-cover wow fadeInLeft" data-wow-delay=".3s" style="background-image: url('<?php echo wp_get_attachment_url($settings['bg_image']['id']);?>');">
				<div class="about-image-2 wow fadeInUp" data-wow-delay=".5s">
				<?php  if ( !empty(esc_url($settings['image2']['id']) )) : ?>   
					<img src="<?php echo wp_get_attachment_url($settings['image2']['id']);?>" alt="<?php echo esc_attr($settings['alt_text2']);?>"/>
				<?php endif;?>
				</div>
			</div>
		</div>
	</div>

<?php  elseif ( 'style2' === $settings['style'] ) : ?>		

	<div class="choose-us-wrapper">
		<div class="choose-us-image-items ms-0">
			<div class="row g-4">
				<div class="col-lg-7 wow fadeInUp" data-wow-delay=".3s">
					<div class="choose-image-1">
					<?php  if ( !empty(esc_url($settings['image']['id']) )) : ?>   
						<img src="<?php echo wp_get_attachment_url($settings['image']['id']);?>" alt="<?php echo esc_attr($settings['alt_text']);?>"/>
					<?php endif;?>
					</div>
				</div>
				<div class="col-lg-5">
					<div class="choose-image-2 bg-cover wow fadeInUp" data-wow-delay=".3s" style="background-image: url('<?php echo wp_get_attachment_url($settings['bg_image']['id']);?>');"></div>
					<div class="choose-image-3 wow fadeInUp" data-wow-delay=".5s">
					<?php  if ( !empty(esc_url($settings['image2']['id']) )) : ?>   
						<img src="<?php echo wp_get_attachment_url($settings['image2']['id']);?>" alt="<?php echo esc_attr($settings['alt_text2']);?>"/>
					<?php endif;?>
					</div>
				</div>
			</div>
			<div class="choose-box">
				<h3><?php echo $settings['title'];?></h3>
				<?php  if ( !empty(esc_url($settings['image3']['id']) )) : ?>   
					<img src="<?php echo wp_get_attachment_url($settings['image3']['id']);?>" alt="<?php echo esc_attr($settings['alt_text3']);?>"/>
				<?php endif;?>
			</div>
		</div>
	</div>

<?php  elseif ( 'style3' === $settings['style'] ) : ?>	

	<div class="about-wrapper style-2">
		<div class="about-image-items">
			<div class="border-shape">
				<?php  if ( !empty(esc_url($settings['image']['id']) )) : ?>   
					<img src="<?php echo wp_get_attachment_url($settings['image']['id']);?>" alt="<?php echo esc_attr($settings['alt_text']);?>"/>
				<?php endif;?>
			</div>
			<div class="about-image bg-cover wow fadeInUp" data-wow-delay=".3s" style="background-image: url('<?php echo wp_get_attachment_url($settings['bg_image']['id']);?>');">
				<div class="about-image-2 wow fadeInUp" data-wow-delay=".4s">
					<?php  if ( !empty(esc_url($settings['image2']['id']) )) : ?>   
						<img src="<?php echo wp_get_attachment_url($settings['image2']['id']);?>" alt="<?php echo esc_attr($settings['alt_text2']);?>"/>
					<?php endif;?>
				</div>
				<div class="experience-text-area wow fadeInUp" data-wow-delay=".5s">
					<h2><span class="count"><?php echo $settings['title'];?></span>+</h2>
					<h6><?php echo $settings['subtitle'];?></h6>
					<div class="star">
						<span class="fas fa-star"></span>
						<span class="fas fa-star"></span>
						<span class="fas fa-star"></span>
						<span class="fas fa-star"></span>
						<span class="fas fa-star me-2"></span>
						<span><?php echo $settings['subtitle2'];?></span>
					</div>
					<div class="ratting">
						<span>5.0</span>
					</div>
				</div>
			</div>
		</div>
	</div>

<?php  elseif ( 'style4' === $settings['style'] ) : ?>	

	<div class="choose-wrapper">
		<div class="choose-image-items">
			<div class="choose-image bg-cover wow fadeInUp" data-wow-delay=".3s" style="background-image: url('<?php echo wp_get_attachment_url($settings['bg_image']['id']);?>');"></div>
			<div class="choose-image-2 wow fadeInRight" data-wow-delay=".5s">
				<?php  if ( !empty(esc_url($settings['image']['id']) )) : ?>   
					<img src="<?php echo wp_get_attachment_url($settings['image']['id']);?>" alt="<?php echo esc_attr($settings['alt_text']);?>"/>
				<?php endif;?>
			</div>
			<div class="circle-shape">
				<?php  if ( !empty(esc_url($settings['image2']['id']) )) : ?>   
					<img class="text-circle" src="<?php echo wp_get_attachment_url($settings['image2']['id']);?>" alt="<?php echo esc_attr($settings['alt_text2']);?>"/>
				<?php endif;?>
			</div>
		</div>
	</div>

	<?php  elseif ( 'style5' === $settings['style'] ) : ?>	

		<div class="about-wrapper-2">
			<div class="about-image-items">
				<div class="about-image-1 bg-cover wow fadeInLeft" data-wow-delay=".3s" style="background-image: url('<?php echo wp_get_attachment_url($settings['bg_image']['id']);?>');">
					<div class="about-image-2 wow fadeInUp" data-wow-delay=".5s">
					<?php  if ( !empty(esc_url($settings['image']['id']) )) : ?>   
						<img src="<?php echo wp_get_attachment_url($settings['image']['id']);?>" alt="<?php echo esc_attr($settings['alt_text']);?>"/>
					<?php endif;?>
					</div>
				</div>
				<div class="circle-shape">
					<?php  if ( !empty(esc_url($settings['image2']['id']) )) : ?>   
						<img class="text-circle" src="<?php echo wp_get_attachment_url($settings['image2']['id']);?>" alt="<?php echo esc_attr($settings['alt_text2']);?>"/>
					<?php endif;?>
					<div class="about-title">
						<h2><span class="count"><?php echo $settings['title'];?></span></h2>
						<p><?php echo $settings['subtitle'];?></p>
					</div>
				</div>
			</div>
        </div>

		<?php  elseif ( 'style6' === $settings['style'] ) : ?>	

			<div class="single-about-wrapper-2 mt-0">
				<div class="about-image-item ralt">
					<div class="circle-shape">
					<?php  if ( !empty(esc_url($settings['image']['id']) )) : ?>   
						<img src="<?php echo wp_get_attachment_url($settings['image']['id']);?>" alt="<?php echo esc_attr($settings['alt_text']);?>"/>
					<?php endif;?>
					</div>
					<div class="bg-shape">
					<?php  if ( !empty(esc_url($settings['image2']['id']) )) : ?>   
						<img src="<?php echo wp_get_attachment_url($settings['image2']['id']);?>" alt="<?php echo esc_attr($settings['alt_text2']);?>"/>
					<?php endif;?>
					</div>
					<div class="row">
						<div class="col-lg-6 col-md-6 col-sm-6 wow fadeInUp" data-wow-delay=".3s">
							<div class="about-image-1">
							<?php  if ( !empty(esc_url($settings['image3']['id']) )) : ?>   
								<img src="<?php echo wp_get_attachment_url($settings['image3']['id']);?>" alt="<?php echo esc_attr($settings['alt_text3']);?>"/>
							<?php endif;?>
							</div>
						</div>
						<div class="col-lg-6 col-md-6 col-sm-6 wow fadeInUp" data-wow-delay=".5s">
							<div class="about-image-2">
							<?php  if ( !empty(esc_url($settings['image4']['id']) )) : ?>   
								<img src="<?php echo wp_get_attachment_url($settings['image4']['id']);?>" alt="<?php echo esc_attr($settings['alt_text4']);?>"/>
							<?php endif;?>
							</div>
						</div>
					</div>
				</div>
			</div>

		<?php  elseif ( 'style7' === $settings['style'] ) : ?>	

		    <div class="choose-us-wrapper-2">
				<div class="choose-us-image">
					<div class="choose-box">
						<h3><?php echo $settings['title'];?></h3>
						<?php  if ( !empty(esc_url($settings['image']['id']) )) : ?>   
							<img src="<?php echo wp_get_attachment_url($settings['image']['id']);?>" alt="<?php echo esc_attr($settings['alt_text']);?>"/>
						<?php endif;?>
					</div>
					<div class="row g-4">
						<div class="col-lg-6 wow fadeInUp" data-wow-delay=".3s">
							<div class="thumb-1">
							<?php  if ( !empty(esc_url($settings['image2']['id']) )) : ?>   
								<img src="<?php echo wp_get_attachment_url($settings['image2']['id']);?>" alt="<?php echo esc_attr($settings['alt_text2']);?>"/>
							<?php endif;?>
							</div>
						</div>
						<div class="col-lg-6 wow fadeInUp" data-wow-delay=".5s">
							<div class="thumb-2">
							<?php  if ( !empty(esc_url($settings['image3']['id']) )) : ?>   
								<img src="<?php echo wp_get_attachment_url($settings['image3']['id']);?>" alt="<?php echo esc_attr($settings['alt_text3']);?>"/>
							<?php endif;?>
							</div>
						</div>
					</div>
				</div>
			</div>
<?php endif ;?>	
             
		<?php 
	}


}

Plugin::instance()->widgets_manager->register_widget_type(new Image_Styles());