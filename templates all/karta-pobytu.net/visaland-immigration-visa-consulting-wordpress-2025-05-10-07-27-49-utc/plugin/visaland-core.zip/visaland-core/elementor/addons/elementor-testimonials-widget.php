<?php
namespace Elementor;

/**
 * Elementor Widget
 * @package Visaland
 * @since 1.0.0
 */ 
 
class Testimonials extends Widget_Base {

	/**
	 * Get widget name.
	 * Retrieve button widget name.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'visaland-testimonials-widget';
	}

	/**
	 * Get widget title.
	 * Retrieve button widget title.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Testimonials Widget', 'visaland-core' );
	}

	/**
	 * Get widget icon.
	 * Retrieve button widget icon.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-flash';
	}

	/**
	 * Get widget categories.
	 * Retrieve the list of categories the button widget belongs to.
	 * Used to determine where to display the widget in the editor.
	 *
	 * @since  2.0.0
	 * @access public
	 * @return array Widget categories.
	 */
	public function get_categories()
    {
        return ['visaland_widgets'];
    }
	
	/**
	 * Register button widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function register_controls() {

		// Tab Start - 1

		$this->start_controls_section(
			'testimonials',
			[
				'label' => esc_html__( 'Testimonials', 'visaland-core' ),
			]
		);		
		
		$this->add_control(
			'style',
			[
				'label'   => esc_html__( 'Select Style', 'visaland-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'style1',
				'options' => array(
					'style1'   => esc_html__( 'Style One', 'visaland-core' ),
					'style2'   => esc_html__( 'Style Two', 'visaland-core' ),
					'style3'   => esc_html__( 'Style Three', 'visaland-core' ),
					'style4'   => esc_html__( 'Style Four', 'visaland-core' ),
				),
			]
		);

		$this->end_controls_section();

		// Tab Start - 2

		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Block', 'visaland-core' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
		  'repeat', 
			[
				'type' => Controls_Manager::REPEATER,
				'separator' => 'before',
				'default' => 
					[
						['block_title' => esc_html__('Projects Completed', 'visaland-core')],
					],
				'fields' => 
					[						
					
						'block_title' =>
						[
							'name' => 'block_title',
							'label' => esc_html__('Title', 'visaland-core'),
							'type' => Controls_Manager::TEXTAREA,
							'default' => esc_html__('', 'visaland-core')
						],

						'block_title2' =>
						[
							'name' => 'block_title2',
							'label' => esc_html__('Title 2', 'visaland-core'),
							'type' => Controls_Manager::TEXTAREA,
							'default' => esc_html__('', 'visaland-core')
						],

						'block_subtitle' =>
						[
							'name' => 'block_subtitle',
							'label' => esc_html__('Subtitle', 'visaland-core'),
							'type' => Controls_Manager::TEXTAREA,
							'default' => esc_html__('', 'visaland-core')
						],

						'block_text' =>
						[
							'name' => 'block_text',
							'label' => esc_html__('Text', 'visaland-core'),
							'type' => Controls_Manager::TEXTAREA,
							'default' => esc_html__('', 'visaland-core')
						],

						'block_image' =>
						[
							'name' => 'block_image',
							'label' => __( 'Image', 'visaland-core' ),
							'type' => Controls_Manager::MEDIA,
							'default' => ['url' => Utils::get_placeholder_image_src(),],
						],	

						'block_alt_text' =>
						[
						'name' => 'block_alt_text',
						'label' => esc_html__('Image Text', 'visaland-core'),
						'type' => Controls_Manager::TEXTAREA,
						'default' => esc_html__('', 'visaland-core')
						],	

						
						'block_image2' =>
						[
							'name' => 'block_image2',
							'label' => __( 'Quote Image', 'visaland-core' ),
							'type' => Controls_Manager::MEDIA,
							'default' => ['url' => Utils::get_placeholder_image_src(),],
						],	

						'block_alt_text2' =>
						[
						'name' => 'block_alt_text2',
						'label' => esc_html__('Image Text', 'visaland-core'),
						'type' => Controls_Manager::TEXTAREA,
						'default' => esc_html__('', 'visaland-core')
						],

						'block_rating' =>
						[
							'name' => 'block_rating',
							'label'   => esc_html__( 'Select Rating', 'visaland-core' ),
							'type'    => Controls_Manager::SELECT,
							'default' => 'rat1',
							'options' => array(
								'rat1'   => esc_html__( 'Rating One', 'visaland-core' ),
								'rat2'   => esc_html__( 'Rating Two', 'visaland-core' ),
								'rat3'   => esc_html__( 'Rating Three', 'visaland-core' ),
								'rat4'   => esc_html__( 'Rating Four', 'visaland-core' ),
								'rat5'   => esc_html__( 'Rating Five', 'visaland-core' ),
							),
						],
						
					],
				'title_field' => '{{block_title}}',
			 ]
	);
		
		
	$this->end_controls_section();	


	    //========== Title Settings ==========================
		$this->start_controls_section(
			'title_settings',
			[
				'label' => __( 'Title Settings', 'visaland-core' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
	
		// Show/Hide Title Control
		$this->add_control(
			'show_title',
			[
				'label'     => esc_html__( 'Show Title', 'visaland-core' ),
				'type'      => \Elementor\Controls_Manager::CHOOSE,
				'options'   => [
					'show' => [
						'title' => esc_html__( 'Show', 'visaland-core' ),
						'icon'  => 'eicon-check-circle',
					],
					'none' => [
						'title' => esc_html__( 'Hide', 'visaland-core' ),
						'icon'  => 'eicon-close-circle',
					],
				],
				'default'   => 'show',
				'selectors' => [
					'{{WRAPPER}} .author-content h5' => 'display: {{VALUE}} !important',
				],
			]
		);
	
		// Title Alignment Control
		$this->add_control(
			'title_alignment',
			[
				'label'     => esc_html__( 'Alignment', 'visaland-core' ),
				'type'      => \Elementor\Controls_Manager::CHOOSE,
				'options'   => [
					'left'   => [
						'title' => esc_html__( 'Left', 'visaland-core' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'visaland-core' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'visaland-core' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'default'   => '',
				'condition' => ['show_title' => 'show'],
				'toggle'    => true,
				'selectors' => [
					'{{WRAPPER}} .author-content h5' => 'text-align: {{VALUE}}',
				],
			]
		);
	
		// Title Margin Control
		$this->add_control(
			'title_margin',
			[
				'label'       => __( 'Margin', 'visaland-core' ),
				'type'        => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units'  => ['px', '%', 'em'],
				'condition'   => ['show_title' => 'show'],
				'selectors'   => [
					'{{WRAPPER}} .author-content h5' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important',
				],
			]
		);
	
		// Title Padding Control
		$this->add_control(
			'title_padding',
			[
				'label'       => __( 'Padding', 'visaland-core' ),
				'type'        => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units'  => ['px', '%', 'em'],
				'condition'   => ['show_title' => 'show'],
				'selectors'   => [
					'{{WRAPPER}} .author-content h5' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important',
				],
			]
		);
	
		// Title Typography Control
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'       => 'title_typography',
				'label'      => __( 'Typography', 'visaland-core' ),
				'condition'  => ['show_title' => 'show'],
				'selector'   => '{{WRAPPER}} .author-content h5',
			]
		);
	
		// Title Color Control
		$this->add_control(
			'title_color',
			[
				'label'      => __( 'Color', 'visaland-core' ),
				'type'       => \Elementor\Controls_Manager::COLOR,
				'condition'  => ['show_title' => 'show'],
				'selectors'  => [
					'{{WRAPPER}} .author-content h5' => 'color: {{VALUE}} !important',
				],
			]
		);
	
		// Title Hover Color Control
		$this->add_control(
			'title_hover_color',
			[
				'label'      => __( 'Hover Color', 'visaland-core' ),
				'type'       => \Elementor\Controls_Manager::COLOR,
				'condition'  => ['show_title' => 'show'],
				'selectors'  => [
					'{{WRAPPER}} .author-content h5:hover' => 'color: {{VALUE}} !important',
				],
			]
		);
	
		$this->end_controls_section();
		// End of Title Settings

		
		//========== Text Settings ==========================
$this->start_controls_section(
    'text_settings',
    [
        'label' => __( 'Text Settings', 'visaland-core' ),
        'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
    ]
);

// Show/Hide Text Control
$this->add_control(
    'show_text',
    [
        'label'     => esc_html__( 'Show Text', 'visaland-core' ),
        'type'      => \Elementor\Controls_Manager::CHOOSE,
        'options'   => [
            'show' => [
                'title' => esc_html__( 'Show', 'visaland-core' ),
                'icon'  => 'eicon-check-circle',
            ],
            'none' => [
                'title' => esc_html__( 'Hide', 'visaland-core' ),
                'icon'  => 'eicon-close-circle',
            ],
        ],
        'default'   => 'show',
        'selectors' => [
            '{{WRAPPER}} .testimonial-card-items p' => 'display: {{VALUE}} !important',
        ],
    ]
);

// Text Alignment Control
$this->add_control(
    'text_alignment',
    [
        'label'     => esc_html__( 'Alignment', 'visaland-core' ),
        'type'      => \Elementor\Controls_Manager::CHOOSE,
        'options'   => [
            'left'   => [
                'title' => esc_html__( 'Left', 'visaland-core' ),
                'icon'  => 'eicon-text-align-left',
            ],
            'center' => [
                'title' => esc_html__( 'Center', 'visaland-core' ),
                'icon'  => 'eicon-text-align-center',
            ],
            'right'  => [
                'title' => esc_html__( 'Right', 'visaland-core' ),
                'icon'  => 'eicon-text-align-right',
            ],
        ],
        'default'   => '',
        'condition' => ['show_text' => 'show'],
        'toggle'    => true,
        'selectors' => [
            '{{WRAPPER}} .testimonial-card-items p' => 'text-align: {{VALUE}} !important',
        ],
    ]
);

// Text Margin Control
$this->add_control(
    'text_margin',
    [
        'label'       => __( 'Margin', 'visaland-core' ),
        'type'        => \Elementor\Controls_Manager::DIMENSIONS,
        'size_units'  => ['px', '%', 'em'],
        'condition'   => ['show_text' => 'show'],
        'selectors'   => [
            '{{WRAPPER}} .testimonial-card-items p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important',
        ],
    ]
);

// Text Padding Control
$this->add_control(
    'text_padding',
    [
        'label'       => __( 'Padding', 'visaland-core' ),
        'type'        => \Elementor\Controls_Manager::DIMENSIONS,
        'size_units'  => ['px', '%', 'em'],
        'condition'   => ['show_text' => 'show'],
        'selectors'   => [
            '{{WRAPPER}} .testimonial-card-items p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important',
        ],
    ]
);

// Text Typography Control
$this->add_group_control(
    \Elementor\Group_Control_Typography::get_type(),
    [
        'name'       => 'text_typography',
        'label'      => __( 'Typography', 'visaland-core' ),
        'condition'  => ['show_text' => 'show'],
        'selector'   => '{{WRAPPER}} .testimonial-card-items p',
    ]
);

// Text Color Control
$this->add_control(
    'text_color',
    [
        'label'      => __( 'Color', 'visaland-core' ),
        'type'       => \Elementor\Controls_Manager::COLOR,
        'condition'  => ['show_text' => 'show'],
        'separator'  => 'after',
        'selectors'  => [
            '{{WRAPPER}} .testimonial-card-items p' => 'color: {{VALUE}} !important',
        ],
    ]
);

// Text Hover Color Control
$this->add_control(
    'text_hover_color',
    [
        'label'      => __( 'Hover Color', 'visaland-core' ),
        'type'       => \Elementor\Controls_Manager::COLOR,
        'condition'  => ['show_text' => 'show'],
        'separator'  => 'after',
        'selectors'  => [
            '{{WRAPPER}} .testimonial-card-items p:hover' => 'color: {{VALUE}} !important',
        ],
    ]
);

$this->end_controls_section();
// End of Text Settings


	
		}

	/**
	 * Render button widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$allowed_tags = wp_kses_allowed_html('post');
		?>

<?php
	  echo '
	 <script>
 jQuery(document).ready(function($) {

// js code start

if($(".testimonial-carousel-active").length > 0) {
	$(".testimonial-carousel-active").slick({
		autoplay: true,
		autoplaySpeed: 2000,
		speed: 500,
		arrows: false,
		slidesToShow: 3,
		slidesToScroll: 1, 
		dots: true,
		dotsClass: "slide-dots",
		responsive: [
			{
			breakpoint: 1399,
			settings: {
				slidesToShow: 3,
			}
			},
			{
			breakpoint: 1191,
			settings: {
				slidesToShow: 2,
			}
			},
			{
			breakpoint: 768,
			settings: {
				slidesToShow: 1,
				center: true,
			}
			},
			{
			breakpoint: 480,
			settings: {
				slidesToShow: 1
			}
			}
		],

	});
}

if($(".testimonial-carousel-active-2").length > 0) {
$(".testimonial-carousel-active-2").slick({
	autoplay: true,
	autoplaySpeed: 2000,
	speed: 500,
	arrows: false,
	slidesToShow: 3,
	slidesToScroll: 1, 
	dots: true,
	dotsClass: "slide-dots",
	responsive: [
		{
			breakpoint: 1399,
			settings: {
			slidesToShow: 3,
			}
		},
		{
			breakpoint: 1191,
			settings: {
			slidesToShow: 2,
			}
		},
		{
			breakpoint: 768,
			settings: {
			slidesToShow: 1,
			center: true,
			}
		},
		{
			breakpoint: 480,
			settings: {
			slidesToShow: 1
			}
		}
	],

});
}


if($(".testimonial-carousel-active-3").length > 0) {
	$(".testimonial-carousel-active-3").slick({
		autoplay: true,
		autoplaySpeed: 2000,
		speed: 500,
		slidesToShow: 1,
		slidesToScroll: 1, 
		arrows: true,
		dots: false,
		prevArrow: $(".testimonial-nav-prev"),
		nextArrow: $(".testimonial-nav-next"),
	});
}

if($(".testimonial-carousel-active-5").length > 0) {
	$(".testimonial-carousel-active-5").slick({
		autoplay: true,
		autoplaySpeed: 2000,
		speed: 500,
		arrows: false,
		slidesToShow: 2,
		slidesToScroll: 1, 
		dots: true,
		dotsClass: "slide-dots",
		responsive: [
		{
			breakpoint: 1191,
			settings: {
			slidesToShow: 2,
			}
		},
		{
			breakpoint: 991,
			settings: {
			slidesToShow: 1,
			center: true,
			}
		},
		{
			breakpoint: 480,
			settings: {
			slidesToShow: 1
			}
		}
	],
	});
}

// js code end 

  });
</script>';


?>

<?php  if ( 'style1' === $settings['style'] ) : ?>	

	<div class="testimonial-carousel-active">
		<?php foreach($settings['repeat'] as $item):?>	
		<div class="testimonial-card-items">
			<div class="author-items">
				<div class="author-image bg-cover" style="background-image: url('<?php echo wp_get_attachment_url($item['block_image']['id']);?>');"></div>
				<div class="author-content">
					<h5><?php echo wp_kses($item['block_title'], $allowed_tags);?></h5>
					<span><?php echo wp_kses($item['block_subtitle'], $allowed_tags);?></span>
				</div>
			</div>
			<p>
				<?php echo wp_kses($item['block_text'], $allowed_tags);?>
			</p>
			<ul>
				<li><?php echo wp_kses($item['block_title2'], $allowed_tags);?></li>
			</ul>
		</div>
		<?php endforeach; ?>
	</div>

	<?php  elseif ( 'style2' === $settings['style'] ) : ?>	

	<div class="testimonial-wrapper">
		<div class="testimonial-carousel-active-2">
			<?php foreach($settings['repeat'] as $item):?>	
			<div class="testimonial-card-items-2">
				<div class="testimonial-image bg-cover" style="background-image: url('<?php echo wp_get_attachment_url($item['block_image']['id']);?>');"></div>
				<div class="testimonial-content">
					<div class="star">
					<?php if ( 'rat1' === $item['block_rating'] ) : ?>
						<i class="fas fa-star"></i>
						<i class="far fa-star"></i>
						<i class="far fa-star"></i>
						<i class="far fa-star"></i>
						<i class="far fa-star"></i>
					<?php elseif ( 'rat2' === $item['block_rating'] ) : ?>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="far fa-star"></i>
						<i class="far fa-star"></i>
						<i class="far fa-star"></i>
					<?php elseif ( 'rat3' === $item['block_rating'] ) : ?>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="far fa-star"></i>
						<i class="far fa-star"></i>
					<?php elseif ( 'rat4' === $item['block_rating'] ) : ?>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="far fa-star"></i>
					<?php elseif ( 'rat5' === $item['block_rating'] ) : ?>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
					<?php endif; ?>
					</div>
					<p>
						<?php echo wp_kses($item['block_text'], $allowed_tags);?>
					</p>
					<div class="author-name">
						<h6><?php echo wp_kses($item['block_title'], $allowed_tags);?></h6>
						<p><?php echo wp_kses($item['block_subtitle'], $allowed_tags);?></p>
					</div>
				</div>
			</div>
			<?php endforeach; ?>
		</div>
	</div>
	
	<?php  elseif ( 'style3' === $settings['style'] ) : ?>	

		<section class="testimonial-section-3 fix section-padding pt-0">
            <div class="container-fluid">
                <div class="testimonial-wrapper-3">
                    <div class="testimonial-carousel-active-3">
						<?php foreach($settings['repeat'] as $item):?>	
                        <div class="testimonial-items">
                            <div class="testimonial-image-area">
                                <div class="testimonial-image bg-cover" style="background-image: url('<?php echo wp_get_attachment_url($item['block_image']['id']);?>');">
                                    <div class="icon">
                                        <i class="fas fa-quote-left"></i>
                                    </div>
                                </div>
                                <div class="star">
								<?php if ( 'rat1' === $item['block_rating'] ) : ?>
									<i class="fas fa-star"></i>
									<i class="far fa-star"></i>
									<i class="far fa-star"></i>
									<i class="far fa-star"></i>
									<i class="far fa-star"></i>
								<?php elseif ( 'rat2' === $item['block_rating'] ) : ?>
									<i class="fas fa-star"></i>
									<i class="fas fa-star"></i>
									<i class="far fa-star"></i>
									<i class="far fa-star"></i>
									<i class="far fa-star"></i>
								<?php elseif ( 'rat3' === $item['block_rating'] ) : ?>
									<i class="fas fa-star"></i>
									<i class="fas fa-star"></i>
									<i class="fas fa-star"></i>
									<i class="far fa-star"></i>
									<i class="far fa-star"></i>
								<?php elseif ( 'rat4' === $item['block_rating'] ) : ?>
									<i class="fas fa-star"></i>
									<i class="fas fa-star"></i>
									<i class="fas fa-star"></i>
									<i class="fas fa-star"></i>
									<i class="far fa-star"></i>
								<?php elseif ( 'rat5' === $item['block_rating'] ) : ?>
									<i class="fas fa-star"></i>
									<i class="fas fa-star"></i>
									<i class="fas fa-star"></i>
									<i class="fas fa-star"></i>
									<i class="fas fa-star"></i>
								<?php endif; ?>
                                </div>
                            </div>
                            <div class="testimonial-content">
                                <h3>
									<?php echo wp_kses($item['block_text'], $allowed_tags);?>
                                </h3>
                                <div class="athor-name">
                                    <h4><?php echo wp_kses($item['block_title'], $allowed_tags);?>/</h4>
                                    <p><?php echo wp_kses($item['block_subtitle'], $allowed_tags);?></p>
                                </div>
                            </div>
                        </div>
						<?php endforeach; ?>
                    </div>
                    <div class="slider-button">
                        <div class="testimonial-nav-prev"><i class="fas fa-long-arrow-left"></i></div>
                        <div class="testimonial-nav-next"><i class="fas fa-long-arrow-right"></i></div>
                    </div>
                </div>
            </div>
        </section>

		<?php  elseif ( 'style4' === $settings['style'] ) : ?>	

		<section class="testimonial-section-5">
			<div class="single-testimonial-style-2">
				<div class="testimonial-carousel-active-5">
					<?php foreach($settings['repeat'] as $item):?>	
					<div class="single-testimonial-items-2">
						<div class="ratting-items">
							<div class="quote-icon">
							<?php if(!empty(wp_get_attachment_url($item['block_image2']['id']))): ?>
								<img src="<?php echo wp_get_attachment_url($item['block_image2']['id']);?>" alt="<?php echo wp_kses($item['block_alt_text2'], $allowed_tags);?>">
							<?php endif;?>
							</div>
							<div class="client-ratting">
								<h5>Quality Services</h5>
								<ul>
								<?php if ( 'rat1' === $item['block_rating'] ) : ?>
									<li><i class="fas fa-star"></i></li>
									<li><i class="far fa-star"></i></li>
									<li><i class="far fa-star"></i></li>
									<li><i class="far fa-star"></i></li>
									<li><i class="far fa-star"></i></li>
								<?php elseif ( 'rat2' === $item['block_rating'] ) : ?>
									<li><i class="fas fa-star"></i></li>
									<li><i class="fas fa-star"></i></li>
									<li><i class="far fa-star"></i></li>
									<li><i class="far fa-star"></i></li>
									<li><i class="far fa-star"></i></li>
								<?php elseif ( 'rat3' === $item['block_rating'] ) : ?>
									<li><i class="fas fa-star"></i></li>
									<li><i class="fas fa-star"></i></li>
									<li><i class="fas fa-star"></i></li>
									<li><i class="far fa-star"></i></li>
									<li><i class="far fa-star"></i></li>
								<?php elseif ( 'rat4' === $item['block_rating'] ) : ?>
									<li><i class="fas fa-star"></i></li>
									<li><i class="fas fa-star"></i></li>
									<li><i class="fas fa-star"></i></li>
									<li><i class="fas fa-star"></i></li>
									<li><i class="far fa-star"></i></li>
								<?php elseif ( 'rat5' === $item['block_rating'] ) : ?>
									<li><i class="fas fa-star"></i></li>
									<li><i class="fas fa-star"></i></li>
									<li><i class="fas fa-star"></i></li>
									<li><i class="fas fa-star"></i></li>
									<li><i class="fas fa-star"></i></li>
								<?php endif; ?>
								</ul>
							</div>
						</div>
						<p class="text">
							<?php echo wp_kses($item['block_text'], $allowed_tags);?>
						</p>
						<div class="client-info">
							<div class="image">
								<img src="<?php echo wp_get_attachment_url($item['block_image']['id']);?>" alt="client-img">
							</div>
							<div class="content">
							<h4><?php echo wp_kses($item['block_title'], $allowed_tags);?></h4>
							<p><?php echo wp_kses($item['block_subtitle'], $allowed_tags);?></p>
							</div>
						</div>
					</div>
					<?php endforeach; ?>
				</div>
			</div>
		</section>

<?php endif ;?>	

             
		<?php 
	}


}

Plugin::instance()->widgets_manager->register_widget_type(new Testimonials());