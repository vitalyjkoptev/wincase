<?php
namespace Elementor;

/**
 * Elementor Widget
 * @package Visaland
 * @since 1.0.0
 */ 
 
class Team_Grid extends Widget_Base {

	/**
	 * Get widget name.
	 * Retrieve button widget name.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'visaland-team-grid-widget';
	}

	/**
	 * Get widget title.
	 * Retrieve button widget title.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Team Grid', 'visaland-core' );
	}

	/**
	 * Get widget icon.
	 * Retrieve button widget icon.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-flash';
	}

	/**
	 * Get widget categories.
	 * Retrieve the list of categories the button widget belongs to.
	 * Used to determine where to display the widget in the editor.
	 *
	 * @since  2.0.0
	 * @access public
	 * @return array Widget categories.
	 */
	public function get_categories()
    {
        return ['visaland_widgets'];
    }
	
	/**
	 * Register button widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function register_controls() {

		// Tab Start - 1

		$this->start_controls_section(
			'team_grid',
			[
				'label' => esc_html__( 'Team Grid', 'visaland-core' ),
			]
		);		
		
		$this->add_control(
			'style',
			[
				'label'   => esc_html__( 'Select Style', 'visaland-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'style1',
				'options' => array(
					'style1'   => esc_html__( 'Style One', 'visaland-core' ),
					'style2'   => esc_html__( 'Style Two', 'visaland-core' ),
					'style3'   => esc_html__( 'Style Three', 'visaland-core' ),
					'style4'   => esc_html__( 'Style Four', 'visaland-core' ),
				),
			]
		);

		$this->add_control('column_grid', [
			'label' => esc_html__('Team Grid', 'visaland-core'),
			'type' => Controls_Manager::SELECT,
			'options' => array(
				'col-lg-2' => esc_html__('col-lg-2', 'visaland-core'),
				'col-lg-3' => esc_html__('col-lg-3', 'visaland-core'),
				'col-lg-4' => esc_html__('col-lg-4', 'visaland-core'),
				'col-lg-6' => esc_html__('col-lg-6', 'visaland-core'),
			),
			'default' => 'col-lg-3',
			'description' => esc_html__('Team Grid', 'visaland-core')
		]);

		$this->end_controls_section();

		// Tab Start - 2

		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Team Grid Block', 'visaland-core' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
		  'repeat', 
			[
				'type' => Controls_Manager::REPEATER,
				'separator' => 'before',
				'default' => 
					[
						['block_title' => esc_html__('Hello World', 'visaland-core')],
					],
				'fields' => 
					[						
						'block_class' => 					   
						[
						'name' => 'block_class',
						'label' => __( 'Card Options', 'visaland-core' ),
						'type' => Controls_Manager::SELECT,
						'options' => [
							'style-1' => __( 'Style 1', 'visaland-core' ),
							'style-2' => __( 'Style 2', 'visaland-core' ),
						],
						'default' => '',
						],

						'block_image' =>
						[
							'name' => 'block_image',
							'label' => __( 'Image', 'visaland-core' ),
							'type' => Controls_Manager::MEDIA,
							'default' => ['url' => Utils::get_placeholder_image_src(),],
						],	

						'block_alt_text' =>
						[
						'name' => 'block_alt_text',
						'label' => esc_html__('Image Text', 'visaland-core'),
						'type' => Controls_Manager::TEXTAREA,
						'default' => esc_html__('', 'visaland-core')
						],	

						'block_title' =>
						[
							'name' => 'block_title',
							'label' => esc_html__('Title', 'visaland-core'),
							'type' => Controls_Manager::TEXTAREA,
							'default' => esc_html__('', 'visaland-core')
						],
						
						'block_subtitle' =>
						
						[
							'name' => 'block_subtitle',
							'label' => esc_html__('Subtitle', 'visaland-core'),
							'type' => Controls_Manager::TEXTAREA,
							'default' => esc_html__('', 'visaland-core')
						],	
						
						'block_button_link6' =>
						[
						  'name' => 'block_button_link6',
						  'label' => __( 'Team Url', 'visaland-core' ),
						  'type' => Controls_Manager::URL,
						  'placeholder' => __( 'https://your-link.com', 'visaland-core' ),
						  'show_external' => true,
						  'default' => [
							'url' => '',
							'is_external' => true,
							'nofollow' => true,
						  ],
					   ],	
					   
					   'block_button_link' =>
						
					   [
						 'name' => 'block_button_link',
						 'label' => __( 'Facebook Url', 'visaland-core' ),
						 'type' => Controls_Manager::URL,
						 'placeholder' => __( 'https://your-link.com', 'visaland-core' ),
						 'show_external' => true,
						 'default' => [
						   'url' => '#',
						   'is_external' => true,
						   'nofollow' => true,
						 ],
					  ],
			   
					   'block_button_link2' =>
					   
					   [
						 'name' => 'block_button_link2',
						 'label' => __( 'Twitter Url', 'visaland-core' ),
						 'type' => Controls_Manager::URL,
						 'placeholder' => __( 'https://your-link.com', 'visaland-core' ),
						 'show_external' => true,
						 'default' => [
						   'url' => '',
						   'is_external' => true,
						   'nofollow' => true,
						 ],
					  ],
			   
					   'block_button_link3' =>
					   
					   [
						 'name' => 'block_button_link3',
						 'label' => __( 'Youtube Url', 'visaland-core' ),
						 'type' => Controls_Manager::URL,
						 'placeholder' => __( 'https://your-link.com', 'visaland-core' ),
						 'show_external' => true,
						 'default' => [
						   'url' => '',
						   'is_external' => true,
						   'nofollow' => true,
						 ],
					  ],
			   
					   'block_button_link4' =>
					   
					   [
						 'name' => 'block_button_link4',
						 'label' => __( 'linkedIn Url', 'visaland-core' ),
						 'type' => Controls_Manager::URL,
						 'placeholder' => __( 'https://your-link.com', 'visaland-core' ),
						 'show_external' => true,
						 'default' => [
						   'url' => '',
						   'is_external' => true,
						   'nofollow' => true,
						 ],
					  ],
			   
					   'block_button_link5' =>
					   
					   [
						 'name' => 'block_button_link5',
						 'label' => __( 'Instagram Url', 'visaland-core' ),
						 'type' => Controls_Manager::URL,
						 'placeholder' => __( 'https://your-link.com', 'visaland-core' ),
						 'show_external' => true,
						 'default' => [
						   'url' => '',
						   'is_external' => true,
						   'nofollow' => true,
						 ],
					  ],
						
					],
				'title_field' => '{{block_title}}',
			 ]
	);
		
		
	$this->end_controls_section();	


	    //========== Title Settings ==========================
		$this->start_controls_section(
			'title_settings',
			[
				'label' => __( 'Title Settings', 'visaland-core' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
	
		// Show/Hide Title Control
		$this->add_control(
			'show_title',
			[
				'label'     => esc_html__( 'Show Title', 'visaland-core' ),
				'type'      => \Elementor\Controls_Manager::CHOOSE,
				'options'   => [
					'show' => [
						'title' => esc_html__( 'Show', 'visaland-core' ),
						'icon'  => 'eicon-check-circle',
					],
					'none' => [
						'title' => esc_html__( 'Hide', 'visaland-core' ),
						'icon'  => 'eicon-close-circle',
					],
				],
				'default'   => 'show',
				'selectors' => [
					'{{WRAPPER}} h3 a' => 'display: {{VALUE}} !important',
				],
			]
		);
	
		// Title Alignment Control
		$this->add_control(
			'title_alignment',
			[
				'label'     => esc_html__( 'Alignment', 'visaland-core' ),
				'type'      => \Elementor\Controls_Manager::CHOOSE,
				'options'   => [
					'left'   => [
						'title' => esc_html__( 'Left', 'visaland-core' ),
						'icon'  => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'visaland-core' ),
						'icon'  => 'eicon-text-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'visaland-core' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'default'   => '',
				'condition' => ['show_title' => 'show'],
				'toggle'    => true,
				'selectors' => [
					'{{WRAPPER}} h3 a' => 'text-align: {{VALUE}}',
				],
			]
		);
	
		// Title Margin Control
		$this->add_control(
			'title_margin',
			[
				'label'       => __( 'Margin', 'visaland-core' ),
				'type'        => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units'  => ['px', '%', 'em'],
				'condition'   => ['show_title' => 'show'],
				'selectors'   => [
					'{{WRAPPER}} h3 a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important',
				],
			]
		);
	
		// Title Padding Control
		$this->add_control(
			'title_padding',
			[
				'label'       => __( 'Padding', 'visaland-core' ),
				'type'        => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units'  => ['px', '%', 'em'],
				'condition'   => ['show_title' => 'show'],
				'selectors'   => [
					'{{WRAPPER}} h3 a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important',
				],
			]
		);
	
		// Title Typography Control
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'       => 'title_typography',
				'label'      => __( 'Typography', 'visaland-core' ),
				'condition'  => ['show_title' => 'show'],
				'selector'   => '{{WRAPPER}} h3 a',
			]
		);
	
		// Title Color Control
		$this->add_control(
			'title_color',
			[
				'label'      => __( 'Color', 'visaland-core' ),
				'type'       => \Elementor\Controls_Manager::COLOR,
				'condition'  => ['show_title' => 'show'],
				'selectors'  => [
					'{{WRAPPER}} h3 a' => 'color: {{VALUE}} !important',
				],
			]
		);
	
		// Title Hover Color Control
		$this->add_control(
			'title_hover_color',
			[
				'label'      => __( 'Hover Color', 'visaland-core' ),
				'type'       => \Elementor\Controls_Manager::COLOR,
				'condition'  => ['show_title' => 'show'],
				'selectors'  => [
					'{{WRAPPER}} h3 a:hover' => 'color: {{VALUE}} !important',
				],
			]
		);
	
		$this->end_controls_section();
		// End of Title Settings

		

		//========== Text Settings ==========================
$this->start_controls_section(
    'text_settings',
    [
        'label' => __( 'Text Settings', 'visaland-core' ),
        'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
    ]
);

// Show/Hide Text Control
$this->add_control(
    'show_text',
    [
        'label'     => esc_html__( 'Show Text', 'visaland-core' ),
        'type'      => \Elementor\Controls_Manager::CHOOSE,
        'options'   => [
            'show' => [
                'title' => esc_html__( 'Show', 'visaland-core' ),
                'icon'  => 'eicon-check-circle',
            ],
            'none' => [
                'title' => esc_html__( 'Hide', 'visaland-core' ),
                'icon'  => 'eicon-close-circle',
            ],
        ],
        'default'   => 'show',
        'selectors' => [
            '{{WRAPPER}} .team-content p' => 'display: {{VALUE}} !important',
        ],
    ]
);

// Text Alignment Control
$this->add_control(
    'text_alignment',
    [
        'label'     => esc_html__( 'Alignment', 'visaland-core' ),
        'type'      => \Elementor\Controls_Manager::CHOOSE,
        'options'   => [
            'left'   => [
                'title' => esc_html__( 'Left', 'visaland-core' ),
                'icon'  => 'eicon-text-align-left',
            ],
            'center' => [
                'title' => esc_html__( 'Center', 'visaland-core' ),
                'icon'  => 'eicon-text-align-center',
            ],
            'right'  => [
                'title' => esc_html__( 'Right', 'visaland-core' ),
                'icon'  => 'eicon-text-align-right',
            ],
        ],
        'default'   => '',
        'condition' => ['show_text' => 'show'],
        'toggle'    => true,
        'selectors' => [
            '{{WRAPPER}} .team-content p' => 'text-align: {{VALUE}} !important',
        ],
    ]
);

// Text Margin Control
$this->add_control(
    'text_margin',
    [
        'label'       => __( 'Margin', 'visaland-core' ),
        'type'        => \Elementor\Controls_Manager::DIMENSIONS,
        'size_units'  => ['px', '%', 'em'],
        'condition'   => ['show_text' => 'show'],
        'selectors'   => [
            '{{WRAPPER}} .team-content p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important',
        ],
    ]
);

// Text Padding Control
$this->add_control(
    'text_padding',
    [
        'label'       => __( 'Padding', 'visaland-core' ),
        'type'        => \Elementor\Controls_Manager::DIMENSIONS,
        'size_units'  => ['px', '%', 'em'],
        'condition'   => ['show_text' => 'show'],
        'selectors'   => [
            '{{WRAPPER}} .team-content p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important',
        ],
    ]
);

// Text Typography Control
$this->add_group_control(
    \Elementor\Group_Control_Typography::get_type(),
    [
        'name'       => 'text_typography',
        'label'      => __( 'Typography', 'visaland-core' ),
        'condition'  => ['show_text' => 'show'],
        'selector'   => '{{WRAPPER}} .team-content p',
    ]
);

// Text Color Control
$this->add_control(
    'text_color',
    [
        'label'      => __( 'Color', 'visaland-core' ),
        'type'       => \Elementor\Controls_Manager::COLOR,
        'condition'  => ['show_text' => 'show'],
        'separator'  => 'after',
        'selectors'  => [
            '{{WRAPPER}} .team-content p' => 'color: {{VALUE}} !important',
        ],
    ]
);

// Text Hover Color Control
$this->add_control(
    'text_hover_color',
    [
        'label'      => __( 'Hover Color', 'visaland-core' ),
        'type'       => \Elementor\Controls_Manager::COLOR,
        'condition'  => ['show_text' => 'show'],
        'separator'  => 'after',
        'selectors'  => [
            '{{WRAPPER}} .team-content p:hover' => 'color: {{VALUE}} !important',
        ],
    ]
);

$this->end_controls_section();
// End of Text Settings


// Section Title Settings ==================
$this->start_controls_section(
    'section_title_settings',
    array(
        'label' => __( 'Section Title Setting', 'visaland-core' ),
        'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
    )
);

// Show Section Title Control
$this->add_control(
    'show_section_title',
    array(
        'label' => esc_html__( 'Show Section Title', 'visaland-core' ),
        'type' => \Elementor\Controls_Manager::CHOOSE,
        'options' => [
            'show' => [
                'show' => esc_html__( 'Show', 'visaland-core' ),
                'icon' => 'eicon-check-circle',
            ],
            'none' => [
                'none' => esc_html__( 'Hide', 'visaland-core' ),
                'icon' => 'eicon-close-circle',
            ],
        ],
        'default' => 'show',
        'selectors' => [
            '{{WRAPPER}} h5 a' => 'display: {{VALUE}} !important',
        ],        
    )
);

// Section Title Alignment Control
$this->add_control(
    'section_title_alignment',
    array(
        'label' => esc_html__( 'Alignment', 'visaland-core' ),
        'type' => \Elementor\Controls_Manager::CHOOSE,
        'options' => [
            'left' => [
                'title' => esc_html__( 'Left', 'visaland-core' ),
                'icon' => 'eicon-text-align-left',
            ],
            'center' => [
                'title' => esc_html__( 'Center', 'visaland-core' ),
                'icon' => 'eicon-text-align-center',
            ],
            'right' => [
                'title' => esc_html__( 'Right', 'visaland-core' ),
                'icon' => 'eicon-text-align-right',
            ],
        ],
        'default' => '',
        'condition' => [ 'show_section_title' => 'show' ],
        'toggle' => true,
        'selectors' => [
            '{{WRAPPER}} h5 a' => 'text-align: {{VALUE}} !important',
        ],
    )
);

// Section Title Margin Control
$this->add_control(
    'section_title_margin',
    array(
        'label' => __( 'Margin', 'visaland-core' ),
        'condition' => [ 'show_section_title' => 'show' ],
        'type' => \Elementor\Controls_Manager::DIMENSIONS,
        'size_units' => ['px', '%', 'em'],
        'selectors' => [
            '{{WRAPPER}} h5 a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important',
        ],
    )
);

// Section Title Padding Control
$this->add_control(
    'section_title_padding',
    array(
        'label' => __( 'Padding', 'visaland-core' ),
        'condition' => [ 'show_section_title' => 'show' ],
        'type' => \Elementor\Controls_Manager::DIMENSIONS,
        'size_units' => ['px', '%', 'em'],
        'selectors' => [
            '{{WRAPPER}} h5 a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important',
        ],
    )
);

// Typography Control
$this->add_group_control(
    \Elementor\Group_Control_Typography::get_type(),
    array(
        'name' => 'section_title_typography',
        'condition' => [ 'show_section_title' => 'show' ],
        'label' => __( 'Typography', 'visaland-core' ),
        'selector' => '{{WRAPPER}} h5 a',
    )
);

// Section Title Color Control
$this->add_control(
    'section_title_color',
    array(
        'label' => __( 'Color', 'visaland-core' ),
        'condition' => [ 'show_section_title' => 'show' ],
        'type' => \Elementor\Controls_Manager::COLOR,
        'selectors' => [
            '{{WRAPPER}} h5 a' => 'color: {{VALUE}} !important',
        ],
    )
);

$this->end_controls_section();
// End of Section Title Setting ==================


	
		}

	/**
	 * Render button widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$allowed_tags = wp_kses_allowed_html('post');
		?>



<?php  if ( 'style1' === $settings['style'] ) : ?>	

	<div class="row">
		<?php foreach($settings['repeat'] as $item):?>	
		<div class="<?php echo esc_attr($settings['column_grid']); ?> col-md-6 wow fadeInUp" data-wow-delay=".3s">
			<div class="team-box-items <?php echo esc_attr($item['block_class']); ?>">
				<div class="team-image">
					<?php if(!empty(wp_get_attachment_url($item['block_image']['id']))): ?>
						<img src="<?php echo wp_get_attachment_url($item['block_image']['id']);?>" alt="<?php echo wp_kses($item['block_alt_text'], $allowed_tags);?>">
					<?php endif;?>
					<ul class="social-icon d-grid justify-content-center align-items-center">
						<?php if (!empty($item['block_button_link']['url'])) : ?>
							<li><a href="<?php echo esc_url($item['block_button_link']['url']);?>"><i class="fab fa-facebook-f"></i></a></li>
						<?php endif; ?> 
						<?php if (!empty($item['block_button_link2']['url'])) : ?>
							<li><a href="<?php echo esc_url($item['block_button_link2']['url']);?>"><i class="fab fa-twitter"></i></a></li>
						<?php endif; ?> 
						<?php if (!empty($item['block_button_link3']['url'])) : ?>
							<li><a href="<?php echo esc_url($item['block_button_link3']['url']);?>"><i class="fab fa-youtube"></i></a></li>
						<?php endif; ?> 
						<?php if (!empty($item['block_button_link4']['url'])) : ?>
							<li><a href="<?php echo esc_url($item['block_button_link4']['url']);?>"><i class="fab fa-linkedin-in"></i></a></li>
						<?php endif; ?> 
						<?php if (!empty($item['block_button_link5']['url'])) : ?>
							<li><a href="<?php echo esc_url($item['block_button_link5']['url']);?>"><i class="fab fa-instagram"></i></a></li>
						<?php endif; ?> 
					</ul>
				</div>
				<div class="team-content">
					<h3><a href="<?php echo esc_url($item['block_button_link6']['url']);?>"><?php echo wp_kses($item['block_title'], $allowed_tags);?></a></h3>
					<p><?php echo wp_kses($item['block_subtitle'], $allowed_tags);?></p>
				</div>
			</div>
		</div>
		<?php endforeach; ?>
	</div>

<?php  elseif ( 'style2' === $settings['style'] ) : ?>		

	<div class="row align-items-center">
		<?php foreach($settings['repeat'] as $item):?>	
		<div class="<?php echo esc_attr($settings['column_grid']); ?> col-md-6 wow fadeInUp" data-wow-delay=".2s">
			<div class="single-team-items">
				<div class="team-image">
					<?php if(!empty(wp_get_attachment_url($item['block_image']['id']))): ?>
						<img src="<?php echo wp_get_attachment_url($item['block_image']['id']);?>" alt="<?php echo wp_kses($item['block_alt_text'], $allowed_tags);?>">
					<?php endif;?>
					<div class="social-profile">
						<span class="plus-btn"><i class="fas fa-share-alt"></i></span>
						<ul>
						<?php if (!empty($item['block_button_link']['url'])) : ?>
							<li><a href="<?php echo esc_url($item['block_button_link']['url']);?>"><i class="fab fa-facebook-f"></i></a></li>
						<?php endif; ?> 
						<?php if (!empty($item['block_button_link2']['url'])) : ?>
							<li><a href="<?php echo esc_url($item['block_button_link2']['url']);?>"><i class="fab fa-twitter"></i></a></li>
						<?php endif; ?> 
						<?php if (!empty($item['block_button_link3']['url'])) : ?>
							<li><a href="<?php echo esc_url($item['block_button_link3']['url']);?>"><i class="fab fa-youtube"></i></a></li>
						<?php endif; ?> 
						<?php if (!empty($item['block_button_link4']['url'])) : ?>
							<li><a href="<?php echo esc_url($item['block_button_link4']['url']);?>"><i class="fab fa-linkedin-in"></i></a></li>
						<?php endif; ?> 
						<?php if (!empty($item['block_button_link5']['url'])) : ?>
							<li><a href="<?php echo esc_url($item['block_button_link5']['url']);?>"><i class="fab fa-instagram"></i></a></li>
						<?php endif; ?> 
						</ul>
					</div>
				</div>
				<div class="team-content text-center">
					<h5>
						<a href="<?php echo esc_url($item['block_button_link6']['url']);?>"><?php echo wp_kses($item['block_title'], $allowed_tags);?></a>
					</h5>
					<p><?php echo wp_kses($item['block_subtitle'], $allowed_tags);?></p>
				</div>
			</div>
		</div>
		<?php endforeach; ?>
	</div>

	<?php  elseif ( 'style3' === $settings['style'] ) : ?>	

		<div class="row">
			<?php foreach($settings['repeat'] as $item):?>	
			<div class="<?php echo esc_attr($settings['column_grid']); ?> col-md-6 wow fadeInUp" data-wow-delay=".3s">
				<div class="team-card-items">
					<div class="team-content">
					<h4>
						<a href="<?php echo esc_url($item['block_button_link6']['url']);?>"><?php echo wp_kses($item['block_title'], $allowed_tags);?></a>
					</h4>
					<p><?php echo wp_kses($item['block_subtitle'], $allowed_tags);?></p>
					</div>
					<div class="team-image">
					<?php if(!empty(wp_get_attachment_url($item['block_image']['id']))): ?>
						<img src="<?php echo wp_get_attachment_url($item['block_image']['id']);?>" alt="<?php echo wp_kses($item['block_alt_text'], $allowed_tags);?>">
					<?php endif;?>
						<div class="social-profile">
							<span class="plus-btn"><i class="fas fa-share-alt"></i></span>
							<ul>
							<?php if (!empty($item['block_button_link']['url'])) : ?>
								<li><a href="<?php echo esc_url($item['block_button_link']['url']);?>"><i class="fab fa-facebook-f"></i></a></li>
							<?php endif; ?> 
							<?php if (!empty($item['block_button_link2']['url'])) : ?>
								<li><a href="<?php echo esc_url($item['block_button_link2']['url']);?>"><i class="fab fa-twitter"></i></a></li>
							<?php endif; ?> 
							<?php if (!empty($item['block_button_link3']['url'])) : ?>
								<li><a href="<?php echo esc_url($item['block_button_link3']['url']);?>"><i class="fab fa-youtube"></i></a></li>
							<?php endif; ?> 
							<?php if (!empty($item['block_button_link4']['url'])) : ?>
								<li><a href="<?php echo esc_url($item['block_button_link4']['url']);?>"><i class="fab fa-linkedin-in"></i></a></li>
							<?php endif; ?> 
							<?php if (!empty($item['block_button_link5']['url'])) : ?>
								<li><a href="<?php echo esc_url($item['block_button_link5']['url']);?>"><i class="fab fa-instagram"></i></a></li>
							<?php endif; ?> 
							</ul>
						</div>
					</div>
				</div>
			</div>
			<?php endforeach; ?>
		</div>

		<?php  elseif ( 'style4' === $settings['style'] ) : ?>	

			<div class="row">
				<?php foreach($settings['repeat'] as $item):?>	
				<div class="<?php echo esc_attr($settings['column_grid']); ?> col-md-6 wow fadeInUp" data-wow-delay=".2s">
					<div class="team-box-items-2">
						<div class="team-thumb">
						<?php if(!empty(wp_get_attachment_url($item['block_image']['id']))): ?>
							<img src="<?php echo wp_get_attachment_url($item['block_image']['id']);?>" alt="<?php echo wp_kses($item['block_alt_text'], $allowed_tags);?>">
						<?php endif;?>
						</div>
						<div class="team-content">
							<h3>
							<a href="<?php echo esc_url($item['block_button_link6']['url']);?>"><?php echo wp_kses($item['block_title'], $allowed_tags);?></a>
							</h3>
							<p><?php echo wp_kses($item['block_subtitle'], $allowed_tags);?></p>
							<ul class="social-icon d-flex justify-content-center align-items-center">
							<?php if (!empty($item['block_button_link']['url'])) : ?>
								<li><a href="<?php echo esc_url($item['block_button_link']['url']);?>"><i class="fab fa-facebook-f"></i></a></li>
							<?php endif; ?> 
							<?php if (!empty($item['block_button_link2']['url'])) : ?>
								<li><a href="<?php echo esc_url($item['block_button_link2']['url']);?>"><i class="fab fa-twitter"></i></a></li>
							<?php endif; ?> 
							<?php if (!empty($item['block_button_link3']['url'])) : ?>
								<li><a href="<?php echo esc_url($item['block_button_link3']['url']);?>"><i class="fab fa-youtube"></i></a></li>
							<?php endif; ?> 
							<?php if (!empty($item['block_button_link4']['url'])) : ?>
								<li><a href="<?php echo esc_url($item['block_button_link4']['url']);?>"><i class="fab fa-linkedin-in"></i></a></li>
							<?php endif; ?> 
							<?php if (!empty($item['block_button_link5']['url'])) : ?>
								<li><a href="<?php echo esc_url($item['block_button_link5']['url']);?>"><i class="fab fa-instagram"></i></a></li>
							<?php endif; ?> 
							</ul>
						</div>
					</div>
				</div>
				<?php endforeach; ?>
			</div>

<?php endif ;?>	

             
		<?php 
	}


}

Plugin::instance()->widgets_manager->register_widget_type(new Team_Grid());