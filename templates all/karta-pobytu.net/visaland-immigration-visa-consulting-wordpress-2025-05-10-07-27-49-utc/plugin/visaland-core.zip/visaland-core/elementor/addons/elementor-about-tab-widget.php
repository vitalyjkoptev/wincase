<?php
namespace Elementor;

/**
 * Elementor Widget
 * @package Visaland
 * @since 1.0.0
 */ 
 
class About_Tab extends Widget_Base {

	/**
	 * Get widget name.
	 * Retrieve button widget name.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'visaland-about-tab-widget';
	}

	/**
	 * Get widget title.
	 * Retrieve button widget title.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'About Tab', 'visaland-core' );
	}

	/**
	 * Get widget icon.
	 * Retrieve button widget icon.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-flash';
	}

	/**
	 * Get widget categories.
	 * Retrieve the list of categories the button widget belongs to.
	 * Used to determine where to display the widget in the editor.
	 *
	 * @since  2.0.0
	 * @access public
	 * @return array Widget categories.
	 */
	public function get_categories()
    {
        return ['visaland_widgets'];
    }
	
	/**
	 * Register button widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function register_controls() {

		// Tab Start - 1

		$this->start_controls_section(
			'about_tab',
			[
				'label' => esc_html__( 'About Tab', 'visaland-core' ),
			]
		);		
		
		$this->add_control(
			'style',
			[
				'label'   => esc_html__( 'Select Style', 'visaland-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'style1',
				'options' => array(
					'style1'   => esc_html__( 'Style One', 'visaland-core' ),
				),
			]
		);

		$this->end_controls_section();

		// Tab Start - 2

		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Block', 'visaland-core' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
		  'repeat', 
			[
				'type' => Controls_Manager::REPEATER,
				'separator' => 'before',
				'default' => 
					[
						['block_title' => esc_html__('Hello World', 'visaland-core')],
					],
				'fields' => 
					[						

						'block_title' =>
						[
							'name' => 'block_title',
							'label' => esc_html__('Title', 'visaland-core'),
							'type' => Controls_Manager::TEXTAREA,
							'default' => esc_html__('', 'visaland-core')
						],

						'block_image' =>
						[
							'name' => 'block_image',
							'label' => __( 'Image', 'visaland-core' ),
							'type' => Controls_Manager::MEDIA,
							'default' => ['url' => Utils::get_placeholder_image_src(),],
						  ],	

						'block_alt_text' =>

						[
						'name' => 'block_alt_text',
						'label' => esc_html__('Image Text', 'visaland-core'),
						'type' => Controls_Manager::TEXTAREA,
						'default' => esc_html__('', 'visaland-core')
						],

						'block_button_link' =>

						[
							'name' => 'block_button_link',
							'label' => __( 'Video Url', 'visaland-core' ),
							'type' => Controls_Manager::URL,
							'placeholder' => __( 'https://your-link.com', 'visaland-core' ),
							'show_external' => true,
							'default' => [
							  'url' => '',
							  'is_external' => true,
							  'nofollow' => true,
							],
						 ],

						'block_text' =>
						[
							'name' => 'block_text',
							'label' => esc_html__('Text', 'visaland-core'),
							'type' => Controls_Manager::TEXTAREA,
							'default' => esc_html__('', 'visaland-core')
						],	
						
					],
				'title_field' => '{{block_title}}',
			 ]
	);
		
		
	$this->end_controls_section();	

	
		}

	/**
	 * Render button widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$allowed_tags = wp_kses_allowed_html('post');
		?>


<?php  if ( 'style1' === $settings['style'] ) : ?>	

<div class="about-wrapper-2">
	<div class="about-content">
		<div class="single-tab-items">

			<ul class="nav mb-4" role="tablist">
				<?php foreach($settings['repeat'] as $key=>$item):?>
				<li class="nav-item wow fadeInUp" data-wow-delay=".3s" role="presentation">
					<a href="#integrity<?php echo esc_attr($key);?>" data-bs-toggle="tab" class="nav-link <?php if($key == 1) echo 'active';?>" aria-selected="true" role="tab">
						<?php echo wp_kses($item['block_title'], $allowed_tags);?>
					</a>
				</li>
				<?php endforeach; ?>	
			</ul>

		</div>
		<div class="tab-content">
			<?php foreach($settings['repeat'] as $key=>$item):?>
			<div id="integrity<?php echo esc_attr($key);?>" class="tab-pane fade show <?php if($key == 1) echo 'active';?>" role="tabpanel">
				<div class="about-tabs-area">
					<div class="about-list-items">
						<div class="video-image wow fadeInUp" data-wow-delay=".3s">
							<?php if(!empty(wp_get_attachment_url($item['block_image']['id']))): ?>
								<img src="<?php echo wp_get_attachment_url($item['block_image']['id']);?>" alt="<?php echo wp_kses($item['block_alt_text'], $allowed_tags);?>">
							<?php endif;?>
							<div class="video-box">
								<a href="<?php echo esc_url($item['block_button_link']['url']);?>" class="video-btn ripple video-popup">
									<i class="fas fa-play"></i>
								</a>
							</div>
						</div>
						<ul class="wow fadeInUp" data-wow-delay=".4s">
							<?php echo wp_kses($item['block_text'], $allowed_tags);?>
						</ul>
					</div>
				</div>
			</div>
			<?php endforeach; ?>	
		</div>
	</div>
</div>

<?php  elseif ( 'style2' === $settings['style'] ) : ?>		



<?php endif ;?>	

             
		<?php 
	}


}

Plugin::instance()->widgets_manager->register_widget_type(new About_Tab());