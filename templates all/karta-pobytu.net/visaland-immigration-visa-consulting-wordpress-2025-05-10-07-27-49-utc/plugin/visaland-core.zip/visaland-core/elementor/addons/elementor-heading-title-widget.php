<?php
namespace Elementor;

/**
 * Elementor Widget
 * @package Visaland
 * @since 1.0.0
 */ 
 
class Heading_Title extends Widget_Base {

	/**
	 * Get widget name.
	 * Retrieve button widget name.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'visaland-heading-title-widget';
	}

	/**
	 * Get widget title.
	 * Retrieve button widget title.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Heading Title', 'visaland-core' );
	}

	/**
	 * Get widget icon.
	 * Retrieve button widget icon.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-site-title';
	}

	/**
	 * Get widget categories.
	 * Retrieve the list of categories the button widget belongs to.
	 * Used to determine where to display the widget in the editor.
	 *
	 * @since  2.0.0
	 * @access public
	 * @return array Widget categories.
	 */
	public function get_categories()
    {
        return ['visaland_widgets'];
    }
	
	/**
	 * Register button widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function register_controls() {

		// Tab Start - 1

		$this->start_controls_section(
			'image_styles',
			[
				'label' => esc_html__( 'Heading Styles', 'visaland-core' ),
			]
		);	
		
		$this->add_control(
			'style',
			[
				'label'   => esc_html__( 'Select Style', 'visaland-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'style1',
				'options' => array(
					'style1'   => esc_html__( 'Style One', 'visaland-core' ),
					'style2'   => esc_html__( 'Style Two', 'visaland-core' ),
					'style3'   => esc_html__( 'Style Three', 'visaland-core' ),
				),
			]
		);

		$this->add_control(
			'subtitle',
			[
				'label'       => __( 'Sub Title', 'visaland-core' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your sub title', 'visaland-core' ),
			]
		);
	
		$this->add_control(
				'title',
				[
					'label'       => __( 'Title', 'visaland-core' ),
					'type'        => Controls_Manager::TEXTAREA,
					'dynamic'     => [
						'active' => true,
					],
					'placeholder' => __( 'Enter your title', 'visaland-core' ),
				]
			);


		$this->end_controls_section();



		    // Subtitle Settings ================== 

			$this->start_controls_section(
				'subtitle_settings',
				[
					'label' => __( 'Sub Title Setting', 'visaland-core' ),
					'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
				]
			);
		
			// Show Sub Title Control
			$this->add_control(
				'show_subtitle',
				[
					'label'     => esc_html__( 'Show Sub Title', 'visaland-core' ),
					'type'      => \Elementor\Controls_Manager::CHOOSE,
					'options'   => [
						'show' => [
							'title' => esc_html__( 'Show', 'visaland-core' ),
							'icon'  => 'eicon-check-circle',
						],
						'none' => [
							'title' => esc_html__( 'Hide', 'visaland-core' ),
							'icon'  => 'eicon-close-circle',
						],
					],
					'default'   => 'show',
					'selectors' => [
						'{{WRAPPER}} .section-title span' => 'display: {{VALUE}} !important',
					],
				]
			);
		
			// Subtitle Alignment Control
			$this->add_control(
				'subtitle_alignment',
				[
					'label'     => esc_html__( 'Alignment', 'visaland-core' ),
					'type'      => \Elementor\Controls_Manager::CHOOSE,
					'options'   => [
						'left'   => [
							'title' => esc_html__( 'Left', 'visaland-core' ),
							'icon'  => 'eicon-text-align-left',
						],
						'center' => [
							'title' => esc_html__( 'Center', 'visaland-core' ),
							'icon'  => 'eicon-text-align-center',
						],
						'right'  => [
							'title' => esc_html__( 'Right', 'visaland-core' ),
							'icon'  => 'eicon-text-align-right',
						],
					],
					'default'   => 'left',
					'condition' => [ 'show_subtitle' => 'show' ],
					'toggle'    => true,
					'selectors' => [
						'{{WRAPPER}} .section-title span' => 'text-align: {{VALUE}} !important',
					],
				]
			);
		
			// Subtitle Padding Control
			$this->add_control(
				'subtitle_padding',
				[
					'label'       => __( 'Padding', 'visaland-core' ),
					'type'        => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units'  => [ 'px', '%', 'em' ],
					'condition'   => [ 'show_subtitle' => 'show' ],
					'selectors'   => [
						'{{WRAPPER}} .section-title span' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important',
					],
				]
			);
		
			// Subtitle Margin Control
			$this->add_control(
				'subtitle_margin',
				[
					'label'       => __( 'Margin', 'visaland-core' ),
					'type'        => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units'  => [ 'px', '%', 'em' ],
					'condition'   => [ 'show_subtitle' => 'show' ],
					'selectors'   => [
						'{{WRAPPER}} .section-title span' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important',
					],
				]
			);
		
			// Subtitle Typography Control
			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name'       => 'subtitle_typography',
					'label'      => __( 'Typography', 'visaland-core' ),
					'selector'   => '{{WRAPPER}} .section-title span',
					'condition'  => [ 'show_subtitle' => 'show' ],
				]
			);
		
			// Subtitle Color Control
			$this->add_control(
				'subtitle_color',
				[
					'label'      => __( 'Color', 'visaland-core' ),
					'type'       => \Elementor\Controls_Manager::COLOR,
					'separator'  => 'after',
					'condition'  => [ 'show_subtitle' => 'show' ],
					'selectors'  => [
						'{{WRAPPER}} .section-title span' => 'color: {{VALUE}} !important',
					],
				]
			);
		
			// Subtitle Background Color Control
			$this->add_control(
				'subtitle_bg_color',
				[
					'label'      => __( 'Background Color', 'visaland-core' ),
					'type'       => \Elementor\Controls_Manager::COLOR,
					'separator'  => 'after',
					'condition'  => [ 'show_subtitle' => 'show' ],
					'selectors'  => [
						'{{WRAPPER}} .section-title span' => 'background-color: {{VALUE}} !important',
					],
				]
			);
		
			$this->end_controls_section();
		
			// End of Subtitle Settings ==================

			
    //========== Title Settings ==========================
    $this->start_controls_section(
        'title_settings',
        [
            'label' => __( 'Title Settings', 'visaland-core' ),
            'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
        ]
    );

    // Show/Hide Title Control
    $this->add_control(
        'show_title',
        [
            'label'     => esc_html__( 'Show Title', 'visaland-core' ),
            'type'      => \Elementor\Controls_Manager::CHOOSE,
            'options'   => [
                'show' => [
                    'title' => esc_html__( 'Show', 'visaland-core' ),
                    'icon'  => 'eicon-check-circle',
                ],
                'none' => [
                    'title' => esc_html__( 'Hide', 'visaland-core' ),
                    'icon'  => 'eicon-close-circle',
                ],
            ],
            'default'   => 'show',
            'selectors' => [
                '{{WRAPPER}} .section-title h2' => 'display: {{VALUE}} !important',
            ],
        ]
    );

    // Title Alignment Control
    $this->add_control(
        'title_alignment',
        [
            'label'     => esc_html__( 'Alignment', 'visaland-core' ),
            'type'      => \Elementor\Controls_Manager::CHOOSE,
            'options'   => [
                'left'   => [
                    'title' => esc_html__( 'Left', 'visaland-core' ),
                    'icon'  => 'eicon-text-align-left',
                ],
                'center' => [
                    'title' => esc_html__( 'Center', 'visaland-core' ),
                    'icon'  => 'eicon-text-align-center',
                ],
                'right'  => [
                    'title' => esc_html__( 'Right', 'visaland-core' ),
                    'icon'  => 'eicon-text-align-right',
                ],
            ],
            'default'   => '',
            'condition' => ['show_title' => 'show'],
            'toggle'    => true,
            'selectors' => [
                '{{WRAPPER}} .section-title h2' => 'text-align: {{VALUE}}',
            ],
        ]
    );

    // Title Margin Control
    $this->add_control(
        'title_margin',
        [
            'label'       => __( 'Margin', 'visaland-core' ),
            'type'        => \Elementor\Controls_Manager::DIMENSIONS,
            'size_units'  => ['px', '%', 'em'],
            'condition'   => ['show_title' => 'show'],
            'selectors'   => [
                '{{WRAPPER}} .section-title h2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important',
            ],
        ]
    );

    // Title Padding Control
    $this->add_control(
        'title_padding',
        [
            'label'       => __( 'Padding', 'visaland-core' ),
            'type'        => \Elementor\Controls_Manager::DIMENSIONS,
            'size_units'  => ['px', '%', 'em'],
            'condition'   => ['show_title' => 'show'],
            'selectors'   => [
                '{{WRAPPER}} .section-title h2' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important',
            ],
        ]
    );

    // Title Typography Control
    $this->add_group_control(
        \Elementor\Group_Control_Typography::get_type(),
        [
            'name'       => 'title_typography',
            'label'      => __( 'Typography', 'visaland-core' ),
            'condition'  => ['show_title' => 'show'],
            'selector'   => '{{WRAPPER}} .section-title h2',
        ]
    );

    // Title Color Control
    $this->add_control(
        'title_color',
        [
            'label'      => __( 'Color', 'visaland-core' ),
            'type'       => \Elementor\Controls_Manager::COLOR,
            'condition'  => ['show_title' => 'show'],
            'selectors'  => [
                '{{WRAPPER}} .section-title h2' => 'color: {{VALUE}} !important',
            ],
        ]
    );

    // Title Hover Color Control
    $this->add_control(
        'title_hover_color',
        [
            'label'      => __( 'Hover Color', 'visaland-core' ),
            'type'       => \Elementor\Controls_Manager::COLOR,
            'condition'  => ['show_title' => 'show'],
            'selectors'  => [
                '{{WRAPPER}} .section-title h2:hover' => 'color: {{VALUE}} !important',
            ],
        ]
    );

    $this->end_controls_section();
    // End of Title Settings

	
		}

	/**
	 * Render button widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$allowed_tags = wp_kses_allowed_html('post');
		?>

<?php  if ( 'style1' === $settings['style'] ) : ?>	

	<div class="section-title">
		<span class="wow fadeInUp"><?php echo $settings['subtitle'];?></span>
		<h2 class="title-anim">
			<?php echo $settings['title'];?>
		</h2>
	</div>

<?php  elseif ( 'style2' === $settings['style'] ) : ?>		

	<div class="section-title text-center">
		<span class="wow fadeInUp"><?php echo $settings['subtitle'];?></span>
		<h2 class="title-anim">
			<?php echo $settings['title'];?>
		</h2>
	</div>

<?php  elseif ( 'style3' === $settings['style'] ) : ?>	

	<div class="section-title text-center">
		<span class="color-style wow fadeInUp"><?php echo $settings['subtitle'];?></span>
		<h2 class="text-white title-anim">
			<?php echo $settings['title'];?>
		</h2>
	</div>

<?php endif ;?>	
             
		<?php 
	}


}

Plugin::instance()->widgets_manager->register_widget_type(new Heading_Title());