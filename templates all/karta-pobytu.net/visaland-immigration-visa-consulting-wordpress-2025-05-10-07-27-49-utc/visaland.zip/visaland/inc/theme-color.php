<?php

function enqueue_custom_color_stylesheet() {

    wp_enqueue_style('visaland-style', get_stylesheet_uri());

    // Retrieve theme color options with fallbacks
    $theme_body_color   = cs_get_option('theme_body_color') ?: '#FFFFFF';
    $theme_black_color  = cs_get_option('theme_black_color') ?: '#000000';
    $theme_white_color  = cs_get_option('theme_white_color') ?: '#FFFFFF';
    $theme_color_1      = cs_get_option('theme_color_1') ?: '#E20935';
    $theme_color_2      = cs_get_option('theme_color_2') ?: '#E20935';
    $theme_header_color = cs_get_option('theme_header_color') ?: '#16171A';
    $theme_text_color   = cs_get_option('theme_text_color') ?: '#5E5F63';
    $theme_text_color_2   = cs_get_option('theme_text_color_2') ?: '#8A8C94';
    $theme_border_color = cs_get_option('theme_border_color') ?: '#EEEFF4';
    $theme_bg_color     = cs_get_option('theme_bg_color') ?: '#F5F5F7';

    wp_enqueue_style('custom-color-theme', get_template_directory_uri() . '/inc/theme-stylesheets/theme-color.css');

    // Inline CSS for theme colors
    $custom_css = "
    :root {
        --body: " . esc_attr($theme_body_color) . ";
        --black: " . esc_attr($theme_black_color) . ";
        --white: " . esc_attr($theme_white_color) . ";
        --theme: " . esc_attr($theme_color_1) . ";
        --theme2: " . esc_attr($theme_color_2) . ";
        --header: " . esc_attr($theme_header_color) . ";
        --text: " . esc_attr($theme_text_color) . ";
        --text2: " . esc_attr($theme_text_color_2) . ";
        --border: " . esc_attr($theme_border_color) . ";
        --bg: " . esc_attr($theme_bg_color) . ";
    } ";

    wp_add_inline_style('custom-color-theme', $custom_css);
}
add_action('wp_enqueue_scripts', 'enqueue_custom_color_stylesheet');
?>
