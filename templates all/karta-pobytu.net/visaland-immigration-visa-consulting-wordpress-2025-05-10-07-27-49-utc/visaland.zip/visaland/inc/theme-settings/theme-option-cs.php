<?php
/**
 * Theme Options
 * @package visaland
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit(); // exit if access directly
}
// Control core classes for avoid errors
if (class_exists('CSF')) {

    $allowed_html = visaland()->kses_allowed_html(array('mark'));
    $prefix = 'visaland';
    // Create options
    CSF::createOptions($prefix . '_theme_options', array(
        'menu_title' => esc_html__('Theme Options', 'visaland'),
        'menu_slug' => 'visaland_theme_options',
        'menu_parent' => 'visaland_theme_options',
        'menu_type' => 'submenu',
        'footer_credit' => ' ',
        'menu_icon' => 'fa fa-filter',
        'show_footer' => false,
        'enqueue_webfont' => false,
        'show_search' => true,
        'show_reset_all' => true,
        'show_reset_section' => true,
        'show_all_options' => false,
        'theme' => 'dark',
        'framework_title' => visaland()->get_theme_info('name')
    ));

    /*-------------------------------------------------------
        ** General  Options
    --------------------------------------------------------*/
    CSF::createSection($prefix . '_theme_options', array(
        'title' => esc_html__('General', 'visaland'),
        'id' => 'general_options',
        'icon' => 'fas fa-cogs',
    ));
    /* Preloader */
    CSF::createSection($prefix . '_theme_options', array(
        'title' => esc_html__('Preloader & SVG Enable', 'visaland'),
        'id' => 'theme_general_preloader_options',
        'icon' => 'fa fa-spinner',
        'parent' => 'general_options',
        'fields' => array(
            array(
                'type' => 'subheading',
                'content' => '<h3>' . esc_html__('Preloader Options', 'visaland') . '</h3>'
            ),
            array(
                'id' => 'preloader_enable',
                'title' => esc_html__('Preloader', 'visaland'),
                'type' => 'switcher',
                'desc' => wp_kses(__('you can set <mark>Yes / No</mark> to enable/disable preloader', 'visaland'), $allowed_html),
                'default' => false,
            ),
            array(
                'id' => 'preloader_bg_color',
                'title' => esc_html__('Preloader Background Color', 'visaland'),
                'type' => 'color',
                'default' => '',
                'desc' => wp_kses(__('you can set <mark>overlay color</mark> for preloader background image', 'visaland'), $allowed_html),
                'dependency' => array('preloader_enable', '==', 'true')
            ),

            array(
                'id'      => 'preloader_title',
                'type'    => 'text',
                'title'   => esc_html__('Preloader Title', 'visaland'),
                'desc'    => esc_html__('Enter the title to display during preloading. If left empty, the site name will be used.', 'visaland'),
                'default' => get_bloginfo('name'),
                'dependency' => array('preloader_enable', '==', 'true')
            ),

            array(
                'id'      => 'loading_text',
                'type'    => 'text',
                'title'   => esc_html__('Preloader Loading Text', 'visaland'),
                'desc'    => esc_html__('Enter the text to display below the loading animation.', 'visaland'),
                'default' => '',
                'dependency' => array('preloader_enable', '==', 'true')
            ),
              
            array(
                'id' => 'enable_svg_upload',
                'type' => 'switcher',
                'title' => esc_html__('Enable Svg Upload ?', 'visaland'),
                'desc' => esc_html__('If you want to enable or disable svg upload you can set ( YES / NO )', 'visaland'),
                'default' => true,
            ),
        )
    ));

    /*-------------------------------------------------------
           ** Typography  Options
    --------------------------------------------------------*/
    CSF::createSection($prefix . '_theme_options', array(
        'id' => 'typography',
        'title' => esc_html__('Typography', 'visaland'),
        'icon' => 'fas fa-text-height',
        'parent' => 'general_options',
        'fields' => array(
            array(
                'type' => 'subheading',
                'content' => '<h3>' . esc_html__('Body Font Options', 'visaland') . '</h3>',
            ),
            array(
                'type' => 'typography',
                'title' => esc_html__('Typography', 'visaland'),
                'id' => '_body_font',
                'default' => array(
                    'font-family' => 'Inter',
                    'font-size' => '16',
                    'line-height' => '26',
                    'unit' => 'px',
                    'type' => 'google',
                ),
                'color' => false,
                'subset' => false,
                'text_align' => false,
                'text_transform' => false,
                'letter_spacing' => false,
                'line_height' => false,
                'desc' => wp_kses(__('you can set <mark>font</mark> for all html tags (if not use different heading font)', 'visaland'), $allowed_html),
            ),
            array(
                'id' => 'body_font_variant',
                'type' => 'select',
                'title' => esc_html__('Load Font Variant', 'visaland'),
                'multiple' => true,
                'chosen' => true,
                'options' => array(
                    '300' => esc_html__('Light 300', 'visaland'),
                    '400' => esc_html__('Regular 400', 'visaland'),
                    '500' => esc_html__('Medium 500', 'visaland'),
                    '600' => esc_html__('Semi Bold 600', 'visaland'),
                    '700' => esc_html__('Bold 700', 'visaland'),
                    '800' => esc_html__('Extra Bold 800', 'visaland'),
                ),
                'default' => array('400', '500', '600', '700')
            ),
            array(
                'type' => 'subheading',
                'content' => '<h3>' . esc_html__('Heading Font Options', 'visaland') . '</h3>',
            ),
            array(
                'type' => 'switcher',
                'id' => 'heading_font_enable',
                'title' => esc_html__('Heading Font', 'visaland'),
                'desc' => wp_kses(__('you can set <mark>yes</mark> to select different heading font', 'visaland'), $allowed_html),
                'default' => true
            ),
            array(
                'type' => 'typography',
                'title' => esc_html__('Typography', 'visaland'),
                'id' => 'heading_font',
                'default' => array(
                    'font-family' => 'Inter',
                    'type' => 'google',
                ),
                'color' => false,
                'subset' => false,
                'text_align' => false,
                'text_transform' => false,
                'letter_spacing' => false,
                'font_size' => false,
                'line_height' => false,
                'desc' => wp_kses(__('you can set <mark>font</mark> for  for heading tag .eg: h1,h2,h3,h4,h5,h6', 'visaland'), $allowed_html),
                'dependency' => array('heading_font_enable', '==', 'true')
            ),
            array(
                'id' => 'heading_font_variant',
                'type' => 'select',
                'title' => esc_html__('Load Font Variant', 'visaland'),
                'multiple' => true,
                'chosen' => true,
                'options' => array(
                    '300' => esc_html__('Light 300', 'visaland'),
                    '400' => esc_html__('Regular 400', 'visaland'),
                    '500' => esc_html__('Medium 500', 'visaland'),
                    '600' => esc_html__('Semi Bold 600', 'visaland'),
                    '700' => esc_html__('Bold 700', 'visaland'),
                    '800' => esc_html__('Extra Bold 800', 'visaland'),
                ),
                'default' => array('400', '500', '600', '700'),
                'dependency' => array('heading_font_enable', '==', 'true')
            ),
        )
    ));

    /*-------------------------------------------------------
           ** Back To Top  Options
    --------------------------------------------------------*/
    CSF::createSection($prefix . '_theme_options', array(
        'title' => esc_html__('Back To Top', 'visaland'),
        'id' => 'theme_general_back_top_options',
        'icon' => 'fa fa-arrow-up',
        'parent' => 'general_options',
        'fields' => array(
            array(
                'type' => 'subheading',
                'content' => '<h3>' . esc_html__('Back Top Options', 'visaland') . '</h3>'
            ),
            array(
                'id' => 'back_top_enable',
                'title' => esc_html__('Back Top', 'visaland'),
                'type' => 'switcher',
                'desc' => wp_kses(__('you can set <mark>Yes / No</mark> to show/hide back to top', 'visaland'), $allowed_html),
                'default' => true,
            ),
            array(
                'id' => 'back_top_icon',
                'title' => esc_html__('Back Top Icon', 'visaland'),
                'type' => 'icon',
                'default' => 'fas fa-arrow-up-long',
                'desc' => wp_kses(__('you can set <mark>icon</mark> for back to top.', 'visaland'), $allowed_html),
                'dependency' => array('back_top_enable', '==', 'true')
            ),
        )
    ));

    /*-------------------------------------------------------
        ** Menu Sidebar  Options
    --------------------------------------------------------*/
    CSF::createSection($prefix . '_theme_options', array(
        'title' => esc_html__('Menu Sidebar', 'visaland'),
        'id' => 'theme_general_sidebar_options',
        'icon' => 'fas fa-bars',
        'parent' => 'general_options',
        'fields' => array(
            array(
                'type' => 'subheading',
                'content' => '<h3>' . esc_html__('Menu Sidebar Option', 'visaland') . '</h3>'
            ),
            array(
                'id' => 'sidebar_logo',
                'type' => 'media',
                'title' => esc_html__('Sidebar Logo', 'visaland'),
                'library' => 'image',
                'desc' => wp_kses(__('you can upload <mark> logo</mark> here it will overwrite customizer uploaded logo', 'visaland'), $allowed_html),
            ),
            array(
                'id' => 'sidebar_text',
                'type' => 'textarea',
                'title' => esc_html__('Sidebar Text', 'visaland'),
                'default' => esc_html__('We understand better that enim ad minim veniam, consectetur adipis cing elit, sed do', 'visaland'),
            ),
            array(
                'id' => 'sidebar_title',
                'type' => 'text',
                'title' => esc_html__('Sidebar Title', 'visaland'),
                'default' => esc_html__('Contact Info', 'visaland'),
            ),
            array(
                'id'        => 'sidebar_contact_info',
                'type'      => 'repeater',
                'title'     => 'Contact Info Repeater',
                'fields'    => array(
              
                  array(
                    'id'    => 'sidebar_contact_icon',
                    'type'  => 'icon',
                    'default' => 'fa-solid fa-phone-volume',
                    'title' => 'Info Icon',
                  ),              
                  array(
                    'id'    => 'sidebar_contact_text',
                    'type'  => 'text',
                    'title' => 'Info Text',
                  ),
                  array(
                    'id'    => 'sidebar_contact_text_url',
                    'type'  => 'text',
                    'title' => 'Info Url',
                  ),
              
                )
            ),
            array(
                'id' => 'sidebar_btn_enabled',
                'type' => 'switcher',
                'title' => esc_html__('Show Button', 'visaland'),
                'default' => true,
                'desc' => wp_kses(__('you can <mark> show/hide</mark> navbar button of header one', 'visaland'), $allowed_html),
            ),
            array(
                'id' => 'sidebar_btn_text',
                'type' => 'text',
                'title' => esc_html__('Button Text', 'visaland'),
                'default' => 'Get A Quote',
                'dependency' => array('sidebar_btn_enabled', '==', 'true')
            ),
            array(
                'id' => 'sidebar_btn_text_url',
                'type' => 'text',
                'title' => esc_html__('Button Url', 'visaland'),
                'default' => esc_html__('#', 'visaland'),
                'dependency' => array('sidebar_btn_enabled', '==', 'true')
            ),
            array(
                'id'        => 'sidebar_socials',
                'type'      => 'repeater',
                'title'     => 'Socials Info Repeater',
                'fields'    => array(
              
                  array(
                    'id'    => 'sidebar_socials_icon',
                    'type'  => 'icon',
                    'default' => 'fa fa-facebook',
                    'title' => 'Socials Info Icon',
                  ),  
                  array(
                    'id'    => 'sidebar_socials_icon_url',
                    'type'  => 'text',
                    'title' => 'Socials Info Url',
                  ),
              
                )
            ),
        )
    ));

    /*-------------------------------------------------------
           ** Theme Color  Options
    --------------------------------------------------------*/
    CSF::createSection($prefix . '_theme_options', array(
        'title' => esc_html__('Theme Colors', 'visaland'),
        'id' => 'theme_color',
        'icon' => 'fa fa-palette',
        'parent' => 'general_options',
        'fields' => array(
            array(
                'type' => 'subheading',
                'content' => '<h3>' . esc_html__('Theme Color Option', 'visaland') . '</h3>'
            ),
            array(
                'id'      => 'theme_color_1',
                'type'    => 'color',
                'title'   => 'Primary Color',
                'default' => '#E20935'
              ),
            array(
                'id'      => 'theme_color_2',
                'type'    => 'color',
                'title'   => 'Secondary Color',
                'default' => '#E20935'
              ),
            array(
                'id'      => 'theme_body_color',
                'type'    => 'color',
                'title'   => 'Body Color',
                'default' => '#FFFFFF'
              ),
            array(
                'id'      => 'theme_black_color',
                'type'    => 'color',
                'title'   => 'Black Color One',
                'default' => '#000000'
              ),
              array(
                'id'      => 'theme_header_color',
                'type'    => 'color',
                'title'   => 'Black Color Two',
                'default' => '#16171A'
              ),
              array(
                'id'      => 'theme_bg_color',
                'type'    => 'color',
                'title'   => 'Background Color',
                'default' => '#F5F5F7'
              ),             
            array(
                'id'      => 'theme_white_color',
                'type'    => 'color',
                'title'   => 'White Color',
                'default' => '#FFFFFF'
              ),          
            array(
                'id'      => 'theme_text_color',
                'type'    => 'color',
                'title'   => 'Paragraph Text Color',
                'default' => '#5E5F63'
              ),
            array(
                'id'      => 'theme_text_color_2',
                'type'    => 'color',
                'title'   => 'Paragraph Text Color 2',
                'default' => '#8A8C94'
              ),
            array(
                'id'      => 'theme_border_color',
                'type'    => 'color',
                'title'   => 'Border Color',
                'default' => '#EEEFF4'
              ),         
              
        )
    ));

    /*----------------------------------
        Header & Footer Style
    -----------------------------------*/
    CSF::createSection($prefix . '_theme_options', array(
        'title' => esc_html__('Set Header & Footer Type', 'visaland'),
        'id' => 'header_footer_style_options',
        'icon' => 'eicon-banner',
        'fields' => array(
            array(
                'type' => 'subheading',
                'content' => esc_html__('Global Header Style', 'visaland'),
            ),
            array(
                'id' => 'navbar_type',
                'title' => esc_html__('Navbar Type', 'visaland'),
                'type' => 'image_select',
                'options' => array(
                    '' => VISALAND_THEME_SETTINGS_IMAGES . '/header/00.png',
                    'style-01' => VISALAND_THEME_SETTINGS_IMAGES . '/header/01.png',
                    'style-02' => VISALAND_THEME_SETTINGS_IMAGES . '/header/02.png',
                    'style-03' => VISALAND_THEME_SETTINGS_IMAGES . '/header/03.png',
                    'style-04' => VISALAND_THEME_SETTINGS_IMAGES . '/header/04.png',
                ),
                'default' => '',
                'desc' => wp_kses(__('you can set <mark>navbar type</mark> it will show in every page except you select specific navbar type form page settings.', 'visaland'), $allowed_html),
            ),
            array(
                'type' => 'subheading',
                'content' => esc_html__('Global Footer Style', 'visaland'),
            ),
            array(
                'id' => 'footer_type',
                'title' => esc_html__('Footer Type', 'visaland'),
                'type' => 'image_select',
                'options' => array(
                    '' => VISALAND_THEME_SETTINGS_IMAGES . '/footer/00.png',
                    'style-01' => VISALAND_THEME_SETTINGS_IMAGES . '/footer/01.png',
                    'style-02' => VISALAND_THEME_SETTINGS_IMAGES . '/footer/02.png',
                    'style-03' => VISALAND_THEME_SETTINGS_IMAGES . '/footer/03.png',
                ),
                'default' => '',
                'desc' => wp_kses(__('you can set <mark>footer type</mark> it will show in every page except you select specific navbar type form page settings.', 'visaland'), $allowed_html),
            ),
        )
    ));

    /*-------------------------------------------------------
       ** Entire Site Header Options
   --------------------------------------------------------*/
    CSF::createSection($prefix . '_theme_options', array(
        'id' => 'headers_settings',
        'title' => esc_html__('Headers', 'visaland'),
        'icon' => 'fa fa-home'
    ));
    /* Default Header Style */
    CSF::createSection($prefix . '_theme_options', array(
        'title' => esc_html__('Default Header', 'visaland'),
        'id' => 'theme_header_default_options',
        'icon' => 'fa fa-image',
        'parent' => 'headers_settings',
       'fields' => array(
        array(
            'type' => 'subheading',
            'content' => '<h3>' . esc_html__('Default Header Settings', 'visaland') . '</h3>'
        ),
        array(
            'id' => 'header_default_logo',
            'type' => 'media',
            'title' => esc_html__('Logo', 'visaland'),
            'library' => 'image',
            'desc' => wp_kses(__('you can upload <mark> logo</mark> here it will overwrite customizer uploaded logo', 'visaland'), $allowed_html),
        ),
        array(
            'id' => 'header_default_right_btn_enabled',
            'type' => 'switcher',
            'title' => esc_html__('Show Right Button', 'visaland'),
            'default' => true,
            'desc' => wp_kses(__('you can <mark> show/hide</mark> navbar button of header one', 'visaland'), $allowed_html),
        ),
        array(
            'id' => 'header_default_right_btn_text',
            'type' => 'text',
            'title' => esc_html__('Right Button Text', 'visaland'),
            'default' => 'Get A Quote',
            'dependency' => array('header_default_right_btn_enabled', '==', 'true'),
        ),
        array(
            'id' => 'header_default_right_btn_url',
            'type' => 'text',
            'title' => esc_html__('Right Button Url', 'visaland'),
            'default' => esc_html__('#', 'visaland'),
            'dependency' => array('header_default_right_btn_enabled', '==', 'true'),
        ),
        array(
            'id' => 'header_default_language_enabled',
            'type' => 'switcher',
            'title' => esc_html__('Show Language Options', 'visaland'),
            'default' => true,
            'desc' => wp_kses(__('you can <mark> show/hide</mark> navbar language options', 'visaland'), $allowed_html),
        ),
        array(
            'id'          => 'header_default_hamburger_style',
            'type'        => 'select',
            'title'       => 'Hamburger On/Off',
            'placeholder' => 'Select an option',
            'options'     => array(
              'block'  => 'Show',
              'none'  => 'Hide',
            ),
            'default'     => 'block'
          ),

        // header 3 top bar start

        array(
            'type' => 'subheading',
            'content' => '<h3>' . esc_html__('Top Bar Options', 'visaland') . '</h3>'
        ),
        array(
            'id' => 'header_default_top_bar_enabled',
            'type' => 'switcher',
            'title' => esc_html__('Show Header Top', 'visaland'),
            'default' => true,
            'desc' => wp_kses(__('you can <mark> show/hide</mark> top bar of header one', 'visaland'), $allowed_html),
        ),  
        array(
            'id' => 'header_default_text',
            'type' => 'text',
            'title' => esc_html__('Left Title', 'visaland'),
            'default' => '<span>Call</span>Consult With It Advisor? <a href="#">Click Now</a>',
            'dependency' => array('header_default_top_bar_enabled', '==', 'true'),
        ),        
        array(
            'id'        => 'header_default_top_bar_contacts_repeater',
            'type'      => 'repeater',
            'title'     => 'Contact Info Repeater',
            'dependency' => array('header_default_top_bar_enabled', '==', 'true'),
            'fields'    => array(          
              array(
                'id'    => 'header_default_top_bar_icon',
                'type'  => 'icon',
                'default' => 'fa-solid fa-phone-volume',
                'title' => 'Info Icon',
              ),              
              array(
                'id'    => 'header_default_top_bar_info',
                'type'  => 'text',
                'title' => 'Info Text',
              ),
              array(
                'id'    => 'header_default_top_bar_info_url',
                'type'  => 'text',
                'title' => 'Info Url',
              ),
          
            )
        ),       
        array(
            'id'        => 'header_default_top_bar_socials_repeater',
            'type'      => 'repeater',
            'title'     => 'Socials Info Repeater',
            'dependency' => array('header_default_top_bar_enabled', '==', 'true'),
            'fields'    => array(
          
              array(
                'id'    => 'header_default_top_bar_socials_icon',
                'type'  => 'icon',
                'default' => 'fa fa-facebook-f',
                'title' => 'Socials Icon',
              ),   
              array(
                'id'    => 'header_default_top_bar_socials_url',
                'type'  => 'text',
                'title' => 'Socials Url',
              ),
          
            )
        ),
          
        )
    ));

      /* Header Style 01 */
      CSF::createSection($prefix . '_theme_options', array(
        'title' => esc_html__('Header One', 'visaland'),
        'id' => 'theme_header_one_options',
        'icon' => 'fa fa-image',
        'parent' => 'headers_settings',
        'fields' => array(
            array(
                'type' => 'subheading',
                'content' => '<h3>' . esc_html__('Header One Settings', 'visaland') . '</h3>'
            ),
            array(
                'id' => 'header_1_logo',
                'type' => 'media',
                'title' => esc_html__('Logo One', 'visaland'),
                'library' => 'image',
                'desc' => wp_kses(__('you can upload <mark> logo</mark> here it will overwrite customizer uploaded logo', 'visaland'), $allowed_html),
            ),
            array(
                'id' => 'header_1_phone_enable',
                'type' => 'switcher',
                'title' => esc_html__('Show Phone Options', 'visaland'),
                'default' => true,
                'desc' => wp_kses(__('you can <mark> show/hide</mark> navbar button of header one', 'visaland'), $allowed_html),
            ),
            array(
                'id' => 'header_1_phone_text',
                'type' => 'text',
                'title' => esc_html__('Phone Text', 'visaland'),
                'default' => 'Get A Quote',
                'dependency' => array('header_1_phone_enable', '==', 'true'),
            ),
            array(
                'id' => 'header_1_phone_url',
                'type' => 'text',
                'title' => esc_html__('Phone Url', 'visaland'),
                'default' => esc_html__('#', 'visaland'),
                'dependency' => array('header_1_phone_enable', '==', 'true'),
            ),  
            array(
                'id' => 'header_1_right_btn_enabled',
                'type' => 'switcher',
                'title' => esc_html__('Show Right Button', 'visaland'),
                'default' => true,
                'desc' => wp_kses(__('you can <mark> show/hide</mark> navbar button of header one', 'visaland'), $allowed_html),
            ),
            array(
                'id' => 'header_1_right_btn_text',
                'type' => 'text',
                'title' => esc_html__('Right Button Text', 'visaland'),
                'default' => 'Get A Quote',
                'dependency' => array('header_1_right_btn_enabled', '==', 'true'),
            ),
            array(
                'id' => 'header_1_right_btn_url',
                'type' => 'text',
                'title' => esc_html__('Right Button Url', 'visaland'),
                'default' => esc_html__('#', 'visaland'),
                'dependency' => array('header_1_right_btn_enabled', '==', 'true'),
            ), 
            array(
                'id' => 'header_1_search_enabled',
                'type' => 'switcher',
                'title' => esc_html__('Show Search Button', 'visaland'),
                'default' => true,
                'desc' => wp_kses(__('you can <mark> show/hide</mark> navbar search button of header one', 'visaland'), $allowed_html),
            ),
            array(
                'id'          => 'header_1_hamburger_style',
                'type'        => 'select',
                'title'       => 'Hamburger On/Off',
                'placeholder' => 'Select an option',
                'options'     => array(
                  'block'  => 'Show',
                  'none'  => 'Hide',
                ),
                'default'     => 'block'
              ),  

           // header 1 top bar start

            array(
                'type' => 'subheading',
                'content' => '<h3>' . esc_html__('Top Bar Options', 'visaland') . '</h3>'
            ),
            array(
                'id' => 'header_1_top_bar_enabled',
                'type' => 'switcher',
                'title' => esc_html__('Show Header Top', 'visaland'),
                'default' => true,
                'desc' => wp_kses(__('you can <mark> show/hide</mark> top bar of header one', 'visaland'), $allowed_html),
            ),           
            array(
                'id'        => 'header_1_top_bar_contacts_repeater',
                'type'      => 'repeater',
                'title'     => 'Contact Info Repeater',
                'dependency' => array('header_1_top_bar_enabled', '==', 'true'),
                'fields'    => array(              
                  array(
                    'id'    => 'header_1_top_bar_contacts_icon',
                    'type'  => 'icon',
                    'default' => 'fa fa-facebook',
                    'title' => 'Contact Info Icon',
                  ),  
                  array(
                    'id'    => 'header_1_top_bar_contacts_url',
                    'type'  => 'text',
                    'title' => 'Contact Info Url',
                  ),
                  array(
                    'id'    => 'header_1_top_bar_contacts_text',
                    'type'  => 'text',
                    'title' => 'Contact Info Text',
                  ),
              
                )
            ), 
            array(
                'id'        => 'header_1_top_bar_socials_repeater',
                'type'      => 'repeater',
                'title'     => 'Socials Info Repeater',
                'dependency' => array('header_1_top_bar_enabled', '==', 'true'),
                'fields'    => array(              
                  array(
                    'id'    => 'header_1_top_bar_socials_icon',
                    'type'  => 'icon',
                    'default' => 'fab fa-facebook-f',
                    'title' => 'Socials Info Icon',
                  ),  
                  array(
                    'id'    => 'header_1_top_bar_socials_icon_url',
                    'type'  => 'text',
                    'title' => 'Socials Info Url',
                  ),
              
                )
            ),
            array(
                'id'        => 'header_1_top_bar_faq_repeater',
                'type'      => 'repeater',
                'title'     => 'Faq Repeater',
                'dependency' => array('header_1_top_bar_enabled', '==', 'true'),
                'fields'    => array( 
                  array(
                    'id'    => 'header_1_top_bar_faq_text',
                    'type'  => 'text',
                    'title' => 'Faq Text',
                  ),
                  array(
                    'id'    => 'header_1_top_bar_faq_url',
                    'type'  => 'text',
                    'title' => 'Faq Url',
                  ),              
                )
            ),         
              
        )
    ));

   /* Header Style 2*/
   CSF::createSection($prefix . '_theme_options', array(
    'title' => esc_html__('Header Two', 'visaland'),
    'id' => 'theme_header_two_options',
    'icon' => 'fa fa-image',
    'parent' => 'headers_settings',
    'fields' => array(
        array(
            'type' => 'subheading',
            'content' => '<h3>' . esc_html__('Header Two Settings', 'visaland') . '</h3>'
        ),
        array(
            'id' => 'header_2_logo',
            'type' => 'media',
            'title' => esc_html__('Logo', 'visaland'),
            'library' => 'image',
            'desc' => wp_kses(__('you can upload <mark> logo</mark> here it will overwrite customizer uploaded logo', 'visaland'), $allowed_html),
        ),
        array(
            'id' => 'header_2_right_btn_enabled',
            'type' => 'switcher',
            'title' => esc_html__('Show Right Button', 'visaland'),
            'default' => true,
            'desc' => wp_kses(__('you can <mark> show/hide</mark> navbar button of header one', 'visaland'), $allowed_html),
        ),
        array(
            'id' => 'header_2_right_btn_text',
            'type' => 'text',
            'title' => esc_html__('Right Button Text', 'visaland'),
            'default' => 'Get A Quote',
            'dependency' => array('header_2_right_btn_enabled', '==', 'true'),
        ),
        array(
            'id' => 'header_2_right_btn_url',
            'type' => 'text',
            'title' => esc_html__('Right Button Url', 'visaland'),
            'default' => esc_html__('#', 'visaland'),
            'dependency' => array('header_2_right_btn_enabled', '==', 'true'),
        ),
        array(
            'id'          => 'header_2_hamburger_style',
            'type'        => 'select',
            'title'       => 'Hamburger On/Off',
            'placeholder' => 'Select an option',
            'options'     => array(
              'block'  => 'Show',
              'none'  => 'Hide',
            ),
            'default'     => 'block'
          ),

        // header 2 top bar start

        array(
            'type' => 'subheading',
            'content' => '<h3>' . esc_html__('Top Bar Options', 'visaland') . '</h3>'
        ),
        array(
            'id' => 'header_2_top_bar_enabled',
            'type' => 'switcher',
            'title' => esc_html__('Show Header Top', 'visaland'),
            'default' => true,
            'desc' => wp_kses(__('you can <mark> show/hide</mark> top bar of header one', 'visaland'), $allowed_html),
        ),    
        array(
            'id' => 'header_2_top_bar_text',
            'type' => 'text',
            'title' => esc_html__('Left Title', 'visaland'),
            'default' => 'Welcome to Visa & Consulting Company',
            'dependency' => array('header_2_top_bar_enabled', '==', 'true'),
        ),       
        array(
            'id'        => 'header_2_top_bar_contacts_repeater',
            'type'      => 'repeater',
            'title'     => 'Contact Info Repeater',
            'dependency' => array('header_2_top_bar_enabled', '==', 'true'),
            'fields'    => array(              
              array(
                'id'    => 'header_2_top_bar_contacts_icon',
                'type'  => 'icon',
                'default' => 'fa fa-facebook',
                'title' => 'Contact Info Icon',
              ),  
              array(
                'id'    => 'header_2_top_bar_contacts_url',
                'type'  => 'text',
                'title' => 'Contact Info Url',
              ),
              array(
                'id'    => 'header_2_top_bar_contacts_text',
                'type'  => 'text',
                'title' => 'Contact Info Text',
              ),
          
            )
        ), 
        array(
            'id'        => 'header_2_top_bar_socials_repeater',
            'type'      => 'repeater',
            'title'     => 'Socials Info Repeater',
            'dependency' => array('header_2_top_bar_enabled', '==', 'true'),
            'fields'    => array(              
              array(
                'id'    => 'header_2_top_bar_socials_icon',
                'type'  => 'icon',
                'default' => 'fab fa-facebook-f',
                'title' => 'Socials Info Icon',
              ),  
              array(
                'id'    => 'header_2_top_bar_socials_icon_url',
                'type'  => 'text',
                'title' => 'Socials Info Url',
              ),
          
            )
        ),
          
        )
    ));

    /* Header Style 3*/

   CSF::createSection($prefix . '_theme_options', array(
    'title' => esc_html__('Header Three', 'visaland'),
    'id' => 'theme_header_three_options',
    'icon' => 'fa fa-image',
    'parent' => 'headers_settings',
    'fields' => array(
        array(
            'type' => 'subheading',
            'content' => '<h3>' . esc_html__('Header Three Settings', 'visaland') . '</h3>'
        ),
        array(
            'id' => 'header_3_logo',
            'type' => 'media',
            'title' => esc_html__('Logo', 'visaland'),
            'library' => 'image',
            'desc' => wp_kses(__('you can upload <mark> logo</mark> here it will overwrite customizer uploaded logo', 'visaland'), $allowed_html),
        ),
        array(
            'id' => 'header_3_right_btn_enabled',
            'type' => 'switcher',
            'title' => esc_html__('Show Right Button', 'visaland'),
            'default' => true,
            'desc' => wp_kses(__('you can <mark> show/hide</mark> navbar button of header one', 'visaland'), $allowed_html),
        ),
        array(
            'id' => 'header_3_right_btn_text',
            'type' => 'text',
            'title' => esc_html__('Right Button Text', 'visaland'),
            'default' => 'Get A Quote',
            'dependency' => array('header_3_right_btn_enabled', '==', 'true'),
        ),
        array(
            'id' => 'header_3_right_btn_url',
            'type' => 'text',
            'title' => esc_html__('Right Button Url', 'visaland'),
            'default' => esc_html__('#', 'visaland'),
            'dependency' => array('header_3_right_btn_enabled', '==', 'true'),
        ),
        array(
            'id' => 'header_3_language_enabled',
            'type' => 'switcher',
            'title' => esc_html__('Show Language Options', 'visaland'),
            'default' => true,
            'desc' => wp_kses(__('you can <mark> show/hide</mark> navbar language options', 'visaland'), $allowed_html),
        ),
        array(
            'id'          => 'header_3_hamburger_style',
            'type'        => 'select',
            'title'       => 'Hamburger On/Off',
            'placeholder' => 'Select an option',
            'options'     => array(
              'block'  => 'Show',
              'none'  => 'Hide',
            ),
            'default'     => 'block'
          ),

        // header 3 top bar start

        array(
            'type' => 'subheading',
            'content' => '<h3>' . esc_html__('Top Bar Options', 'visaland') . '</h3>'
        ),
        array(
            'id' => 'header_3_top_bar_enabled',
            'type' => 'switcher',
            'title' => esc_html__('Show Header Top', 'visaland'),
            'default' => true,
            'desc' => wp_kses(__('you can <mark> show/hide</mark> top bar of header one', 'visaland'), $allowed_html),
        ),  
        array(
            'id' => 'header_3_text',
            'type' => 'text',
            'title' => esc_html__('Left Title', 'visaland'),
            'default' => '<span>Call</span>Consult With It Advisor? <a href="#">Click Now</a>',
            'dependency' => array('header_3_top_bar_enabled', '==', 'true'),
        ),        
        array(
            'id'        => 'header_3_top_bar_contacts_repeater',
            'type'      => 'repeater',
            'title'     => 'Contact Info Repeater',
            'dependency' => array('header_3_top_bar_enabled', '==', 'true'),
            'fields'    => array(          
              array(
                'id'    => 'header_3_top_bar_icon',
                'type'  => 'icon',
                'default' => 'fa-solid fa-phone-volume',
                'title' => 'Info Icon',
              ),              
              array(
                'id'    => 'header_3_top_bar_info',
                'type'  => 'text',
                'title' => 'Info Text',
              ),
              array(
                'id'    => 'header_3_top_bar_info_url',
                'type'  => 'text',
                'title' => 'Info Url',
              ),
          
            )
        ),       
        array(
            'id'        => 'header_3_top_bar_socials_repeater',
            'type'      => 'repeater',
            'title'     => 'Socials Info Repeater',
            'dependency' => array('header_3_top_bar_enabled', '==', 'true'),
            'fields'    => array(
          
              array(
                'id'    => 'header_3_top_bar_socials_icon',
                'type'  => 'icon',
                'default' => 'fa fa-facebook-f',
                'title' => 'Socials Icon',
              ),   
              array(
                'id'    => 'header_3_top_bar_socials_url',
                'type'  => 'text',
                'title' => 'Socials Url',
              ),
          
            )
        ),
          
        )
    ));


      /* Header Style 4*/

   CSF::createSection($prefix . '_theme_options', array(
    'title' => esc_html__('Header Four', 'visaland'),
    'id' => 'theme_header_four_options',
    'icon' => 'fa fa-image',
    'parent' => 'headers_settings',
    'fields' => array(
        array(
            'type' => 'subheading',
            'content' => '<h3>' . esc_html__('Header Four Settings', 'visaland') . '</h3>'
        ),
        array(
            'id' => 'header_4_logo',
            'type' => 'media',
            'title' => esc_html__('Logo', 'visaland'),
            'library' => 'image',
            'desc' => wp_kses(__('you can upload <mark> logo</mark> here it will overwrite customizer uploaded logo', 'visaland'), $allowed_html),
        ),
        array(
            'id' => 'header_4_logo_2',
            'type' => 'media',
            'title' => esc_html__('Logo', 'visaland'),
            'library' => 'image',
            'desc' => wp_kses(__('you can upload <mark> logo</mark> here it will overwrite customizer uploaded logo', 'visaland'), $allowed_html),
        ),
        array(
            'id' => 'header_4_search_btn_enabled',
            'type' => 'switcher',
            'title' => esc_html__('Show Search Button', 'visaland'),
            'default' => true,
            'desc' => wp_kses(__('you can <mark> show/hide</mark> search button of header', 'visaland'), $allowed_html),
        ),
          
        )
    ));
  

    /* Breadcrumb */
    CSF::createSection($prefix . '_theme_options', array(
        'title' => esc_html__('Breadcrumb', 'visaland'),
        'id' => 'breadcrumb_options',
        'icon' => ' eicon-product-breadcrumbs',
        'fields' => array(
            array(
                'type' => 'subheading',
                'content' => '<h3>' . esc_html__('Breadcrumb Options', 'visaland') . '</h3>'
            ),
            array(
                'id' => 'breadcrumb_enabled',
                'title' => esc_html__('Breadcrumb', 'visaland'),
                'type' => 'switcher',
                'desc' => wp_kses(__('you can set <mark>Yes / No</mark> to show/hide breadcrumb', 'visaland'), $allowed_html),
                'default' => true,
            ),
            array(
                'id' => 'breadcrumb_main_image',
                'type' => 'media',
                'title' => esc_html__('Background Image', 'visaland'),
                'library' => 'image',
                'desc' => wp_kses(__('you can upload <mark>background image</mark> here.', 'visaland'), $allowed_html),
                'dependency' => array('breadcrumb_enabled', '==', 'true')
            ),
            array(
                'id' => 'breadcrumb_shape_image',
                'type' => 'media',
                'title' => esc_html__('Shape Image', 'visaland'),
                'library' => 'image',
                'desc' => wp_kses(__('you can upload <mark>shape image</mark> here.', 'visaland'), $allowed_html),
                'dependency' => array('breadcrumb_enabled', '==', 'true')
            ),
            array(
                'id' => 'breadcrumb_shape_image_2',
                'type' => 'media',
                'title' => esc_html__('Shape Image 2', 'visaland'),
                'library' => 'image',
                'desc' => wp_kses(__('you can upload <mark>shape image</mark> here.', 'visaland'), $allowed_html),
                'dependency' => array('breadcrumb_enabled', '==', 'true')
            ),
            array(
                'id' => 'breadcrumb_shape_image_3',
                'type' => 'media',
                'title' => esc_html__('Shape Image 3', 'visaland'),
                'library' => 'image',
                'desc' => wp_kses(__('you can upload <mark>shape image</mark> here.', 'visaland'), $allowed_html),
                'dependency' => array('breadcrumb_enabled', '==', 'true')
            ),
        )
    ));

    /*-------------------------------------------------------
           ** Footer  Options
    --------------------------------------------------------*/
    CSF::createSection($prefix . '_theme_options', array(
        'title' => esc_html__('Footer', 'visaland'),
        'id' => 'footer_options',
        'icon' => ' eicon-footer',
    ));
    // Default Footer  Options
    CSF::createSection($prefix . '_theme_options', array(
        'parent' => 'footer_options',
        'id' => 'footer_general_options',
        'title' => esc_html__('Default Footer', 'visaland'),
        'icon' => 'fa fa-list-ul',
        'fields' => array(
            array(
                'type' => 'subheading',
                'content' => '<h3>' . esc_html__('Default Footer Settings', 'visaland') . '</h3>'
            ), 
            array(
                'id' => 'footer_default_top_enabled',
                'type' => 'switcher',
                'title' => esc_html__('Show Footer Top', 'visaland'),
                'default' => true,
                'desc' => wp_kses(__('you can <mark> show/hide</mark> top bar of footer', 'visaland'), $allowed_html),
            ),         
            array(
                'id' => 'footer_default_shape_image',
                'type' => 'media',
                'title' => esc_html__('Top Shape Image', 'visaland'),
                'library' => 'image',
                'desc' => wp_kses(__('you can upload <mark> shape image</mark> here', 'visaland'), $allowed_html),
            ),   
            array(
                'id' => 'footer_default_shape_image_2',
                'type' => 'media',
                'title' => esc_html__('Bottom Shape Image', 'visaland'),
                'library' => 'image',
                'desc' => wp_kses(__('you can upload <mark> shape image</mark> here', 'visaland'), $allowed_html),
            ), 
            array(
                'type' => 'subheading',
                'content' => '<h3>' . esc_html__('Footer Copyright Area Options', 'visaland') . '</h3>'
            ),         
            array(
                'id' => 'copyright_text',
                'title' => esc_html__('Copyright Area Text', 'visaland'),
                'type' => 'textarea',
                'desc' => wp_kses(__('use  <mark>{copy}</mark> for copyright symbol, use <mark>{year}</mark> for current year, ', 'visaland'), $allowed_html)
            ),
            array(
                'id'        => 'footer_tc_repeater',
                'type'      => 'repeater',
                'title'     => 'Footer Terms & Condition Repeater',
                'fields'    => array(  
                  array(
                    'id'    => 'footer_tc_title',
                    'type'  => 'text',
                    'title' => 'Terms & Condition Title',
                  ),
                  array(
                    'id'    => 'footer_tc_url',
                    'type'  => 'text',
                    'title' => 'Terms & Condition Url',
                  ),              
                )
            ),
          
        )
    ));

    /*-------------------------------------------------------
           ** Footer Style One
    --------------------------------------------------------*/
    CSF::createSection($prefix . '_theme_options', array(
        'parent' => 'footer_options',
        'id' => 'footer_one_options',
        'title' => esc_html__('Footer One', 'visaland'),
        'icon' => 'fa fa-list-ul',
        'fields' => array(
            array(
                'type' => 'subheading',
                'content' => '<h3>' . esc_html__('Footer One Settings', 'visaland') . '</h3>'
            ),                    
            array(
                'id' => 'footer_1_top_enabled',
                'type' => 'switcher',
                'title' => esc_html__('Show Footer Top', 'visaland'),
                'default' => true,
                'desc' => wp_kses(__('you can <mark> show/hide</mark> top bar of footer', 'visaland'), $allowed_html),
            ), 
          
        )
    ));

    /*-------------------------------------------------------
           ** Footer Style Two
    --------------------------------------------------------*/

    CSF::createSection($prefix . '_theme_options', array(
        'parent' => 'footer_options',
        'id' => 'footer_two_options',
        'title' => esc_html__('Footer Two', 'visaland'),
        'icon' => 'fa fa-list-ul',
        'fields' => array(
            array(
                'type' => 'subheading',
                'content' => '<h3>' . esc_html__('Footer Two Settings', 'visaland') . '</h3>'
            ), 
            array(
                'id' => 'footer_2_top_enabled',
                'type' => 'switcher',
                'title' => esc_html__('Show Footer Top', 'visaland'),
                'default' => true,
                'desc' => wp_kses(__('you can <mark> show/hide</mark> top bar of footer', 'visaland'), $allowed_html),
            ),         
            array(
                'id' => 'footer_2_shape_image',
                'type' => 'media',
                'title' => esc_html__('Top Shape Image', 'visaland'),
                'library' => 'image',
                'desc' => wp_kses(__('you can upload <mark> shape image</mark> here', 'visaland'), $allowed_html),
            ),   
            array(
                'id' => 'footer_2_shape_image_2',
                'type' => 'media',
                'title' => esc_html__('Bottom Shape Image', 'visaland'),
                'library' => 'image',
                'desc' => wp_kses(__('you can upload <mark> shape image</mark> here', 'visaland'), $allowed_html),
            ), 
          
        )
    ));


      /*-------------------------------------------------------
           ** Footer Style Three
    --------------------------------------------------------*/
    CSF::createSection($prefix . '_theme_options', array(
        'parent' => 'footer_options',
        'id' => 'footer_three_options',
        'title' => esc_html__('Footer Three', 'visaland'),
        'icon' => 'fa fa-list-ul',
        'fields' => array(
            array(
                'type' => 'subheading',
                'content' => '<h3>' . esc_html__('Footer Three Settings', 'visaland') . '</h3>'
            ),                    
            array(
                'id' => 'footer_3_top_enabled',
                'type' => 'switcher',
                'title' => esc_html__('Show Footer Top', 'visaland'),
                'default' => true,
                'desc' => wp_kses(__('you can <mark> show/hide</mark> top bar of footer', 'visaland'), $allowed_html),
            ), 
          
        )
    ));


    /*-------------------------------------------------------
          ** Blog  Options
    --------------------------------------------------------*/
    CSF::createSection($prefix . '_theme_options', array(
        'id' => 'blog_settings',
        'title' => esc_html__('Blog Settings', 'visaland'),
        'icon' => 'fa fa-book'
    ));
    CSF::createSection($prefix . '_theme_options', array(
        'parent' => 'blog_settings',
        'id' => 'blog_post_options',
        'title' => esc_html__('Blog Post', 'visaland'),
        'icon' => 'fa fa-list-ul',
        'fields' => Visaland_Group_Fields::post_meta('blog_post', esc_html__('Blog Page', 'visaland'))
    ));
    CSF::createSection($prefix . '_theme_options', array(
        'parent' => 'blog_settings',
        'id' => 'blog_single_post_options',
        'title' => esc_html__('Single Post', 'visaland'),
        'icon' => 'fa fa-list-alt',
        'fields' => Visaland_Group_Fields::post_meta('blog_single_post', esc_html__('Blog Single Page', 'visaland'))
    )); 

    /*-------------------------------------------------------
          ** Pages & templates Options
   --------------------------------------------------------*/
    CSF::createSection($prefix . '_theme_options', array(
        'id' => 'pages_and_template',
        'title' => esc_html__('Pages Settings', 'visaland'),
        'icon' => 'fa fa-files-o'
    ));
    /*  404 page options */
    CSF::createSection($prefix . '_theme_options', array(
        'id' => '404_page',
        'title' => esc_html__('404 Page', 'visaland'),
        'parent' => 'pages_and_template',
        'icon' => 'fa fa-exclamation-triangle',
        'fields' => array(
            array(
                'type' => 'subheading',
                'content' => '<h3>' . esc_html__('404 Page Options', 'visaland') . '</h3>',
            ),
            array(
                'id' => '404_title',
                'title' => esc_html__('Title', 'visaland'),
                'type' => 'text',
                'info' => wp_kses(__('you can change <mark>title</mark> of 404 page', 'visaland'), $allowed_html),
                'attributes' => array('placeholder' => esc_html__('Sorry! The Page Not Found', 'visaland'))
            ),
            array(
                'id' => '404_paragraph',
                'title' => esc_html__('Paragraph', 'visaland'),
                'type' => 'textarea',
                'info' => wp_kses(__('you can change <mark>paragraph</mark> of 404 page', 'visaland'), $allowed_html),
                'attributes' => array('placeholder' => esc_html__('Oops! The page you are looking for does not exit. it might been moved or deleted.', 'visaland'))
            ),
            array(
                'id' => '404_button_text',
                'title' => esc_html__('Button Text', 'visaland'),
                'type' => 'text',
                'info' => wp_kses(__('you can change <mark>button text</mark> of 404 page', 'visaland'), $allowed_html),
                'attributes' => array('placeholder' => esc_html__('back to home', 'visaland'))
            ),
        )
    ));

    /*  blog page options */
    CSF::createSection($prefix . '_theme_options', array(
        'id' => 'blog_page',
        'title' => esc_html__('Blog Page', 'visaland'),
        'parent' => 'pages_and_template',
        'icon' => 'fa fa-indent',
        'fields' => Visaland_Group_Fields::page_layout_options(esc_html__('Blog', 'visaland'), 'blog')
    ));
    /*  blog single page options */
    CSF::createSection($prefix . '_theme_options', array(
        'id' => 'blog_single_page',
        'title' => esc_html__('Blog Single Page', 'visaland'),
        'parent' => 'pages_and_template',
        'icon' => 'fa fa-indent',
        'fields' => Visaland_Group_Fields::page_layout_options(esc_html__('Blog Single', 'visaland'), 'blog_single')
    ));
    /*  archive page options */
    CSF::createSection($prefix . '_theme_options', array(
        'id' => 'archive_page',
        'title' => esc_html__('Archive Page', 'visaland'),
        'parent' => 'pages_and_template',
        'icon' => 'fa fa-archive',
        'fields' => Visaland_Group_Fields::page_layout_options(esc_html__('Archive', 'visaland'), 'archive')
    ));
    /*  search page options */
    CSF::createSection($prefix . '_theme_options', array(
        'id' => 'search_page',
        'title' => esc_html__('Search Page', 'visaland'),
        'parent' => 'pages_and_template',
        'icon' => 'fa fa-search',
        'fields' => Visaland_Group_Fields::page_layout_options(esc_html__('Search', 'visaland'), 'search')
    ));

    /*-------------------------------------------------------
           ** Backup  Options
    --------------------------------------------------------*/
    CSF::createSection($prefix . '_theme_options', array(
        'id' => 'backup',
        'title' => esc_html__('Import / Export', 'visaland'),
        'icon' => 'eicon-export-kit',
        'fields' => array(
            array(
                'type' => 'notice',
                'style' => 'warning',
                'content' => esc_html__('You can save your current options. Download a Backup and Import.', 'visaland'),
            ),
            array(
                'type' => 'backup',
                'title' => esc_html__('Backup & Import', 'visaland')
            )
        )
    ));
}
