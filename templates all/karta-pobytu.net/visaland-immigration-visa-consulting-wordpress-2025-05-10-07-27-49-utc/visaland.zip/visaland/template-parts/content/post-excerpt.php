<?php
/**
 * Theme Post excerpt Template
 * @package visaland
 * @since 1.0.0
 */

$visaland = visaland();
$post_meta = Visaland_Group_Fields_Value::post_meta('blog_post');
$excerpt_length = !empty($post_meta['excerpt_length']) ? $post_meta['excerpt_length'] : 55;
$readmore_text = !empty($post_meta['readmore_btn_text']) ? $post_meta['readmore_btn_text'] : esc_html__('Read More','visaland');


Visaland_Excerpt($excerpt_length);
?>
<div class="blog-bottom mt-3">
<?php
    if ($post_meta['readmore_btn']) {
        printf(
            '<div class="blog-button"><a href="%1$s" class="theme-btn"> <span> %2$s <i class="fas fa-chevron-right"></i> </span> </a></div>',
            esc_url(get_the_permalink()),
            esc_html($readmore_text)
        );
    }
    ?>
</div>