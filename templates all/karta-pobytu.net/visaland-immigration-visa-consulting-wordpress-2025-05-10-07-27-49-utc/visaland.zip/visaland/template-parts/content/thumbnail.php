<?php
/**
 * Post Thumbnail 
 * @package visaland
 * @since 1.0.0
 */
?>

 <div class="thumbnail">
    <?php
    if (has_post_thumbnail() && get_post_type() == 'post') {
        visaland()->post_thumbnail('post-thumbnail');
    }
    ?>
</div>
