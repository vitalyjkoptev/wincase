<?php
/**
 * Theme Footer Gallery Widget Template
 * @package visaland
 * @since 1.0.0
 */

if (!is_active_sidebar('footer-newsletter-widget')){
	return;
}
?>

<?php dynamic_sidebar('footer-newsletter-widget');?>