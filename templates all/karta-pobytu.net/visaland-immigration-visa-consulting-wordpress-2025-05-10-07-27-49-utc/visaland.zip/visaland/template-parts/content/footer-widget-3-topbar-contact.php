<?php
/**
 * Theme Footer 3 Widget Top Bar Contact Info Template
 * @package visaland
 * @since 1.0.0
 */

if (!is_active_sidebar('footer-widget-3-topbar-contact')){
	return;
}
?>

<?php dynamic_sidebar('footer-widget-3-topbar-contact');?>