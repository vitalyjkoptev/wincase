<?php
/**
 * Theme Footer Address Widget Template
 * @package visaland
 * @since 1.0.0
 */

if (!is_active_sidebar('footer-address-widget')){
	return;
}
?>

<?php dynamic_sidebar('footer-address-widget');?>