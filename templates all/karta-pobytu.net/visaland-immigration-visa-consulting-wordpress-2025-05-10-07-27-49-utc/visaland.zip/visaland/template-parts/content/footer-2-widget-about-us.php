<?php
/**
 * Theme Footer 2 Widget About Us Template
 * @package visaland
 * @since 1.0.0
 */

if (!is_active_sidebar('footer-2-widget-about-us')){
	return;
}
?>

<?php dynamic_sidebar('footer-2-widget-about-us');?>