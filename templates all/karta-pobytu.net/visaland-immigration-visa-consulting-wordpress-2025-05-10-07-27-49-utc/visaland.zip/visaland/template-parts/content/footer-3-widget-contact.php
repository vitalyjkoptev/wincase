<?php
/**
 * Theme Footer 3 Widget Contact Info Template
 * @package visaland
 * @since 1.0.0
 */

if (!is_active_sidebar('footer-3-widget-contact')){
	return;
}
?>

<?php dynamic_sidebar('footer-3-widget-contact');?>