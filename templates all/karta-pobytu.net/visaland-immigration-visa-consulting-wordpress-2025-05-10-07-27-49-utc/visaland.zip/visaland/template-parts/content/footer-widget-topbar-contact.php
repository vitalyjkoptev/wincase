<?php
/**
 * Theme Footer 2 Widget Top Bar Contact Info Template
 * @package visaland
 * @since 1.0.0
 */

if (!is_active_sidebar('footer-2-widget-topbar-contact')){
	return;
}
?>

<?php dynamic_sidebar('footer-2-widget-topbar-contact');?>