<?php
/**
 * Theme Footer 3 Newsletter Widget Template
 * @package visaland
 * @since 1.0.0
 */

if (!is_active_sidebar('footer-3-newsletter-widget')){
	return;
}
?>

<?php dynamic_sidebar('footer-3-newsletter-widget');?>