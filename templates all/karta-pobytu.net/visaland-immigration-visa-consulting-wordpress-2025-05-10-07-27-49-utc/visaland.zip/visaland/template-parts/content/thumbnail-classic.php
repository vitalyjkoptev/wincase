<?php
/**
 * Post Thumbnail Functions
 * @package visaland
 * @since 1.0.0
 */

$visaland = visaland();
if (has_post_thumbnail()): ?>
    <div class="thumbnail">
        <?php $visaland->post_thumbnail('post-thumbnail'); ?>
    </div>
<?php endif; ?>