<?php
/**
 * Footer Style 03
 * @package visaland
 * @since 1.0.0
 */

$copyright_text = !empty(cs_get_option('copyright_text')) ? cs_get_option('copyright_text'): esc_html__('Copyright © 2025 visaland All Rights Reserved.','visaland');
$copyright_text = str_replace('{copy}','&copy;',$copyright_text);
$copyright_text = str_replace('{year}',date('Y'),$copyright_text);

$footer_3_top_enabled = cs_get_option('footer_3_top_enabled');


?>


<footer class="footer-section section-bg-3">
    <div class="container">
        <?php 
        if( $footer_3_top_enabled ): ?>
        <!-- Footer Top-bar Contact Info -->
        <?php get_template_part('template-parts/content/footer-widget-3-topbar-contact'); ?>
        <?php 
        endif; ?> 
        <div class="footer-widgets-wrapper">
            <div class="row">
                <div class="col-xl-6 col-sm-12 col-md-8 col-lg-6 wow fadeInUp" data-wow-delay=".3s">
                    <!-- footer-newsletter-widget -->
                    <?php get_template_part('template-parts/content/footer-3-newsletter-widget'); ?>   
                </div>
                <div class="col-xl-3 ps-lg-5 col-sm-6 col-md-6 col-lg-3 wow fadeInUp" data-wow-delay=".5s">
                    <!-- footer menu 1 -->
                    <?php get_template_part('template-parts/content/footer-widget'); ?>
                </div>
                <div class="col-xl-3 ps-lg-5 col-sm-6 col-md-6 col-lg-3 wow fadeInUp" data-wow-delay=".7s">
                    <div class="single-footer-widget">
                        <!-- footer-widget-3-contact -->
                        <?php get_template_part('template-parts/content/footer-3-widget-contact'); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="footer-bottom style-2">
        <div class="container">
            <div class="footer-wrapper d-flex align-items-center justify-content-between">
                <p class="wow fadeInUp color-2" data-wow-delay=".4s">
                    <?php
                        echo wp_kses($copyright_text, visaland()->kses_allowed_html(array('a')));
                    ?>
                </p>
            </div>
        </div>
    </div>
</footer>