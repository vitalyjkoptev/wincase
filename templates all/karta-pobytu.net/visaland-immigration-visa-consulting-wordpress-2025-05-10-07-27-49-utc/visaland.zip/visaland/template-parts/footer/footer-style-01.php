<?php
/**
 * Footer Style 01
 * @package visaland
 * @since 1.0.0
 */

$copyright_text = !empty(cs_get_option('copyright_text')) ? cs_get_option('copyright_text'): esc_html__('Copyright © 2025 visaland All Rights Reserved.','visaland');
$copyright_text = str_replace('{copy}','&copy;',$copyright_text);
$copyright_text = str_replace('{year}',date('Y'),$copyright_text);
$footer_tc_repeater = cs_get_option('footer_tc_repeater');

$footer_1_top_enabled = cs_get_option('footer_1_top_enabled');

?>


<footer class="footer-section footer-bg">
    <?php 
    if( $footer_1_top_enabled ): ?>
    <div class="container">
        <div class="footer-widgets-wrapper">
            <div class="row">
                <div class="col-xl-3 col-sm-6 col-md-6 col-lg-3 wow fadeInUp" data-wow-delay=".2s">
                    <!-- footer-2-widget-about-us -->
                    <?php get_template_part('template-parts/content/footer-2-widget-about-us'); ?>
                </div>
                <div class="col-xl-2 ps-lg-5 col-sm-6 col-md-3 col-lg-3 wow fadeInUp" data-wow-delay=".4s">
                      <!-- footer menu 1 -->
                      <?php get_template_part('template-parts/content/footer-widget'); ?>
                </div>
                <div class="col-xl-2 ps-lg-4 col-sm-6 col-md-3 col-lg-3 wow fadeInUp" data-wow-delay=".6s">
                        <!-- footer menu 2 -->
                    <?php get_template_part('template-parts/content/footer-widget-two'); ?>
                </div>
                <div class="col-xl-2 col-sm-6 col-md-6 col-lg-3 wow fadeInUp" data-wow-delay=".8s">
                    <div class="single-footer-widget">
                        <!-- footer-address-widget -->
                        <?php get_template_part('template-parts/content/footer-address-widget'); ?>
                    </div>
                </div>
                <div class="col-xl-3 ps-xl-5 col-sm-6 col-md-6 col-lg-4 wow fadeInUp" data-wow-delay=".9s">
                    <!-- footer-gallery-widget -->
                    <?php get_template_part('template-parts/content/footer-gallery-widget'); ?>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
    <div class="footer-bottom">
        <div class="container">
            <div class="footer-wrapper d-flex align-items-center justify-content-between">
                <p class="wow fadeInLeft color-2" data-wow-delay=".3s">
                    <?php
                        echo wp_kses($copyright_text, visaland()->kses_allowed_html(array('a')));
                    ?>
                </p>
                <?php                
                if (!empty($footer_tc_repeater) && is_array($footer_tc_repeater)) {
                    echo '<ul class="footer-menu wow fadeInRight" data-wow-delay=".5s">';
                    foreach ($footer_tc_repeater as $item) {
                        $title = isset($item['footer_default_tc_title']) ? $item['footer_default_tc_title'] : '';
                        $url = isset($item['footer_default_tc_url']) ? esc_url($item['footer_default_tc_url']) : '#';
                        if (!empty($title)) {
                            echo '<li><a href="' . $url . '">' . esc_html($title) . '</a></li>';
                        }
                    }
                    echo '</ul>';
                }
                ?>
            </div>
        </div>
    </div>
</footer>