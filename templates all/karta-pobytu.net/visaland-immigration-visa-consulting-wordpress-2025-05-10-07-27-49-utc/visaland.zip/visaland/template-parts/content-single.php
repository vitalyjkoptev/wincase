<?php
/**
 * Template part for displaying single post
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package visaland
 */

$visaland = visaland();
$post_meta = get_post_meta(get_the_ID(), 'visaland_post_gallery_options', true);
$post_meta_gallery = isset($post_meta['gallery_images']) && !empty($post_meta['gallery_images']) ? $post_meta['gallery_images'] : '';
$post_single_meta = Visaland_Group_Fields_Value::post_meta('blog_single_post');
?>

<article id="post-<?php the_ID(); ?>" <?php post_class('blog-single-content-wrap blog-wrapper news-wrapper'); ?>>
    
    <?php if ( get_the_title() ) : ?>
        <h2 class="mt-0 title-anim"><?php the_title(); ?></h2>
    <?php endif; ?>

    <div class="entry-content">
        <?php if ('post' == get_post_type()): ?>
            <ul class="post-meta mt-3">
                <?php if ($post_single_meta['posted_by']): ?>
                    <li>
                        <i class="fal fa-user"></i>
                        <span><?php echo esc_html('Written by:', 'visaland'); ?></span>
                        <?php $visaland->posted_by(); ?>
                    </li>
                <?php endif; ?>
                <li>
                    <i class="fal fa-calendar-alt"></i>
                    <span class="date-left-dot"></span>
                    <?php echo get_the_date(); ?>
                </li>
                <li>
                    <i class="fal fa-comments"></i>
                    <span><?php echo esc_html('Comments:', 'visaland'); ?></span>
                    <?php comments_number('(0)', '(1)', '(%)'); ?>
                </li>
            </ul>

        <?php endif;
        the_content();
        $visaland->link_pages();
        ?>
    </div>
    <?php if ('post' == get_post_type() && ((has_tag() && $post_single_meta['posted_tag']) || (shortcode_exists('visaland_post_share') && $post_single_meta['posted_share']))): ?>
        <div class="blog-details-footer">
            <?php if (has_tag() && $post_single_meta['posted_tag']): ?>
                <div class="left">
                    <h5 class="title"><?php echo esc_html__('Tags:', 'visaland') ?></h5>
                    <?php $visaland->posted_tag(); ?>
                </div>
            <?php endif; ?>
            <?php if (shortcode_exists('visaland_post_share') && $post_single_meta['posted_share']) : ?>
                <div class="right">
                    <h5 class="title"><?php echo esc_html__('Share:', 'visaland') ?></h5>
                    <?php
                    if (shortcode_exists('visaland_post_share') && $post_single_meta['posted_share']) {
                        echo do_shortcode('[visaland_post_share]');
                    }
                    ?>
                </div>
            <?php endif; ?>
        </div>
    <?php endif;
    if ($post_single_meta['next_post_nav_btn'] && $visaland->is_visaland_core_active()) {
        echo wp_kses($visaland->post_navigation(), $visaland->kses_allowed_html('all'));
    }
    if ($visaland->is_visaland_core_active()) {
        if ($post_single_meta['get_related_post']) {
            $visaland->get_related_post([
                'post_type' => 'post',
                'taxonomy' => 'category',
                'exclude_id' => get_the_ID(),
                'posts_per_page' => 2
            ]);
        }
    }
    ?>

</article><!-- #post-<?php the_ID(); ?> -->
