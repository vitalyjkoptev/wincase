<?php
/**
 * Header Style 1
 * @package visaland
 * @since 1.0.0
 */
?>

<?php 

    $header_1_top_bar_enabled = cs_get_option('header_1_top_bar_enabled');
    $header_1_top_bar_contacts_repeater = cs_get_option('header_1_top_bar_contacts_repeater');
    $header_1_top_bar_socials_repeater = cs_get_option('header_1_top_bar_socials_repeater');
    $header_1_top_bar_faq_repeater = cs_get_option('header_1_top_bar_faq_repeater');

    $header_1_logo = cs_get_option('header_1_logo');
    $header_1_phone_enable = cs_get_option('header_1_phone_enable');
    $header_1_phone_text = cs_get_option('header_1_phone_text');
    $header_1_phone_url = cs_get_option('header_1_phone_url'); 
    $header_1_right_btn_enabled = cs_get_option('header_1_right_btn_enabled');  
    $header_1_right_btn_text = cs_get_option('header_1_right_btn_text');  
    $header_1_right_btn_url = cs_get_option('header_1_right_btn_url');  
    $header_1_search_enabled = cs_get_option('header_1_search_enabled');  
    $header_1_hamburger_visibility = cs_get_option('header_1_hamburger_style');
    $header_1_hamburger_style = ($header_1_hamburger_visibility == 'block') ? 'block' : 'none';

?> 

    <?php 
    if( $header_1_top_bar_enabled ): ?>
    <div class="header-top-section fix">
        <div class="container">
            <div class="header-top-wrapper">
                <?php              
                if (!empty($header_1_top_bar_contacts_repeater)) {
                    echo '<ul class="contact-list">';
                    foreach ($header_1_top_bar_contacts_repeater as $contact_info) {
                        $icon = !empty($contact_info['header_1_top_bar_contacts_icon']) ? $contact_info['header_1_top_bar_contacts_icon'] : 'fas fa-info-circle';
                        $text = !empty($contact_info['header_1_top_bar_contacts_text']) ? $contact_info['header_1_top_bar_contacts_text'] : '';
                        $url = !empty($contact_info['header_1_top_bar_contacts_url']) ? $contact_info['header_1_top_bar_contacts_url'] : '';

                        echo '<li>';
                        echo '<i class="' . esc_attr($icon) . '"></i>';
                        if (!empty($url)) {
                            echo '<a href="' . esc_url($url) . '" class="link">';
                            echo esc_html($text);
                            echo '</a>';
                        } else {
                            echo esc_html($text);
                        }
                        echo '</li>';
                    }
                    echo '</ul>';
                }
                ?>
                <div class="top-right">

                    <?php                 
                    if (!empty($header_1_top_bar_socials_repeater)) {
                        echo '<div class="social-icon d-flex align-items-center">';
                        foreach ($header_1_top_bar_socials_repeater as $social) {
                            $icon = !empty($social['header_1_top_bar_socials_icon']) ? $social['header_1_top_bar_socials_icon'] : 'fab fa-facebook-f';
                            $url = !empty($social['header_1_top_bar_socials_icon_url']) ? $social['header_1_top_bar_socials_icon_url'] : '#';

                            echo '<a href="' . esc_url($url) . '">';
                            echo '<i class="' . esc_attr($icon) . '"></i>';
                            echo '</a>';
                        }
                        echo '</div>';
                    }
                    ?>

                    <?php                  

                    if (!empty($header_1_top_bar_faq_repeater)) {
                        echo '<ul class="header-menu">';
                        foreach ($header_1_top_bar_faq_repeater as $faq) {
                            $text = !empty($faq['header_1_top_bar_faq_text']) ? $faq['header_1_top_bar_faq_text'] : '';
                            $url = !empty($faq['header_1_top_bar_faq_url']) ? $faq['header_1_top_bar_faq_url'] : '#';

                            echo '<li>';
                            echo '<a href="' . esc_url($url) . '">';
                            echo esc_html($text);
                            echo '</a>';
                            echo '</li>';
                        }
                        echo '</ul>';
                    }
                    ?>

                </div>
            </div>
        </div>
    </div>
    <?php 
    endif; ?> 

        <!-- Header Area Start -->
    <div class="header-section-1">
        <div id="header-sticky" class="header-1">
            <div class="container-fluid">
                <div class="mega-menu-wrapper">
                    <div class="header-main">
                        <div class="header-left">
                            <div class="logo">
                            <?php
                                if (has_custom_logo() && empty($header_1_logo['id'])) {
                                    the_custom_logo();
                                } elseif (!empty($header_1_logo['id'])) {
                                    printf('<a class="header-logo" href="%1$s"><img src="%2$s" alt="%3$s"/></a>', esc_url(get_home_url()), $header_1_logo['url'], $header_1_logo['alt']);
                                } else {
                                    printf('<a class="d-inline-block site-title" href="%1$s">%2$s</a>', esc_url(get_home_url()), esc_html(get_bloginfo('title')));
                                }
                            ?>
                            </div>
                            <div class="mean__menu-wrapper">
                                <div class="main-menu">
                                 
                                <?php
                                    wp_nav_menu(array(
                                    'theme_location' => 'main-menu',
                                    'menu_class' => '',
                                    'container' => 'div',
                                    'container_class' => '',
                                    'container_id' => 'visaland_main_menu',
                                    'fallback_cb' => 'visaland_theme_fallback_menu',
                                    ));
                                ?>

                                </div>
                            </div>
                        </div>
                        <div class="header-right d-flex justify-content-end align-items-center">

                        <?php 
                        if( $header_1_phone_enable ): ?>
                        <div class="contact-info">
                            <div class="icon">
                                <i class="fa fa-phone"></i>
                            </div>
                            <div class="content">
                                <p>Phone:</p>
                                <h6>
                                    <a href="<?php echo esc_url($header_1_phone_url); ?>"><?php echo esc_html($header_1_phone_text); ?></a>
                                </h6>
                            </div>
                        </div>
                        <?php 
                        endif; ?> 

                            <?php 
                            if( $header_1_right_btn_enabled ): ?>
                            <div class="header-button">
                                <a href="<?php echo esc_url($header_1_right_btn_url); ?>" class="link-btn">
                                    <span><?php echo esc_html($header_1_right_btn_text); ?></span>
                                    <i class="fas fa-chevron-right"></i>
                                </a>
                            </div>
                            <?php 
                            endif; ?> 
                            <?php 
                            if( $header_1_search_enabled ): ?>
                                <a href="#0" class="search-trigger search-icon"><i class="fal fa-search"></i></a>
                                <?php 
                            endif; ?> 
                            <div class="header__hamburger d-xl-<?php echo esc_attr($header_1_hamburger_style); ?> my-auto">
                                <div class="sidebar__toggle">
                                    <i class="fas fa-bars"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
