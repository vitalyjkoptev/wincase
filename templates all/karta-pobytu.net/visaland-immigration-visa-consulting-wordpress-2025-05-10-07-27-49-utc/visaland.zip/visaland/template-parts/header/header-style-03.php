<?php
/**
 * Header Style 3
 * @package visaland
 * @since 1.0.0
 */
?>

<?php

 $header_3_top_bar_enabled = cs_get_option('header_3_top_bar_enabled'); 
 $header_3_text = cs_get_option('header_3_text'); 
 $header_3_top_bar_contacts_repeater = cs_get_option('header_3_top_bar_contacts_repeater');
 $header_3_top_bar_socials_repeater = cs_get_option('header_3_top_bar_socials_repeater');

 $header_3_logo = cs_get_option('header_3_logo');
 $header_3_right_btn_text = cs_get_option('header_3_right_btn_text');
 $header_3_right_btn_url = cs_get_option('header_3_right_btn_url'); 
 $header_3_right_btn_enabled = cs_get_option('header_3_right_btn_enabled'); 
 $header_3_language_enabled = cs_get_option('header_3_language_enabled'); 
 $header_3_hamburger_visibility = cs_get_option('header_3_hamburger_style');
 $header_3_hamburger_style = ($header_3_hamburger_visibility == 'block') ? 'block' : 'none';

?> 

    <!-- Header Top Start -->
    <?php 
    if( $header_3_top_bar_enabled ): ?>
    <div class="header-top-section-3">
        <div class="container-fluid">
            <div class="header-top-wrapper style-2 style-3">
                <div class="top-left">
                    <ul class="contact-list">
                        <li>                           
                            <?php
                                if (!empty($header_3_text)) {
                                    echo wp_kses_post($header_3_text);
                                }                                
                            ?>
                        </li>

                        <?php                    

                        if (!empty($header_3_top_bar_contacts_repeater)) {
                            foreach ($header_3_top_bar_contacts_repeater as $contact_info) {
                                $icon = !empty($contact_info['header_3_top_bar_icon']) ? $contact_info['header_3_top_bar_icon'] : 'fas fa-info-circle';
                                $text = !empty($contact_info['header_3_top_bar_info']) ? $contact_info['header_3_top_bar_info'] : '';
                                $url = !empty($contact_info['header_3_top_bar_info_url']) ? $contact_info['header_3_top_bar_info_url'] : '#';

                                echo '<li>';
                                if (!empty($url)) {
                                    echo '<a href="' . esc_url($url) . '">';
                                }
                                echo '<i class="' . esc_attr($icon) . '"></i>';
                                echo esc_html($text);
                                if (!empty($url)) {
                                    echo '</a>';
                                }
                                echo '</li>';
                            }
                        }
                        ?>
                    </ul>
                </div>
                <div class="top-right">
                    <div class="flag-wrap">
                    <?php 
                    if( $header_3_top_bar_enabled ): ?>



                        <?php 
                    endif; ?> 
                    </div>
                    <div class="social-icon d-flex align-items-center">
                        <?php  
                        if ( $header_3_top_bar_socials_repeater ) {
                                foreach ( $header_3_top_bar_socials_repeater as $item ) {
                                    if ( isset( $item['header_3_top_bar_socials_icon'] ) && isset( $item['header_3_top_bar_socials_url'] ) ) {
                                        echo '<a href="' . esc_url( $item['header_3_top_bar_socials_url'] ) . '">';
                                        echo '<i class="' . esc_attr( $item['header_3_top_bar_socials_icon'] ) . '"></i>';
                                        echo '</a>';
                                    }
                                }                            
                            }                    
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php 
    endif; ?> 

    <!-- Header Area Start -->
    <header class="header-section-3">
        <div id="header-sticky" class="header-3">
            <div class="container-fluid">
                <div class="mega-menu-wrapper">
                    <div class="header-main">
                        <div class="logo">
                            <?php                               
                            if (has_custom_logo() && empty($header_3_logo['id'])) {
                                the_custom_logo();
                            } elseif (!empty($header_3_logo['id'])) {
                                printf('<a class="header-logo" href="%1$s"><img src="%2$s" alt="%3$s"/></a>', esc_url(get_home_url()), $header_3_logo['url'], $header_3_logo['alt']);
                            } else {
                                printf('<a class="header-logo d-inline-block site-title" href="%1$s">%2$s</a>', esc_url(get_home_url()), esc_html(get_bloginfo('title')));
                            }
                            ?>
                        </div>
                        <div class="header-left">
                            <div class="mean__menu-wrapper">
                                <div class="main-menu">
                                <?php
                                    wp_nav_menu(array(
                                        'theme_location' => 'main-menu',
                                        'menu_class' => '',
                                        'container' => 'div',
                                        'container_class' => '',
                                        'container_id' => 'visaland_main_menu',
                                        'fallback_cb' => 'visaland_theme_fallback_menu',
                                    ));
                                ?>
                                </div>
                            </div>
                        </div>
                        <div class="header-right d-flex justify-content-end align-items-center">

                            <div class="header-button">
                                <?php 
                                if( $header_3_right_btn_enabled ): ?>
                                <a href="<?php echo esc_url($header_3_right_btn_url); ?>" class="theme-btn theme-btn-2">
                                    <span>
                                        <?php echo esc_html($header_3_right_btn_text); ?>
                                        <i class="fas fa-chevron-right"></i>
                                    </span>
                                    </a>
                                <?php 
                                endif; ?> 
                            </div>

                            <div class="header__hamburger d-xl-<?php echo esc_attr($header_3_hamburger_style); ?> my-auto">
                                <div class="sidebar__toggle">
                                    <div class="header-bar">
                                        <span></span>
                                        <span></span>
                                        <span></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>