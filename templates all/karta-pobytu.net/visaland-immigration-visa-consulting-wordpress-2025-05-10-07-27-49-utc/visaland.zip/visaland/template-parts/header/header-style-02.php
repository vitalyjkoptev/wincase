<?php
/**
 * Header Style 2
 * @package visaland
 * @since 1.0.0
 */
?>

<?php
 $header_2_top_bar_enabled = cs_get_option('header_2_top_bar_enabled'); 
 $header_2_top_bar_text = cs_get_option('header_2_top_bar_text'); 
 $header_2_top_bar_contacts_repeater = cs_get_option('header_2_top_bar_contacts_repeater');
 $header_2_top_bar_socials_repeater = cs_get_option('header_2_top_bar_socials_repeater');

 $header_2_logo = cs_get_option('header_2_logo');
 $header_2_right_btn_text = cs_get_option('header_2_right_btn_text');
 $header_2_right_btn_url = cs_get_option('header_2_right_btn_url'); 
 $header_2_right_btn_enabled = cs_get_option('header_2_right_btn_enabled');  
 $header_2_hamburger_visibility = cs_get_option('header_2_hamburger_style');
 $header_2_hamburger_style = ($header_2_hamburger_visibility == 'block') ? 'block' : 'none';

?> 

<?php 
if( $header_2_top_bar_enabled ): ?>
<div class="header-top-4">
    <div class="container-fluid">
        <div class="header-top-wrapper-4">
            <div class="header-top-left">
                <p>
                <?php
                    if (!empty($header_2_top_bar_text)) {
                        echo wp_kses_post($header_2_top_bar_text);
                    }                                
                ?>
                </p>
            </div>
            <div class="header-top-right">
                <?php              
                    if (!empty($header_2_top_bar_contacts_repeater)) {
                        echo '<ul class="contact-list">';
                        foreach ($header_2_top_bar_contacts_repeater as $contact_info) {
                            $icon = !empty($contact_info['header_2_top_bar_contacts_icon']) ? $contact_info['header_2_top_bar_contacts_icon'] : 'fas fa-info-circle';
                            $text = !empty($contact_info['header_2_top_bar_contacts_text']) ? $contact_info['header_2_top_bar_contacts_text'] : '';
                            $url = !empty($contact_info['header_2_top_bar_contacts_url']) ? $contact_info['header_2_top_bar_contacts_url'] : '';

                            echo '<li>';
                            echo '<i class="' . esc_attr($icon) . '"></i>';
                            if (!empty($url)) {
                                echo '<a href="' . esc_url($url) . '" class="link">';
                                echo esc_html($text);
                                echo '</a>';
                            } else {
                                echo esc_html($text);
                            }
                            echo '</li>';
                        }
                        echo '</ul>';
                    }
                ?>

                <?php                 
                    if (!empty($header_2_top_bar_socials_repeater)) {
                        echo '<div class="social-icon d-flex align-items-center">';
                        foreach ($header_2_top_bar_socials_repeater as $social) {
                            $icon = !empty($social['header_2_top_bar_socials_icon']) ? $social['header_2_top_bar_socials_icon'] : 'fab fa-facebook-f';
                            $url = !empty($social['header_2_top_bar_socials_icon_url']) ? $social['header_2_top_bar_socials_icon_url'] : '#';

                            echo '<a href="' . esc_url($url) . '">';
                            echo '<i class="' . esc_attr($icon) . '"></i>';
                            echo '</a>';
                        }
                        echo '</div>';
                    }
                ?>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Header Section Start -->
<header class="header-section header-2">
    <div id="header-sticky">
        <div class="container-fluid">
            <div class="mega-menu-wrapper">
                <div class="header-main">
                    <div class="header-logo">
                        <?php                               
                            if (has_custom_logo() && empty($header_2_logo['id'])) {
                                the_custom_logo();
                            } elseif (!empty($header_2_logo['id'])) {
                                printf('<a class="header-logo" href="%1$s"><img src="%2$s" alt="%3$s"/></a>', esc_url(get_home_url()), $header_2_logo['url'], $header_2_logo['alt']);
                            } else {
                                printf('<a class="header-logo d-inline-block site-title" href="%1$s">%2$s</a>', esc_url(get_home_url()), esc_html(get_bloginfo('title')));
                            }
                        ?>
                    </div>
                    <div class="header-left">
                        <div class="mean__menu-wrapper d-none d-lg-block">
                            <div class="main-menu">
                                <?php
                                    wp_nav_menu(array(
                                        'theme_location' => 'main-menu',
                                        'menu_class' => '',
                                        'container' => 'div',
                                        'container_class' => '',
                                        'container_id' => 'visaland_main_menu',
                                        'fallback_cb' => 'visaland_theme_fallback_menu',
                                    ));
                                ?>
                                <!-- for wp -->
                            </div>
                        </div>
                    </div>
                    <div class="header-right d-flex justify-content-end align-items-center">
                        <?php 
                        if( $header_2_right_btn_enabled ): ?>
                        <div class="header-button">
                            <a href="<?php echo esc_url($header_2_right_btn_url); ?>" class="theme-btn hover-color">
                                <span><?php echo esc_html($header_2_right_btn_text); ?> <i class="fas fa-chevron-right"></i></span>
                            </a>
                        </div>
                        <?php 
                        endif; ?>
                        <div class="header__hamburger d-xl-<?php echo esc_attr($header_2_hamburger_style); ?> my-auto">
                            <div class="sidebar__toggle">
                                <a class="bar-icon" href="javascript:void(0)">
                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M23.9999 0H16.6736V7.32632H23.9999V0Z" fill="#E20935"/>
                                    <path d="M7.32632 0H0V7.32632H7.32632V0Z" fill="#E20935"/>
                                    <path d="M7.32632 16.6737H0V24H7.32632V16.6737Z" fill="#E20935"/>
                                    <path d="M23.9999 16.6737H16.6736V24H23.9999V16.6737Z" fill="#E20935"/>
                                    </svg>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>