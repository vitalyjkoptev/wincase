<?php
/**
 * Header Style 4
 * @package visaland
 * @since 1.0.0
 */
?>

<?php

 $header_4_logo = cs_get_option('header_4_logo');
 $header_4_logo_2 = cs_get_option('header_4_logo_2');
 $header_4_search_btn_enabled = cs_get_option('header_4_search_btn_enabled');

?> 

    <header>
        <div id="header-sticky" class="header-4">
            <div class="container-fluid">
                <div class="mega-menu-wrapper">
                    <div class="header-main">
                        <div class="logo">
                            <?php                               
                                if (has_custom_logo() && empty($header_4_logo['id'])) {
                                    the_custom_logo();
                                } elseif (!empty($header_4_logo['id'])) {
                                    printf('<a class="header-logo" href="%1$s"><img src="%2$s" alt="%3$s"/></a>', esc_url(get_home_url()), $header_4_logo['url'], $header_4_logo['alt']);
                                } else {
                                    printf('<a class="header-logo d-inline-block site-title" href="%1$s">%2$s</a>', esc_url(get_home_url()), esc_html(get_bloginfo('title')));
                                }
                            ?>
                            <?php                               
                                if (has_custom_logo() && empty($header_4_logo_2['id'])) {
                                    the_custom_logo();
                                } elseif (!empty($header_4_logo_2['id'])) {
                                    printf('<a class="header-logo-2" href="%1$s"><img src="%2$s" alt="%3$s"/></a>', esc_url(get_home_url()), $header_4_logo_2['url'], $header_4_logo_2['alt']);
                                } else {
                                    printf('<a class="header-logo-2 d-inline-block site-title" href="%1$s">%2$s</a>', esc_url(get_home_url()), esc_html(get_bloginfo('title')));
                                }
                            ?>
                        </div>
                        <div class="header-left">
                            <div class="mean__menu-wrapper">
                                <div class="main-menu">
                                    <?php
                                        wp_nav_menu(array(
                                            'theme_location' => 'main-menu',
                                            'menu_class' => '',
                                            'container' => 'div',
                                            'container_class' => '',
                                            'container_id' => 'visaland_main_menu',
                                            'fallback_cb' => 'visaland_theme_fallback_menu',
                                        ));
                                    ?>
                                </div>
                            </div>
                        </div>
                        <div class="header-right d-flex justify-content-end align-items-center">
                            <?php 
                            if( $header_4_search_btn_enabled ): ?>
                                <a href="#0" class="search-trigger search-icon"><i class="fal fa-search"></i></a>
                            <?php 
                            endif; ?> 
                            <div class="header__hamburger d-lg-none my-auto">
                                <div class="sidebar__toggle">
                                    <i class="far fa-bars"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>