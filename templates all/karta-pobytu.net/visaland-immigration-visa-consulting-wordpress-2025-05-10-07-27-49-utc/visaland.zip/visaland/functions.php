<?php
/**
 * Theme functions & definitations
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package visaland
 */

/**
 * Define Theme Folder Path & URL Constant
 * @package visaland
 * @since 1.0.0
 */

define('VISALAND_THEME_ROOT', get_template_directory());
define('VISALAND_THEME_ROOT_URL', get_template_directory_uri());
define('VISALAND_INC', VISALAND_THEME_ROOT . '/inc');
define('VISALAND_THEME_SETTINGS', VISALAND_INC . '/theme-settings');
define('VISALAND_THEME_SETTINGS_IMAGES', VISALAND_THEME_ROOT_URL . '/inc/theme-settings/images');
define('VISALAND_TGMA', VISALAND_INC . '/plugins/tgma');
define('VISALAND_DYNAMIC_STYLESHEETS', VISALAND_INC . '/theme-stylesheets');
define('VISALAND_CSS', VISALAND_THEME_ROOT_URL . '/assets/css');
define('VISALAND_JS', VISALAND_THEME_ROOT_URL . '/assets/js');
define('VISALAND_ASSETS', VISALAND_THEME_ROOT_URL . '/assets');
define('VISALAND_DEV', true);


/**
 * Theme Initial File
 * @package visaland
 * @since 1.0.0
 */
if (file_exists(VISALAND_INC . '/theme-init.php')) {
    require_once VISALAND_INC . '/theme-init.php';
}


/**
 * Codester Framework Functions
 * @package visaland
 * @since 1.0.0
 */
if (file_exists(VISALAND_INC . '/theme-cs-function.php')) {
    require_once VISALAND_INC . '/theme-cs-function.php';
}


/**
 * Theme Helpers Functions
 * @package visaland
 * @since 1.0.0
 */
if (file_exists(VISALAND_INC . '/theme-helper-functions.php')) {

    require_once VISALAND_INC . '/theme-helper-functions.php';
    if (!function_exists('visaland')) {
        function visaland()
        {
            return class_exists('Visaland_Helper_Functions') ? new Visaland_Helper_Functions() : false;
        }
    }
}
/**
 * Nav menu fallback function
 * @since 1.0.0
 */
if (is_user_logged_in()) {
    function visaland_theme_fallback_menu()
    {
        get_template_part('template-parts/default', 'menu');
    }
}

// theme-color

if (file_exists(VISALAND_INC . '/theme-color.php')) {
    require_once VISALAND_INC . '/theme-color.php';
}



// register_block_style

function visaland_register_block_styles() {
    register_block_style(
        'core/paragraph',
        array(
            'name'  => 'fancy-paragraph',
            'label' => __( 'Fancy Paragraph', 'visaland' ),
        )
    );
}
add_action( 'init', 'visaland_register_block_styles' );


// register_block_pattern

function visaland_register_block_patterns() {
    register_block_pattern(
        'visaland/hero-section',
        array(
            'title'       => __( 'Hero Section', 'visaland' ),
            'description' => _x( 'A custom hero section with image and text', 'Block pattern description', 'visaland' ),
            'content'     => '<!-- wp:paragraph --><p>Your content here...</p><!-- /wp:paragraph -->',
        )
    );
}
add_action( 'init', 'visaland_register_block_patterns' );


// custom-header

function visaland_custom_header_setup() {
    add_theme_support( 'custom-header', array(
        'default-image' => get_template_directory_uri() . '/inc/theme-settings/images/header/00.png',
        'width'         => 1000,
        'height'        => 250,
        'flex-width'    => true,
        'flex-height'   => true,
    ) );
}
add_action( 'after_setup_theme', 'visaland_custom_header_setup' );


// custom-background

function visaland_custom_background_setup() {
    add_theme_support( 'custom-background', array(
        'default-color' => 'ffffff',
    ) );
}
add_action( 'after_setup_theme', 'visaland_custom_background_setup' );



