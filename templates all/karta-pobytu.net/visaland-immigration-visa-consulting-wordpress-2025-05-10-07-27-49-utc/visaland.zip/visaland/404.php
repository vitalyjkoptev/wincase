<?php
/**
 * The template for displaying 404 Error page
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package visaland
 */

get_header();
$get_404_options_value = Visaland_Group_Fields_Value::get_404_options_value();
$error_bg_switch = cs_get_option('error_bg_switch');
$error_bg = cs_get_option('error_bg');
?>

    <section class="error-section section-padding fix">
        <div class="container">
            <div class="error-content text-center">
                <h2 class="wow fadeInUp" data-wow-delay=".3s"><?php echo wp_kses_post($get_404_options_value['title']); ?></h2>
                <h3 class="wow fadeInUp" data-wow-delay=".5s"><?php echo esc_html($get_404_options_value['paragraph']); ?></h3>
                <a href="<?php echo esc_url(home_url('/')); ?>" class="theme-btn style-line-height mt-5 wow fadeInUp" data-wow-delay=".7s">
                <span class="button-text"><?php echo esc_html($get_404_options_value['btn_text']); ?></span>
                </a>
            </div>
        </div>
    </section>


<?php
get_footer();
