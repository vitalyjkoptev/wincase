<?php global $redux_demo;
if( isset($redux_demo['header_layout']) ){
  get_header($redux_demo['header_layout']);;	
} else{
    get_header();
}
?>
<div class="category1-topheader">
  <div class="category1-topinside">
    <div class="col-md-6 cattitle">
      <div class="cat-count"> <?php echo esc_html ($wp_query->found_posts) ?>
        <?php esc_html_e( 'Books', 'javapaper' ); ?>
        <?php esc_html_e( 'In  This Category', 'javapaper' ); ?>
      </div>
      <header class="category1-header">
        <h1 class="archive-title">
          <?php single_cat_title(); ?>
        </h1>
      </header>
      <!-- .archive-header -->
    </div>
    <div class="col-md-6">
      <?php if ( category_description() ) : // Show an optional category description ?>
      <?php echo category_description(); ?>
      <?php endif; ?>
    </div>
  </div>
</div>
<div class="single2-wrapper">
  <div id="primary" class="site-content 
  <?php if(isset($redux_demo['jp_sidebar']) ){ ?>
<?php echo esc_html($redux_demo['jp_sidebar']); ?>
<?php } ?>">
    <div id="content" role="main">
      <?php if ( have_posts() ) : ?>
      <div class="category1-wrapper">
        <?php if ( get_query_var('paged') ) {
				$paged = get_query_var('paged');
				} else if ( get_query_var('page') ) {
				$paged = get_query_var('page');
				} else {
				$paged = 1;
				}
				?>
        <?php while(have_posts()) :
				the_post();
				?>
          <div <?php post_class('clearfix'); ?> >
            <?php get_template_part( 'page-templates/catbook', get_post_format() ); ?>
          </div>

        <?php endwhile; ?>
        <?php else : ?>
        <?php get_template_part( 'page-templates/content2', 'none' ); ?>
        <?php endif; ?>
      </div>
    </div>
    <!-- #content -->
    <?php if (function_exists("javapaper_numbered_pages")) { ?>
    <?php javapaper_numbered_pages(); ?>
    <?php } else { ?>
    <nav>
      <ul class="pager">
        <li class="previous">
          <?php next_posts_link( esc_attr__( '&laquo; Older Entries', 'javapaper' ) ); ?>
        </li>
        <li class="next">
          <?php previous_posts_link( esc_attr__( 'Newer Entries &raquo;', 'javapaper' ) ); ?>
        </li>
      </ul>
    </nav>
    <?php } ?>
  </div>
  <!-- #primary -->
  <div class="sidebar 
    <?php if(isset($redux_demo['jp_sidebar']) ){ ?>
<?php echo esc_html($redux_demo['jp_sidebar']); ?>
<?php } ?>">
  <div class="cpt-sidebar"> 
		  <?php if (is_active_sidebar('book-sidebar')) :?>
		  <?php dynamic_sidebar( 'book-sidebar' ); ?>
		  <?php endif; ?>   
  </div>
  </div>  
</div>
<?php 
if( isset($redux_demo['footer_layout']) ){
  get_template_part($redux_demo['footer_layout']);
} else{
    get_footer();
}
?>